# 💰 Money Cal Saving

แอป Android สำหรับบันทึก **รายรับ รายจ่าย และเงินออมของครอบครัว** ดีไซน์พาสเทลน่ารัก ใช้งานได้ **ออฟไลน์ 100%** ข้อมูลทั้งหมดอยู่ในเครื่อง

- Android 8.0+ (API 26) · targetSdk 35 · แนวตั้งเท่านั้น
- ภาษาไทย · สกุลเงิน ฿ รูปแบบ `1,234.50` · ปี พ.ศ. (สลับเป็น ค.ศ. ได้)
- Flutter · Material 3 · Riverpod · Drift (SQLite) · fl_chart · flutter_local_notifications

> ⚠️ **สถานะโค้ด:** โปรเจกต์นี้เขียนครบทุกส่วนแล้ว แต่ผู้เขียนยังไม่ได้คอมไพล์หรือรันบนเครื่องที่มี Flutter
> ขั้นตอนแรกที่ควรทำคือ `flutter pub get` → build_runner → `flutter test` → `flutter run`
> หากเจอ error ตอน build ให้ดูหัวข้อ [แก้ปัญหา](#แก้ปัญหา)

---

## ✨ ฟีเจอร์

| ส่วน | รายละเอียด |
|---|---|
| **หน้าแรก** | ยอดคงเหลือ (ตามแผน/ตอนนี้), สรุปรับ-จ่าย-ออม, รายการใกล้ครบกำหนด + ปุ่ม "จ่ายเลย", เป้าหมายออม, ข้อสังเกตเทียบเดือนก่อน |
| **รายรับ** | ประจำทุกเดือน และพิเศษครั้งเดียว, สถานะ "รอเงินเข้า/ได้รับแล้ว", กรองตามสมาชิก |
| **รายจ่าย** | ประจำ/ผ่อนชำระ (นับงวดอัตโนมัติ, ปิดยอด) และรายจ่ายจร, แท็บ ทั้งหมด/ยังไม่จ่าย/จ่ายแล้ว |
| **สรุป** | กราฟเส้นรายรับ-รายจ่าย 6/12 เดือน, วงกลมแยกหมวด, เทียบเดือนก่อน, กรองรายคน |
| **เป้าหมายออม** | ฝาก/ถอน, วงแหวนความคืบหน้า, "ต้องออมเดือนละเท่าไร", พลุฉลองเมื่อถึงเป้า |
| **สมาชิกครอบครัว** | ชื่อ/ชื่อเล่น/สี/รูป, สรุปรายคน, ลบแล้วเลือกย้ายไป "ส่วนกลาง" หรือลบรายการ |
| **การแจ้งเตือน** | ล่วงหน้า 0/1/3/7 วัน เวลา 09:00 (ปรับได้), ปุ่ม "จ่ายแล้ว" บนแจ้งเตือน, ตั้งใหม่หลังรีบูต |
| **ปฏิทินการเงิน** | จุดสีบอกวันที่มีรายการ แตะดูรายละเอียดรายวัน |
| **หมวดหมู่** | เพิ่ม/แก้/ลบ/ลากเรียง (มี Undo) |
| **ตั้งค่า** | ธีมสว่าง/มืด, พ.ศ./ค.ศ., ยกยอดคงเหลือ, PIN + ลายนิ้วมือ, สำรอง/กู้คืน JSON, ส่งออก CSV, ข้อมูลตัวอย่าง, ล้างข้อมูล |

การลบทุกชนิดมีกล่องยืนยันและปุ่ม **เลิกทำ (Undo)** · รายการประจำจะถามว่าแก้/ลบ "เฉพาะเดือนนี้" หรือ "ตั้งแต่เดือนนี้เป็นต้นไป"

---

## 🚀 เริ่มใช้งาน (ครั้งแรก)

ต้องมี **Flutter ≥ 3.27** (Dart ≥ 3.5) และ Android SDK

```bash
# 1) แตกไฟล์โปรเจกต์ แล้วเข้าโฟลเดอร์
cd money_cal_saving

# 2) สร้างโฟลเดอร์ android/ + ใส่ manifest/gradle ตามสเปก + build_runner + ไอคอน + splash
bash tool/setup_android.sh

# 3) ทดสอบ แล้วรัน
flutter test
flutter run
```

สคริปต์ `tool/setup_android.sh` ทำให้ทั้งหมดนี้ (ทำเองทีละขั้นได้ ดูด้านล่าง)

<details>
<summary>ทำเองทีละขั้น (ไม่ใช้สคริปต์)</summary>

```bash
flutter create --platforms=android --org th.moneycal --project-name money_cal_saving .
cp android_overrides/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
mkdir -p android/app/src/main/kotlin/th/moneycal/money_cal_saving
cp android_overrides/MainActivity.kt android/app/src/main/kotlin/th/moneycal/money_cal_saving/MainActivity.kt
cp android_overrides/proguard-rules.pro android/app/proguard-rules.pro
python3 tool/patch_gradle.py        # minSdk 26, targetSdk 35, desugaring, R8, signing
flutter pub get
dart run build_runner build --delete-conflicting-outputs   # สร้างโค้ด Drift (*.g.dart)
dart run flutter_launcher_icons
dart run flutter_native_splash:create
```

> `MainActivity` ต้องเป็น `FlutterFragmentActivity` (ไฟล์ใน `android_overrides/` ทำไว้แล้ว) เพราะ `local_auth` ใช้ลายนิ้วมือ
</details>

### ไฟล์ Android ที่ปรับให้
- `AndroidManifest.xml`: ชื่อแอป **Money Cal Saving**, ล็อกแนวตั้ง, สิทธิ์ `POST_NOTIFICATIONS`, `SCHEDULE_EXACT_ALARM`, `RECEIVE_BOOT_COMPLETED`, `USE_BIOMETRIC`, ตัวรับแจ้งเตือน/รีบูต/ปุ่ม "จ่ายแล้ว"
- `build.gradle(.kts)`: minSdk 26, targetSdk 35, core library desugaring (จำเป็นสำหรับ flutter_local_notifications), เปิด R8 + `proguard-rules.pro`, signing จาก `android/key.properties`

---

## 🔤 ฟอนต์ (Noto Sans Thai) และการใช้งานออฟไลน์

ค่าเริ่มต้น `google_fonts` จะดาวน์โหลดฟอนต์ **ครั้งแรกที่เปิดแอปตอนมีเน็ต** แล้วแคชไว้ใช้ต่อ

ถ้าต้องการให้ออฟไลน์ได้ตั้งแต่ครั้งแรก:
1. ดาวน์โหลด Noto Sans Thai (.ttf) จาก Google Fonts
2. วางใน `assets/google_fonts/` ตั้งชื่อ `NotoSansThai-Regular.ttf`, `-Medium`, `-SemiBold`, `-Bold`
3. สร้างแอปด้วย `--dart-define=BUNDLED_FONTS=true` (ปิดการดาวน์โหลดฟอนต์):
   ```bash
   flutter run --dart-define=BUNDLED_FONTS=true
   ```

---

## 📦 สร้างไฟล์ติดตั้ง (Build)

### APK สำหรับติดตั้งเอง (debug key)
```bash
flutter build apk --release
# ได้ไฟล์: build/app/outputs/flutter-apk/app-release.apk
```

### เซ็นแอปด้วย keystore ของคุณเอง (แนะนำสำหรับแจกจริง/ขึ้น Play Store)

1) สร้าง keystore (เก็บไฟล์และรหัสผ่านไว้ให้ดี **ทำหายแล้วอัปเดตแอปเดิมไม่ได้**)
```bash
keytool -genkey -v -keystore ~/money-cal-saving.jks -keyalg RSA -keysize 2048 -validity 10000 -alias moneycal
```

2) สร้างไฟล์ `android/key.properties` (ถูกใส่ใน `.gitignore` แล้ว ห้ามอัปโหลดขึ้น git)
```properties
storePassword=รหัสผ่าน keystore
keyPassword=รหัสผ่านกุญแจ
keyAlias=moneycal
storeFile=/เส้นทางเต็ม/ไปที่/money-cal-saving.jks
```

3) สร้างไฟล์ที่เซ็นแล้ว (`patch_gradle.py` ตั้งให้อ่าน `key.properties` อัตโนมัติ)
```bash
# APK
flutter build apk --release --dart-define=BUNDLED_FONTS=true
# App Bundle สำหรับ Google Play
flutter build appbundle --release --dart-define=BUNDLED_FONTS=true
```
(ถ้ายังไม่วางไฟล์ฟอนต์ ให้ตัด `--dart-define=BUNDLED_FONTS=true` ออก)

เพิ่มเลขเวอร์ชันได้ที่ `version:` ใน `pubspec.yaml` (เช่น `1.0.1+2`)

ตรวจลายเซ็น: `keytool -printcert -jarfile build/app/outputs/flutter-apk/app-release.apk`

---

## 🔔 เรื่องการแจ้งเตือนบน Android

- **Android 13+** ต้องกดอนุญาตการแจ้งเตือน (ไปที่ เมนู > การแจ้งเตือน > "อนุญาตการแจ้งเตือน")
- **Android 12+** ต้องอนุญาต "การเตือนและการแจ้งเตือน" (exact alarm) จึงจะเตือนตรงเวลาเป๊ะ ถ้าไม่อนุญาต แอปจะใช้การเตือนแบบประมาณเวลา
- เครื่องบางยี่ห้อ (Xiaomi, Oppo, Vivo, Huawei, Samsung ประหยัดแบตมากๆ) อาจฆ่าแอปเบื้องหลัง ให้ตั้งแอปเป็น "ไม่จำกัดแบตเตอรี่/อนุญาตเริ่มอัตโนมัติ"
- เวลาเปิดแอป ระบบจะตั้งการแจ้งเตือนใหม่ทั้งหมดจากข้อมูลล่าสุด และตั้งใหม่หลังรีบูตเครื่องอัตโนมัติ

---

## 🧮 กติกาการคำนวณ

- เงินทุกจำนวนเก็บเป็น **สตางค์ (จำนวนเต็ม)** ไม่ใช้ทศนิยม เพื่อไม่ให้เศษคลาดเคลื่อน
- รายการประจำ = **แม่แบบ (template)** + **รายการรายเดือน (instance)** สร้างอัตโนมัติเมื่อเปิดเดือนนั้น ไม่ซ้ำ (unique `templateId + yyyy-MM`) สถานะ "ได้รับ/จ่ายแล้ว" แยกตามเดือน
- **เงินคงเหลือ (ตามแผน)** = รายรับรวม − รายจ่ายรวม − เงินออมสุทธิ
- **เงินคงเหลือ (ตอนนี้)** = รายรับที่ได้รับแล้ว − รายจ่ายที่จ่ายแล้ว − เงินออมสุทธิ
- **ยกยอดคงเหลือ** (ปิดเป็นค่าเริ่มต้น): ยอดบวกของเดือนก่อนถูกนับเป็นรายรับยกมา คำนวณสดทุกครั้ง จึงถูกต้องแม้แก้เดือนเก่า
- "ลบเฉพาะเดือนนี้" ใช้ tombstone (`isSkipped`) เพื่อไม่ให้ระบบสร้างรายการนั้นซ้ำ
- งวดผ่อน: นับจากเดือนเริ่มต้น หยุดสร้างเมื่อครบงวด หรือปิดยอดเอง

---

## 🗂️ โครงสร้างโปรเจกต์

```
lib/
├─ main.dart, app.dart            จุดเริ่มต้น, ธีม, ล็อกแนวตั้ง, ภาษาไทย
├─ core/
│  ├─ theme/                      สี gradient ขนาด ฟอนต์ ธีมสว่าง/มืด (AppPalette)
│  └─ utils/                      Money, AppDates, Haptics, IntMath, AmountInputFormatter
├─ widgets/                       widget กลาง: GradientCard, GlassCard, AmountText, MonthSelector, FloatingNavBar, ...
├─ data/
│  ├─ db/                         ตาราง Drift, AppDatabase, DAO
│  ├─ repositories/               ตรรกะเขียนข้อมูล (แก้/ลบ/Undo/ปิดยอด)
│  └─ seed/                       หมวดหมู่ตั้งต้น, ข้อมูลตัวอย่าง
├─ domain/                        ฟังก์ชันล้วน: คำนวณสรุป, เป้าหมาย, สถานะ, สร้างรายการรายเดือน
├─ providers/                     Riverpod (stream จาก Drift → ทุกหน้าอัปเดตตรงกัน)
├─ services/                      แจ้งเตือน, สำรอง/CSV, PIN/ลายนิ้วมือ
└─ features/                      หน้าจอ: shell, home, income, expense, report, savings,
                                  members, categories, calendar, notifications, settings, lock
test/                             unit test (คำนวณ/วันที่/เงิน), repository test (SQLite in-memory), widget overflow test
tool/                             setup_android.sh, patch_gradle.py, generate_icons.py
android_overrides/                AndroidManifest, MainActivity, proguard
assets/icon/                      ไอคอนและ splash พาสเทล (สร้างใหม่ด้วย tool/generate_icons.py)
```

## 🧪 การทดสอบ

```bash
flutter test
```
- **unit test**: เงิน วันที่ กติกาแม่แบบ ตัวสร้างรายการรายเดือน สรุปยอด เป้าหมาย สถานะ
- **repository test** (`test/data/repositories_test.dart`): ใช้ SQLite ในหน่วยความจำ ต้องมีไลบรารี `sqlite3` ในเครื่อง (Linux: `sudo apt install libsqlite3-dev`, macOS มีอยู่แล้ว)
- **widget test** (`test/widgets/overflow_test.dart`): ตรวจว่าไม่ล้นที่ 360/411/480dp และตัวอักษร 1.0x/1.3x

## 🛠️ แก้ปัญหา

| อาการ | วิธีแก้ |
|---|---|
| `flutter pub get` แก้เวอร์ชันไม่ลงตัว | `flutter pub upgrade --major-versions` แล้ว `flutter pub get` |
| ไม่พบ `app_database.g.dart` / `_$AppDatabase` | `dart run build_runner build --delete-conflicting-outputs` |
| error เรื่อง `uiLocalNotificationDateInterpretation` หรือ `androidScheduleMode` | โปรเจกต์ล็อก `flutter_local_notifications: ^17.2.3` ถ้าอัปเป็น v18+ ให้ลบพารามิเตอร์ `uiLocalNotificationDateInterpretation` ใน `lib/services/notification_service.dart` |
| error เรื่อง `desugar` ตอน build Android | รัน `python3 tool/patch_gradle.py` (ต้องเปิด core library desugaring) |
| ฟอนต์ไทยเป็นกล่อง/ไม่ขึ้นครั้งแรกตอนไม่มีเน็ต | วางไฟล์ฟอนต์ตามหัวข้อฟอนต์ หรือเปิดแอปครั้งแรกตอนมีเน็ต |
| ลายนิ้วมือไม่ทำงาน | ตรวจว่า `MainActivity` เป็น `FlutterFragmentActivity` และเครื่องตั้งลายนิ้วมือไว้แล้ว |
| `repositories_test` ล้ม: ไม่พบ sqlite3 | ติดตั้ง `libsqlite3` ในเครื่อง (ดูหัวข้อทดสอบ) |

## 🔐 ความเป็นส่วนตัว

ไม่มีการส่งข้อมูลออกนอกเครื่อง ไม่มีโฆษณา ไม่มีบัญชีผู้ใช้ · PIN เก็บเป็นค่าแฮช SHA-256 + salt · ไฟล์สำรอง JSON **ไม่รวม PIN**
ไฟล์สำรองไม่ได้เข้ารหัส ควรเก็บไว้ในที่ปลอดภัย
