import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';
import '../core/theme/app_dimens.dart';
import '../core/utils/money.dart';

/// แสดงยอดเงิน (รับค่าเป็นสตางค์) พร้อม FittedBox(scaleDown)
/// ตัวเลขหลักล้านจะย่อให้พอดีกรอบ ไม่ล้นขอบ
///
/// เมื่ออยู่ใน Row ให้ห่อด้วย Flexible/Expanded เสมอ เพื่อให้ FittedBox มีความกว้างจำกัด
/// [animate] = true จะนับตัวเลขวิ่งขึ้นตอนแสดงครั้งแรกและตอนค่าเปลี่ยน
class AmountText extends StatelessWidget {
  const AmountText(
    this.satang, {
    super.key,
    this.style,
    this.color,
    this.animate = false,
    this.showSymbol = true,
    this.showSign = false,
    this.redWhenNegative = false,
    this.alignment = Alignment.centerLeft,
  });

  final int satang;
  final TextStyle? style;
  final Color? color;
  final bool animate;
  final bool showSymbol;
  final bool showSign;

  /// ติดลบให้เป็นสีแดงพาสเทลเข้ม (อ่านง่ายบนพื้นพาสเทล)
  final bool redWhenNegative;
  final AlignmentGeometry alignment;

  @override
  Widget build(BuildContext context) {
    final base = style ?? Theme.of(context).textTheme.titleLarge!;
    final resolvedColor = color ??
        (redWhenNegative && satang < 0 ? AppColors.dangerInk : base.color);
    final resolved = base.copyWith(
      color: resolvedColor,
      fontWeight: base.fontWeight ?? FontWeight.w700,
      fontFeatures: const [FontFeature.tabularFigures()],
    );

    Widget buildText(int value) => Text(
          Money.format(value, symbol: showSymbol, signed: showSign),
          style: resolved,
          maxLines: 1,
          softWrap: false,
        );

    final disableAnimations =
        MediaQuery.maybeDisableAnimationsOf(context) ?? false;

    final Widget text = (animate && !disableAnimations)
        ? TweenAnimationBuilder<int>(
            tween: IntTween(begin: 0, end: satang),
            duration: AppDurations.counter,
            curve: Curves.easeOutCubic,
            builder: (context, value, _) => buildText(value),
          )
        : buildText(satang);

    return FittedBox(
      fit: BoxFit.scaleDown,
      alignment: alignment,
      child: text,
    );
  }
}
