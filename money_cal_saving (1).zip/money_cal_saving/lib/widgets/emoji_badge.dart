import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';
import '../core/theme/app_dimens.dart';
import '../core/theme/app_gradients.dart';

/// วงกลมอีโมจิ + gradient ใช้กับสมาชิก หมวดหมู่ เป้าหมายออม
class EmojiBadge extends StatelessWidget {
  const EmojiBadge({
    super.key,
    required this.emoji,
    this.color,
    this.gradient,
    this.size = 44,
  });

  final String emoji;
  final Color? color;
  final LinearGradient? gradient;
  final double size;

  @override
  Widget build(BuildContext context) {
    final g = gradient ?? AppGradients.fromColor(color ?? AppColors.brandA);
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: g,
        border: Border.all(color: Colors.white.withValues(alpha: 0.7)),
        boxShadow: AppShadows.soft(
          g.colors.first,
          opacity: 0.35,
          blur: 10,
          dy: 4,
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(size * 0.2),
        child: FittedBox(
          child: Text(emoji, style: TextStyle(fontSize: size * 0.5)),
        ),
      ),
    );
  }
}
