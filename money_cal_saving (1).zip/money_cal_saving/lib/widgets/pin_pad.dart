import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../core/theme/app_colors.dart';
import '../core/theme/app_dimens.dart';
import '../core/theme/app_gradients.dart';
import '../core/theme/app_palette.dart';
import '../core/utils/haptics.dart';
import 'pressable_scale.dart';

/// แป้นกรอก PIN 4 หลัก (ปุ่มใหญ่ ≥ 64dp) พร้อมจุดแสดงจำนวนหลักและอนิเมชันสั่นเมื่อผิด
class PinPad extends StatefulWidget {
  const PinPad({
    super.key,
    required this.onCompleted,
    this.length = 4,
    this.onBiometric,
  });

  final int length;

  /// เรียกเมื่อกรอกครบ ส่ง PIN ที่กรอก คืน false = ผิด (สั่นและล้างค่า) / true = ผ่าน
  final Future<bool> Function(String pin) onCompleted;
  final VoidCallback? onBiometric;

  @override
  State<PinPad> createState() => PinPadState();
}

class PinPadState extends State<PinPad> with SingleTickerProviderStateMixin {
  String _pin = '';
  bool _busy = false;
  late final AnimationController _shake = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 380),
  );

  @override
  void dispose() {
    _shake.dispose();
    super.dispose();
  }

  Future<void> _add(String d) async {
    if (_busy || _pin.length >= widget.length) return;
    Haptics.selection();
    setState(() => _pin += d);
    if (_pin.length == widget.length) {
      _busy = true;
      final ok = await widget.onCompleted(_pin);
      if (!mounted) return;
      if (!ok) {
        Haptics.heavy();
        await _shake.forward(from: 0);
      }
      if (mounted) {
        setState(() {
          _pin = '';
          _busy = false;
        });
      }
    }
  }

  void _back() {
    if (_busy || _pin.isEmpty) return;
    Haptics.selection();
    setState(() => _pin = _pin.substring(0, _pin.length - 1));
  }

  @override
  Widget build(BuildContext context) {
    final p = context.palette;

    Widget key(String label) => _Key(
          onTap: () => _add(label),
          child: Text(
            label,
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.w600, color: p.ink),
          ),
        );

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        AnimatedBuilder(
          animation: _shake,
          builder: (context, child) {
            final dx = (1 - _shake.value) *
                14 *
                ((_shake.value * 10).floor().isEven ? 1 : -1);
            return Transform.translate(offset: Offset(_shake.isAnimating ? dx : 0, 0), child: child);
          },
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (var i = 0; i < widget.length; i++)
                AnimatedContainer(
                  duration: AppDurations.fast,
                  margin: const EdgeInsets.symmetric(horizontal: 10),
                  width: 18,
                  height: 18,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: i < _pin.length ? AppGradients.brand : null,
                    color: i < _pin.length ? null : p.divider,
                    border: Border.all(color: p.glassBorder),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 32),
        for (final row in const [
          ['1', '2', '3'],
          ['4', '5', '6'],
          ['7', '8', '9'],
        ])
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [for (final d in row) key(d)],
            ),
          ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              widget.onBiometric == null
                  ? const SizedBox(width: 88, height: 72)
                  : _Key(
                      label: 'สแกนลายนิ้วมือ',
                      onTap: widget.onBiometric!,
                      child: Icon(PhosphorIconsRegular.fingerprint, size: 30, color: p.ink),
                    ),
              key('0'),
              _Key(
                label: 'ลบ',
                onTap: _back,
                child: Icon(PhosphorIconsRegular.backspace, size: 28, color: p.ink),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _Key extends StatelessWidget {
  const _Key({required this.child, required this.onTap, this.label});

  final Widget child;
  final VoidCallback onTap;
  final String? label;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return SizedBox(
      width: 88,
      height: 72,
      child: Center(
        child: PressableScale(
          onTap: onTap,
          semanticLabel: label,
          child: Container(
            width: 68,
            height: 68,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: p.surface.withValues(alpha: 0.7),
              border: Border.all(color: p.glassBorder),
              boxShadow: AppShadows.neutral(p, opacity: 0.12),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}
