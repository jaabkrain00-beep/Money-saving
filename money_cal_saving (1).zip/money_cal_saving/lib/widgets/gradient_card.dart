import 'package:flutter/material.dart';

import '../core/theme/app_dimens.dart';
import '../core/theme/app_palette.dart';
import 'on_pastel.dart';
import 'pressable_scale.dart';

/// การ์ด gradient พาสเทล + เงานุ่ม + ขอบขาวใส + แสงสะท้อนด้านบน (มีมิติ ไม่แบน)
/// ตัวอักษรข้างในใช้สีเข้มอัตโนมัติ แม้อยู่ใน Dark mode
class GradientCard extends StatelessWidget {
  const GradientCard({
    super.key,
    required this.gradient,
    required this.child,
    this.padding = const EdgeInsets.all(18),
    this.margin,
    this.radius = AppRadius.card,
    this.onTap,
    this.onLongPress,
    this.shadowColor,
    this.glossy = true,
  });

  final LinearGradient gradient;
  final Widget child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry? margin;
  final double radius;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final Color? shadowColor;
  final bool glossy;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final borderRadius = BorderRadius.circular(radius);
    final shadow = shadowColor ?? gradient.colors.first;

    Widget card = DecoratedBox(
      decoration: BoxDecoration(
        gradient: gradient,
        borderRadius: borderRadius,
        border: Border.all(color: Colors.white.withValues(alpha: 0.6)),
        boxShadow: AppShadows.soft(shadow, opacity: p.isDark ? 0.22 : 0.4),
      ),
      child: ClipRRect(
        borderRadius: borderRadius,
        child: Stack(
          children: [
            if (glossy)
              Positioned.fill(
                child: IgnorePointer(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.center,
                        colors: [
                          Colors.white.withValues(alpha: 0.32),
                          Colors.white.withValues(alpha: 0),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            Padding(
              padding: padding,
              child: OnPastel(child: child),
            ),
          ],
        ),
      ),
    );

    if (onTap != null || onLongPress != null) {
      card = PressableScale(
        onTap: onTap,
        onLongPress: onLongPress,
        scale: 0.98,
        child: card,
      );
    }

    if (margin != null) card = Padding(padding: margin!, child: card);
    return card;
  }
}
