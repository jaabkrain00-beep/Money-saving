import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';
import '../core/theme/app_palette.dart';

/// พื้นหลังครีมขาว (หรือกรมท่าม่วงใน Dark mode) พร้อม gradient blob จางๆ
/// ใช้ครั้งเดียวที่ MaterialApp.builder ให้ทุกหน้าใช้พื้นหลังเดียวกัน
class AppBackground extends StatelessWidget {
  const AppBackground({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final alpha = p.isDark ? 0.18 : 0.42;

    return Stack(
      fit: StackFit.expand,
      children: [
        DecoratedBox(decoration: BoxDecoration(color: p.background)),
        RepaintBoundary(
          child: IgnorePointer(
            child: Stack(
              children: [
                _Blob(
                  color: AppColors.brandA.withValues(alpha: alpha),
                  size: 320,
                  top: -110,
                  left: -90,
                ),
                _Blob(
                  color: AppColors.expenseA.withValues(alpha: alpha),
                  size: 280,
                  top: 220,
                  right: -120,
                ),
                _Blob(
                  color: AppColors.incomeA.withValues(alpha: alpha),
                  size: 300,
                  bottom: 120,
                  left: -130,
                ),
                _Blob(
                  color: AppColors.savingA.withValues(alpha: alpha),
                  size: 260,
                  bottom: -90,
                  right: -70,
                ),
              ],
            ),
          ),
        ),
        child,
      ],
    );
  }
}

class _Blob extends StatelessWidget {
  const _Blob({
    required this.color,
    required this.size,
    this.top,
    this.left,
    this.right,
    this.bottom,
  });

  final Color color;
  final double size;
  final double? top;
  final double? left;
  final double? right;
  final double? bottom;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: top,
      left: left,
      right: right,
      bottom: bottom,
      width: size,
      height: size,
      child: DecoratedBox(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [color, color.withValues(alpha: 0)],
          ),
        ),
      ),
    );
  }
}
