import 'package:flutter/material.dart';

import '../core/theme/app_palette.dart';

/// บังคับให้ลูกใช้ตัวอักษรสีเข้ม (ink) และพาเลตโหมดสว่าง
/// ใช้ภายในการ์ด gradient พาสเทล เพราะพื้นพาสเทลสว่างเสมอ แม้อยู่ใน Dark mode
class OnPastel extends StatelessWidget {
  const OnPastel({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    const p = AppPalette.light;
    return Theme(
      data: theme.copyWith(
        textTheme: theme.textTheme.apply(
          bodyColor: p.ink,
          displayColor: p.ink,
        ),
        iconTheme: IconThemeData(color: p.ink),
        extensions: const <ThemeExtension<dynamic>>[p],
      ),
      child: DefaultTextStyle.merge(
        style: TextStyle(color: p.ink),
        child: IconTheme.merge(
          data: IconThemeData(color: p.ink),
          child: child,
        ),
      ),
    );
  }
}
