import 'package:flutter/material.dart';

/// Snackbar พร้อมปุ่ม "เลิกทำ" (Undo) ใช้หลังลบรายการทุกชนิด
void showUndoSnackBar(
  BuildContext context, {
  required String message,
  required VoidCallback onUndo,
  Duration duration = const Duration(seconds: 6),
}) {
  showUndoSnackBarOn(
    ScaffoldMessenger.of(context),
    message: message,
    onUndo: onUndo,
    duration: duration,
  );
}

/// เหมือน [showUndoSnackBar] แต่รับ messenger ที่จับไว้ล่วงหน้า
/// ใช้เมื่อ widget ต้นทางอาจถูกถอดออกหลังลบ (เช่นแถวในรายการที่หายไปแล้ว)
void showUndoSnackBarOn(
  ScaffoldMessengerState messenger, {
  required String message,
  required VoidCallback onUndo,
  Duration duration = const Duration(seconds: 6),
}) {
  messenger
    ..clearSnackBars()
    ..showSnackBar(
      SnackBar(
        duration: duration,
        content: Text(message, maxLines: 2, overflow: TextOverflow.ellipsis),
        action: SnackBarAction(label: 'เลิกทำ', onPressed: onUndo),
      ),
    );
}

/// Snackbar ข้อความทั่วไป
void showAppSnackBar(BuildContext context, String message, {String? emoji}) {
  showAppSnackBarOn(ScaffoldMessenger.of(context), message, emoji: emoji);
}

void showAppSnackBarOn(
  ScaffoldMessengerState messenger,
  String message, {
  String? emoji,
}) {
  messenger
    ..clearSnackBars()
    ..showSnackBar(
      SnackBar(
        duration: const Duration(seconds: 3),
        content: Text(
          emoji == null ? message : '$emoji  $message',
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
      ),
    );
}
