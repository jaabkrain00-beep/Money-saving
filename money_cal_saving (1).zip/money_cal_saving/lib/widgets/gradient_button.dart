import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';
import '../core/theme/app_dimens.dart';
import '../core/theme/app_gradients.dart';
import 'pressable_scale.dart';

/// ปุ่ม gradient พาสเทล มีเงา ย่อตอนกด + haptic (สูงอย่างน้อย 48 dp)
class GradientButton extends StatelessWidget {
  const GradientButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.gradient = AppGradients.brand,
    this.expand = false,
    this.height = 52,
    this.loading = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final LinearGradient gradient;
  final bool expand;
  final double height;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null && !loading;

    final content = Row(
      mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (loading) ...[
          const SizedBox(
            width: 18,
            height: 18,
            child: CircularProgressIndicator(
              strokeWidth: 2.4,
              color: AppColors.ink,
            ),
          ),
          const SizedBox(width: 8),
        ] else if (icon != null) ...[
          Icon(icon, size: 20, color: AppColors.ink),
          const SizedBox(width: 8),
        ],
        Flexible(
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: AppColors.ink,
              height: 1.35,
            ),
          ),
        ),
      ],
    );

    final button = Opacity(
      opacity: enabled ? 1 : 0.5,
      child: Container(
        constraints: BoxConstraints(
          minHeight: math.max(height, AppSpacing.minTap),
          minWidth: AppSpacing.minTap,
        ),
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 8),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: gradient,
          borderRadius: BorderRadius.circular(AppRadius.pill),
          border: Border.all(color: Colors.white.withValues(alpha: 0.6)),
          boxShadow: AppShadows.soft(
            gradient.colors.first,
            opacity: 0.45,
            blur: 18,
            dy: 8,
          ),
        ),
        child: content,
      ),
    );

    return PressableScale(
      onTap: enabled ? onPressed : null,
      semanticLabel: label,
      child: expand
          ? SizedBox(width: double.infinity, child: button)
          : button,
    );
  }
}
