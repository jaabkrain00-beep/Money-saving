import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../core/theme/app_colors.dart';
import '../core/theme/app_dimens.dart';
import '../core/theme/app_gradients.dart';
import '../core/theme/app_palette.dart';
import 'pressable_scale.dart';

class NavItemData {
  const NavItemData({
    required this.icon,
    required this.activeIcon,
    required this.label,
  });

  final IconData icon;
  final IconData activeIcon;
  final String label;
}

/// Bottom Navigation ลอยแบบโค้งมน 4 แท็บ + ปุ่ม + ตรงกลาง
/// [items] ต้องมี 4 รายการ (หน้าแรก, รายรับ, รายจ่าย, สรุป)
/// [currentIndex] คือ index ใน items (0-3) ไม่รวมปุ่ม +
class FloatingNavBar extends StatelessWidget {
  const FloatingNavBar({
    super.key,
    required this.currentIndex,
    required this.items,
    required this.onSelected,
    required this.onAdd,
  }) : assert(items.length == 4, 'FloatingNavBar ต้องมี 4 แท็บ');

  final int currentIndex;
  final List<NavItemData> items;
  final ValueChanged<int> onSelected;
  final VoidCallback onAdd;

  static const double _addSize = 60;
  static const double _protrude = 24;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final borderRadius = BorderRadius.circular(32);

    Widget item(int i) => Expanded(
          child: _NavItem(
            data: items[i],
            selected: currentIndex == i,
            onTap: () => onSelected(i),
          ),
        );

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        child: MediaQuery.withClampedTextScaling(
          maxScaleFactor: 1.15,
          child: Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.topCenter,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: _protrude),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    borderRadius: borderRadius,
                    boxShadow: AppShadows.neutral(p, opacity: 0.28),
                  ),
                  child: ClipRRect(
                    borderRadius: borderRadius,
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          borderRadius: borderRadius,
                          border: Border.all(color: p.glassBorder),
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              p.surface.withValues(alpha: 0.9),
                              p.surface.withValues(alpha: 0.72),
                            ],
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 6),
                          child: Row(
                            children: [
                              item(0),
                              item(1),
                              const SizedBox(width: _addSize + 12),
                              item(2),
                              item(3),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 0,
                child: _AddButton(onTap: onAdd),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.data,
    required this.selected,
    required this.onTap,
  });

  final NavItemData data;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final color = selected ? p.ink : p.inkSoft;

    return PressableScale(
      onTap: onTap,
      semanticLabel: data.label,
      child: ConstrainedBox(
        constraints: const BoxConstraints(minHeight: 64),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedContainer(
                duration: AppDurations.normal,
                curve: Curves.easeOutCubic,
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                decoration: BoxDecoration(
                  gradient: selected
                      ? AppGradients.brand.scale(p.isDark ? 0.8 : 0.9)
                      : null,
                  borderRadius: BorderRadius.circular(AppRadius.r16),
                  boxShadow: selected
                      ? AppShadows.soft(AppColors.brandA,
                          opacity: 0.35, blur: 10, dy: 4)
                      : null,
                ),
                child: Icon(
                  selected ? data.activeIcon : data.icon,
                  size: 24,
                  color: selected ? AppColors.ink : color,
                ),
              ),
              const SizedBox(height: 2),
              FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  data.label,
                  maxLines: 1,
                  style: TextStyle(
                    fontSize: 12,
                    height: 1.3,
                    fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                    color: color,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AddButton extends StatelessWidget {
  const _AddButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return PressableScale(
      onTap: onTap,
      scale: 0.92,
      semanticLabel: 'เพิ่มรายการ',
      child: Container(
        width: FloatingNavBar._addSize,
        height: FloatingNavBar._addSize,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppColors.brandA, AppColors.brandB, AppColors.savingA],
          ),
          border: Border.all(color: Colors.white.withValues(alpha: 0.85), width: 3),
          boxShadow: AppShadows.soft(
            AppColors.brandB,
            opacity: 0.6,
            blur: 22,
            dy: 10,
          ),
        ),
        child: const Icon(
          PhosphorIconsBold.plus,
          size: 28,
          color: AppColors.ink,
        ),
      ),
    );
  }
}
