import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../core/theme/app_colors.dart';
import '../core/theme/app_gradients.dart';

enum ChipTone { unpaid, dueSoon, overdue, paid, waiting, received, info }

/// ป้ายสถานะแบบ gradient พาสเทล
/// ยังไม่จ่าย (ชมพู), ใกล้ครบกำหนด (ส้มพาสเทล), เลยกำหนด (แดงพาสเทล),
/// จ่ายแล้ว (เขียวมิ้นต์ + เครื่องหมายถูก)
class StatusChip extends StatelessWidget {
  const StatusChip({
    super.key,
    required this.label,
    required this.tone,
    this.icon,
  });

  const StatusChip.unpaid({super.key, this.label = 'ยังไม่จ่าย'})
      : tone = ChipTone.unpaid,
        icon = PhosphorIconsRegular.clock;

  const StatusChip.dueSoon({super.key, this.label = 'ใกล้ครบกำหนด'})
      : tone = ChipTone.dueSoon,
        icon = PhosphorIconsRegular.bellRinging;

  const StatusChip.overdue({super.key, this.label = 'เลยกำหนด'})
      : tone = ChipTone.overdue,
        icon = PhosphorIconsRegular.warningCircle;

  const StatusChip.paid({super.key, this.label = 'จ่ายแล้ว'})
      : tone = ChipTone.paid,
        icon = PhosphorIconsFill.checkCircle;

  const StatusChip.waiting({super.key, this.label = 'รอเงินเข้า'})
      : tone = ChipTone.waiting,
        icon = PhosphorIconsRegular.hourglassMedium;

  const StatusChip.received({super.key, this.label = 'ได้รับแล้ว'})
      : tone = ChipTone.received,
        icon = PhosphorIconsFill.checkCircle;

  const StatusChip.lastInstallment({super.key, this.label = 'งวดสุดท้าย'})
      : tone = ChipTone.info,
        icon = PhosphorIconsRegular.flag;

  final String label;
  final ChipTone tone;
  final IconData? icon;

  LinearGradient get _gradient {
    switch (tone) {
      case ChipTone.unpaid:
        return AppGradients.statusUnpaid;
      case ChipTone.dueSoon:
        return AppGradients.statusDueSoon;
      case ChipTone.overdue:
        return AppGradients.statusOverdue;
      case ChipTone.paid:
      case ChipTone.received:
        return AppGradients.statusPaid;
      case ChipTone.waiting:
        return AppGradients.statusWaiting;
      case ChipTone.info:
        return AppGradients.brand;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: const BoxConstraints(minHeight: 28),
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: _gradient,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: Colors.white.withValues(alpha: 0.6)),
          boxShadow: [
            BoxShadow(
              color: _gradient.colors.first.withValues(alpha: 0.35),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[
                Icon(icon, size: 14, color: AppColors.ink),
                const SizedBox(width: 4),
              ],
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.ink,
                    height: 1.35,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
