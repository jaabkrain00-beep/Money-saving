import 'dart:ui';

import 'package:flutter/material.dart';

import '../core/theme/app_dimens.dart';
import '../core/theme/app_palette.dart';
import 'pressable_scale.dart';

/// Glassmorphism บางๆ: โปร่งแสง + blur + ขอบขาวใส + เงานุ่ม
/// ให้ผลสวยเมื่ออยู่บนพื้นหลังที่มี blob หรือซ้อนบน GradientCard
class GlassCard extends StatelessWidget {
  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.margin,
    this.radius = AppRadius.card,
    this.blur = 18,
    this.onTap,
    this.tint,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry? margin;
  final double radius;
  final double blur;
  final VoidCallback? onTap;

  /// สีเจือจางของกระจก (ค่าเริ่มต้นขาว)
  final Color? tint;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final borderRadius = BorderRadius.circular(radius);
    final base = tint ?? Colors.white;

    Widget card = DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: borderRadius,
        boxShadow: AppShadows.neutral(p),
      ),
      child: ClipRRect(
        borderRadius: borderRadius,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
          child: DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: borderRadius,
              border: Border.all(color: p.glassBorder),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  base.withValues(alpha: p.isDark ? 0.14 : 0.55),
                  base.withValues(alpha: p.isDark ? 0.06 : 0.25),
                ],
              ),
            ),
            child: Padding(padding: padding, child: child),
          ),
        ),
      ),
    );

    if (onTap != null) {
      card = PressableScale(onTap: onTap, scale: 0.98, child: card);
    }
    if (margin != null) card = Padding(padding: margin!, child: card);
    return card;
  }
}
