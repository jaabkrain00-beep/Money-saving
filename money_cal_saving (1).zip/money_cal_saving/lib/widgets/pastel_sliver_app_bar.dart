import 'package:flutter/material.dart';

import '../core/theme/app_dimens.dart';
import '../core/theme/app_palette.dart';

/// SliverAppBar แบบ collapsing: หัวข้อใหญ่ยุบตัวเมื่อเลื่อน
/// ใช้เป็น sliver แรกของ CustomScrollView ทุกหน้าหลัก
class PastelSliverAppBar extends StatelessWidget {
  const PastelSliverAppBar({
    super.key,
    required this.title,
    this.actions = const [],
    this.leading,
    this.expandedHeight = 124,
  });

  final String title;
  final List<Widget> actions;
  final Widget? leading;
  final double expandedHeight;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final p = context.palette;

    return SliverAppBar(
      pinned: true,
      automaticallyImplyLeading: false,
      toolbarHeight: 64,
      expandedHeight: expandedHeight,
      backgroundColor: p.background.withValues(alpha: 0.92),
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      leading: leading,
      actions: [...actions, const SizedBox(width: AppSpacing.sm)],
      flexibleSpace: FlexibleSpaceBar(
        centerTitle: false,
        expandedTitleScale: 1.18,
        titlePadding: const EdgeInsetsDirectional.only(
          start: AppSpacing.screenH,
          end: 120,
          bottom: 16,
        ),
        title: Text(
          title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: theme.textTheme.titleLarge,
        ),
      ),
    );
  }
}
