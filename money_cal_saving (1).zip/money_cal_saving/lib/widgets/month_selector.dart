import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../core/theme/app_colors.dart';
import '../core/theme/app_dimens.dart';
import '../core/theme/app_gradients.dart';
import '../core/theme/app_palette.dart';
import '../core/utils/app_dates.dart';
import '../core/utils/haptics.dart';
import '../providers/month_provider.dart';
import 'glass_card.dart';
import 'pressable_scale.dart';

/// ตัวเลือกเดือน "‹ พฤษภาคม 2568 ›" ใช้ร่วมกันทุกหน้าผ่าน selectedMonthProvider
/// - กดลูกศรเพื่อเปลี่ยนเดือน
/// - แตะชื่อเดือนเพื่อเปิดตัวเลือกเดือน/ปี, กดค้างเพื่อกลับเดือนปัจจุบัน
class MonthSelector extends ConsumerWidget {
  const MonthSelector({
    super.key,
    this.padding = const EdgeInsets.symmetric(
      horizontal: AppSpacing.screenH,
      vertical: AppSpacing.sm,
    ),
  });

  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final key = ref.watch(selectedMonthProvider);
    final buddhist = ref.watch(useBuddhistYearProvider);
    final notifier = ref.read(selectedMonthProvider.notifier);
    final label = AppDates.formatMonthYearFromKey(key, buddhist: buddhist);
    final theme = Theme.of(context);

    return Padding(
      padding: padding,
      child: GlassCard(
        radius: AppRadius.r24,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: Row(
          children: [
            _ArrowButton(
              icon: PhosphorIconsBold.caretLeft,
              label: 'เดือนก่อนหน้า',
              onTap: () {
                Haptics.selection();
                notifier.previous();
              },
            ),
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => showMonthPickerSheet(context, ref),
                onLongPress: () {
                  Haptics.medium();
                  notifier.goToToday();
                },
                child: ConstrainedBox(
                  constraints:
                      const BoxConstraints(minHeight: AppSpacing.minTap),
                  child: Center(
                    child: AnimatedSwitcher(
                      duration: AppDurations.normal,
                      transitionBuilder: (child, animation) => FadeTransition(
                        opacity: animation,
                        child: ScaleTransition(
                          scale: Tween<double>(begin: 0.94, end: 1)
                              .animate(animation),
                          child: child,
                        ),
                      ),
                      child: Padding(
                        key: ValueKey(label),
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(
                            label,
                            maxLines: 1,
                            style: theme.textTheme.titleMedium
                                ?.copyWith(fontWeight: FontWeight.w700),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            _ArrowButton(
              icon: PhosphorIconsBold.caretRight,
              label: 'เดือนถัดไป',
              onTap: () {
                Haptics.selection();
                notifier.next();
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _ArrowButton extends StatelessWidget {
  const _ArrowButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return PressableScale(
      onTap: onTap,
      haptic: false,
      semanticLabel: label,
      child: SizedBox(
        width: AppSpacing.minTap,
        height: AppSpacing.minTap,
        child: Center(
          child: Icon(icon, size: 22, color: context.palette.ink),
        ),
      ),
    );
  }
}

/// ปัดซ้าย-ขวาเพื่อเปลี่ยนเดือน (ครอบเนื้อหาของหน้า)
/// รายการที่ใช้ Dismissible จะรับท่าปัดของตัวเองก่อน ส่วนพื้นที่อื่นปัดเปลี่ยนเดือนได้
class MonthSwipe extends ConsumerWidget {
  const MonthSwipe({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onHorizontalDragEnd: (details) {
        final v = details.primaryVelocity ?? 0;
        final notifier = ref.read(selectedMonthProvider.notifier);
        if (v < -350) {
          Haptics.selection();
          notifier.next();
        } else if (v > 350) {
          Haptics.selection();
          notifier.previous();
        }
      },
      child: child,
    );
  }
}

/// Bottom Sheet เลือกเดือน/ปี
Future<void> showMonthPickerSheet(BuildContext context, WidgetRef ref) {
  final buddhist = ref.read(useBuddhistYearProvider);
  var year = AppDates.parseKey(ref.read(selectedMonthProvider)).year;

  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (sheetContext) {
      return StatefulBuilder(
        builder: (context, setState) {
          final selected = AppDates.parseKey(ref.read(selectedMonthProvider));
          final theme = Theme.of(context);
          return SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.screenH,
                AppSpacing.xs,
                AppSpacing.screenH,
                AppSpacing.xl,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      IconButton(
                        tooltip: 'ปีก่อนหน้า',
                        onPressed: () => setState(() => year--),
                        icon: const Icon(PhosphorIconsBold.caretLeft),
                      ),
                      Expanded(
                        child: Center(
                          child: Text(
                            '${AppDates.displayYear(year, buddhist: buddhist)}',
                            style: theme.textTheme.titleMedium,
                          ),
                        ),
                      ),
                      IconButton(
                        tooltip: 'ปีถัดไป',
                        onPressed: () => setState(() => year++),
                        icon: const Icon(PhosphorIconsBold.caretRight),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    alignment: WrapAlignment.center,
                    children: [
                      for (var m = 1; m <= 12; m++)
                        _MonthChip(
                          label: AppDates.thaiMonthsShort[m - 1],
                          selected: selected.year == year && selected.month == m,
                          onTap: () {
                            ref
                                .read(selectedMonthProvider.notifier)
                                .set(AppDates.monthKeyOf(year, m));
                            Navigator.of(sheetContext).pop();
                          },
                        ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.md),
                  TextButton(
                    onPressed: () {
                      ref.read(selectedMonthProvider.notifier).goToToday();
                      Navigator.of(sheetContext).pop();
                    },
                    child: const Text('ไปเดือนปัจจุบัน'),
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}

class _MonthChip extends StatelessWidget {
  const _MonthChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return PressableScale(
      onTap: onTap,
      child: ConstrainedBox(
        constraints: const BoxConstraints(minWidth: 72, minHeight: 48),
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: selected ? AppGradients.brand : null,
            color: selected ? null : p.inputFill,
            borderRadius: BorderRadius.circular(AppRadius.r20),
            border: Border.all(
              color: selected
                  ? Colors.white.withValues(alpha: 0.7)
                  : Colors.transparent,
            ),
            boxShadow: selected
                ? AppShadows.soft(AppColors.brandA,
                    opacity: 0.4, blur: 12, dy: 5)
                : null,
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Center(
              widthFactor: 1,
              child: Text(
                label,
                maxLines: 1,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                  color: selected ? AppColors.ink : p.ink,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
