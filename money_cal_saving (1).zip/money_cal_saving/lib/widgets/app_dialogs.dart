import 'package:flutter/material.dart';

import '../core/theme/app_dimens.dart';
import '../core/theme/app_gradients.dart';
import '../core/theme/app_palette.dart';
import 'gradient_button.dart';

/// กล่องยืนยัน (ใช้กับการลบ) คืน true เมื่อกดยืนยัน
Future<bool> showConfirmDialog(
  BuildContext context, {
  required String title,
  String? message,
  String confirmLabel = 'ตกลง',
  String cancelLabel = 'ยกเลิก',
  bool destructive = false,
  String? emoji,
}) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) => _DialogShell(
      emoji: emoji ?? (destructive ? '🗑️' : '💬'),
      title: title,
      message: message,
      cancelLabel: cancelLabel,
      actions: [
        GradientButton(
          label: confirmLabel,
          expand: true,
          gradient: destructive ? AppGradients.expense : AppGradients.brand,
          onPressed: () => Navigator.of(ctx).pop(true),
        ),
      ],
    ),
  );
  return result ?? false;
}

/// ขอบเขตการแก้ไขรายการที่มาจากแม่แบบ (template)
enum EditScope { thisMonthOnly, fromThisMonth }

/// ถามว่าจะแก้ "เฉพาะเดือนนี้" หรือ "ตั้งแต่เดือนนี้เป็นต้นไป" (null = ยกเลิก)
Future<EditScope?> showEditScopeDialog(
  BuildContext context, {
  String title = 'ต้องการแก้ไขแบบไหน?',
  String? message = 'รายการนี้เป็นรายการประจำ เลือกขอบเขตที่จะให้การแก้ไขมีผล',
}) {
  return showDialog<EditScope>(
    context: context,
    builder: (ctx) => _DialogShell(
      emoji: '✏️',
      title: title,
      message: message,
      cancelLabel: 'ยกเลิก',
      actions: [
        GradientButton(
          label: 'เฉพาะเดือนนี้',
          expand: true,
          gradient: AppGradients.brand,
          onPressed: () => Navigator.of(ctx).pop(EditScope.thisMonthOnly),
        ),
        const SizedBox(height: AppSpacing.sm),
        GradientButton(
          label: 'ตั้งแต่เดือนนี้เป็นต้นไป',
          expand: true,
          gradient: AppGradients.saving,
          onPressed: () => Navigator.of(ctx).pop(EditScope.fromThisMonth),
        ),
      ],
    ),
  );
}

class _DialogShell extends StatelessWidget {
  const _DialogShell({
    required this.emoji,
    required this.title,
    required this.cancelLabel,
    required this.actions,
    this.message,
  });

  final String emoji;
  final String title;
  final String? message;
  final String cancelLabel;
  final List<Widget> actions;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final p = context.palette;

    return Dialog(
      backgroundColor: p.surface,
      surfaceTintColor: Colors.transparent,
      insetPadding:
          const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.r28),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(AppSpacing.xxl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Text(emoji, style: const TextStyle(fontSize: 40)),
            ),
            const SizedBox(height: AppSpacing.sm),
            Text(
              title,
              textAlign: TextAlign.center,
              style: theme.textTheme.titleMedium,
            ),
            if (message != null) ...[
              const SizedBox(height: AppSpacing.sm),
              Text(
                message!,
                textAlign: TextAlign.center,
                style:
                    theme.textTheme.bodyMedium?.copyWith(color: p.inkSoft),
              ),
            ],
            const SizedBox(height: AppSpacing.xl),
            ...actions,
            const SizedBox(height: AppSpacing.xs),
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(cancelLabel),
            ),
          ],
        ),
      ),
    );
  }
}
