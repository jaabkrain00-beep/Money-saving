import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// ขนาดตัวอักษรตามสเปก
/// หัวข้อใหญ่ 22-26, หัวข้อการ์ด 16-18, เนื้อหา 14-15, คำอธิบาย 12-13
class AppFontSize {
  AppFontSize._();

  static const double display = 26;
  static const double title = 22;
  static const double cardTitle = 17;
  static const double body = 14.5;
  static const double caption = 12.5;
}

class AppTypography {
  AppTypography._();

  static TextTheme textTheme({
    required Brightness brightness,
    required Color ink,
    required Color inkSoft,
  }) {
    final base = GoogleFonts.notoSansThaiTextTheme(
      ThemeData(brightness: brightness).textTheme,
    );

    TextStyle? s(
      TextStyle? t,
      double size,
      FontWeight weight, {
      double height = 1.45,
      Color? color,
    }) {
      return t?.copyWith(
        fontSize: size,
        fontWeight: weight,
        height: height,
        color: color ?? ink,
      );
    }

    return base.copyWith(
      displaySmall: s(base.displaySmall, 28, FontWeight.w700, height: 1.3),
      headlineMedium:
          s(base.headlineMedium, AppFontSize.display, FontWeight.w700, height: 1.3),
      headlineSmall: s(base.headlineSmall, 24, FontWeight.w700, height: 1.3),
      titleLarge:
          s(base.titleLarge, AppFontSize.title, FontWeight.w700, height: 1.35),
      titleMedium: s(base.titleMedium, AppFontSize.cardTitle, FontWeight.w600,
          height: 1.4),
      titleSmall: s(base.titleSmall, 15, FontWeight.w600, height: 1.4),
      bodyLarge: s(base.bodyLarge, 15, FontWeight.w400),
      bodyMedium: s(base.bodyMedium, AppFontSize.body, FontWeight.w400),
      bodySmall: s(base.bodySmall, AppFontSize.caption, FontWeight.w400,
          color: inkSoft),
      labelLarge: s(base.labelLarge, 14, FontWeight.w600),
      labelMedium: s(base.labelMedium, 13, FontWeight.w500),
      labelSmall:
          s(base.labelSmall, 12, FontWeight.w500, color: inkSoft),
    );
  }
}
