import 'package:flutter/material.dart';

/// สีทั้งหมดของแอป (พาเลตพาสเทลตามสเปก)
class AppColors {
  AppColors._();

  // ตัวอักษร (ห้ามใช้ดำสนิท)
  static const Color ink = Color(0xFF3D3D4E);
  static const Color inkSoft = Color(0xFF6E6E82);

  // พื้นหลัง
  static const Color cream = Color(0xFFFFF9F5);
  static const Color darkBg = Color(0xFF1E1B33);
  static const Color darkSurface = Color(0xFF2A2646);
  static const Color darkSurfaceAlt = Color(0xFF353059);
  static const Color darkInk = Color(0xFFF2EFFF);
  static const Color darkInkSoft = Color(0xFFB7B1D6);

  // รายรับ: เขียวมิ้นต์
  static const Color incomeA = Color(0xFFA8E6CF);
  static const Color incomeB = Color(0xFFDCEDC1);

  // รายจ่าย: ชมพูพีช
  static const Color expenseA = Color(0xFFFFB7B2);
  static const Color expenseB = Color(0xFFFFDAC1);

  // เงินออม: ม่วงลาเวนเดอร์
  static const Color savingA = Color(0xFFC3B1E1);
  static const Color savingB = Color(0xFFE2D5F8);

  // หลัก/แบรนด์: ฟ้าพาสเทล
  static const Color brandA = Color(0xFFA0C4FF);
  static const Color brandB = Color(0xFFBDB2FF);
  static const Color brandStrong = Color(0xFF7B9CFF);

  // สถานะ
  static const Color dueSoonA = Color(0xFFFFD8A8); // ส้มพาสเทล
  static const Color dueSoonB = Color(0xFFFFE9C7);
  static const Color overdueA = Color(0xFFFF9AA8); // แดงพาสเทล
  static const Color overdueB = Color(0xFFFFC2C9);

  // สีตัวอักษรเน้น (เข้มพอให้อ่านง่ายบนพื้นพาสเทลและพื้นเข้ม)
  static const Color dangerInk = Color(0xFFD94F6B);
  static const Color successInk = Color(0xFF2E9E78);
  static const Color warningInk = Color(0xFFD9822B);

  /// สีประจำตัวสมาชิก/หมวดหมู่ให้เลือก
  static const List<Color> pickerColors = [
    Color(0xFFFFB7B2),
    Color(0xFFFFC8A2),
    Color(0xFFFFE5A0),
    Color(0xFFA8E6CF),
    Color(0xFF9EE0E6),
    Color(0xFFA0C4FF),
    Color(0xFFBDB2FF),
    Color(0xFFC3B1E1),
    Color(0xFFF4B6DB),
    Color(0xFFD5C4A1),
  ];
}
