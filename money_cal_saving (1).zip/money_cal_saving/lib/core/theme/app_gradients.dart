import 'package:flutter/material.dart';

import 'app_colors.dart';

enum AmountKind { income, expense, saving, brand }

/// Gradient พาสเทลทั้งหมด (ห้ามใช้พื้นสีทึบแบนๆ)
class AppGradients {
  AppGradients._();

  static const Alignment _begin = Alignment.topLeft;
  static const Alignment _end = Alignment.bottomRight;

  static const LinearGradient income = LinearGradient(
    begin: _begin,
    end: _end,
    colors: [AppColors.incomeA, AppColors.incomeB],
  );

  static const LinearGradient expense = LinearGradient(
    begin: _begin,
    end: _end,
    colors: [AppColors.expenseA, AppColors.expenseB],
  );

  static const LinearGradient saving = LinearGradient(
    begin: _begin,
    end: _end,
    colors: [AppColors.savingA, AppColors.savingB],
  );

  static const LinearGradient brand = LinearGradient(
    begin: _begin,
    end: _end,
    colors: [AppColors.brandA, AppColors.brandB],
  );

  /// การ์ดใหญ่หน้าแรก (3 สี)
  static const LinearGradient hero = LinearGradient(
    begin: _begin,
    end: _end,
    colors: [AppColors.brandA, AppColors.brandB, AppColors.savingB],
  );

  // สถานะรายจ่าย/รายรับ
  static const LinearGradient statusUnpaid = expense;
  static const LinearGradient statusDueSoon = LinearGradient(
    begin: _begin,
    end: _end,
    colors: [AppColors.dueSoonA, AppColors.dueSoonB],
  );
  static const LinearGradient statusOverdue = LinearGradient(
    begin: _begin,
    end: _end,
    colors: [AppColors.overdueA, AppColors.overdueB],
  );
  static const LinearGradient statusPaid = income;
  static const LinearGradient statusWaiting = saving;

  static LinearGradient forKind(AmountKind kind) {
    switch (kind) {
      case AmountKind.income:
        return income;
      case AmountKind.expense:
        return expense;
      case AmountKind.saving:
        return saving;
      case AmountKind.brand:
        return brand;
    }
  }

  /// สร้าง gradient จากสีเดียว (สีสมาชิก/หมวดหมู่/เป้าหมาย)
  static LinearGradient fromColor(Color base, {double lighten = 0.55}) {
    return LinearGradient(
      begin: _begin,
      end: _end,
      colors: [base, Color.lerp(base, Colors.white, lighten)!],
    );
  }
}
