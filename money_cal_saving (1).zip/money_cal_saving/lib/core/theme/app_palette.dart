import 'package:flutter/material.dart';

import 'app_colors.dart';

/// สีที่เปลี่ยนตามโหมดสว่าง/มืด เข้าถึงด้วย `context.palette`
@immutable
class AppPalette extends ThemeExtension<AppPalette> {
  const AppPalette({
    required this.isDark,
    required this.ink,
    required this.inkSoft,
    required this.background,
    required this.surface,
    required this.inputFill,
    required this.glassBorder,
    required this.divider,
    required this.shadow,
  });

  final bool isDark;
  final Color ink;
  final Color inkSoft;
  final Color background;
  final Color surface;
  final Color inputFill;
  final Color glassBorder;
  final Color divider;
  final Color shadow;

  static const AppPalette light = AppPalette(
    isDark: false,
    ink: AppColors.ink,
    inkSoft: AppColors.inkSoft,
    background: AppColors.cream,
    surface: Color(0xFFFFFDFB),
    inputFill: Color(0xFFF6F1FF),
    glassBorder: Color(0xB3FFFFFF),
    divider: Color(0x143D3D4E),
    shadow: Color(0xFF9C8FD8),
  );

  static const AppPalette dark = AppPalette(
    isDark: true,
    ink: AppColors.darkInk,
    inkSoft: AppColors.darkInkSoft,
    background: AppColors.darkBg,
    surface: AppColors.darkSurface,
    inputFill: AppColors.darkSurfaceAlt,
    glassBorder: Color(0x2EFFFFFF),
    divider: Color(0x1AFFFFFF),
    shadow: Color(0xFF0F0D1F),
  );

  @override
  AppPalette copyWith({
    bool? isDark,
    Color? ink,
    Color? inkSoft,
    Color? background,
    Color? surface,
    Color? inputFill,
    Color? glassBorder,
    Color? divider,
    Color? shadow,
  }) {
    return AppPalette(
      isDark: isDark ?? this.isDark,
      ink: ink ?? this.ink,
      inkSoft: inkSoft ?? this.inkSoft,
      background: background ?? this.background,
      surface: surface ?? this.surface,
      inputFill: inputFill ?? this.inputFill,
      glassBorder: glassBorder ?? this.glassBorder,
      divider: divider ?? this.divider,
      shadow: shadow ?? this.shadow,
    );
  }

  @override
  AppPalette lerp(ThemeExtension<AppPalette>? other, double t) {
    if (other is! AppPalette) return this;
    return AppPalette(
      isDark: t < 0.5 ? isDark : other.isDark,
      ink: Color.lerp(ink, other.ink, t)!,
      inkSoft: Color.lerp(inkSoft, other.inkSoft, t)!,
      background: Color.lerp(background, other.background, t)!,
      surface: Color.lerp(surface, other.surface, t)!,
      inputFill: Color.lerp(inputFill, other.inputFill, t)!,
      glassBorder: Color.lerp(glassBorder, other.glassBorder, t)!,
      divider: Color.lerp(divider, other.divider, t)!,
      shadow: Color.lerp(shadow, other.shadow, t)!,
    );
  }
}

extension AppPaletteContext on BuildContext {
  AppPalette get palette =>
      Theme.of(this).extension<AppPalette>() ?? AppPalette.light;
}
