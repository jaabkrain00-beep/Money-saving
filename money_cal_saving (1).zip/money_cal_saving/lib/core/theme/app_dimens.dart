import 'package:flutter/material.dart';

import 'app_palette.dart';

/// ระยะห่างมาตรฐาน
class AppSpacing {
  AppSpacing._();

  static const double xs = 4;
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 20;
  static const double xxl = 24;
  static const double huge = 32;

  /// padding ขอบจอซ้าย-ขวา (ขั้นต่ำ 16-20)
  static const double screenH = 20;

  /// ระยะเผื่อด้านล่างให้ Floating Bottom Nav
  static const double navBarClearance = 124;

  /// ขนาดพื้นที่กดขั้นต่ำ
  static const double minTap = 48;
}

/// มุมโค้ง 20-28 dp
class AppRadius {
  AppRadius._();

  static const double r16 = 16;
  static const double r20 = 20;
  static const double r24 = 24;
  static const double r28 = 28;
  static const double card = r24;
  static const double sheet = r28;
  static const double pill = 999;
}

class AppDurations {
  AppDurations._();

  static const Duration fast = Duration(milliseconds: 150);
  static const Duration normal = Duration(milliseconds: 300);
  static const Duration slow = Duration(milliseconds: 600);
  static const Duration counter = Duration(milliseconds: 700);
  static const Duration chart = Duration(milliseconds: 900);
}

/// เงานุ่มๆ (ไม่ดำเข้ม)
class AppShadows {
  AppShadows._();

  static List<BoxShadow> soft(
    Color color, {
    double opacity = 0.3,
    double blur = 24,
    double dy = 10,
    double spread = -2,
  }) {
    return [
      BoxShadow(
        color: color.withValues(alpha: opacity),
        blurRadius: blur,
        offset: Offset(0, dy),
        spreadRadius: spread,
      ),
    ];
  }

  static List<BoxShadow> neutral(AppPalette p, {double opacity = 0.16}) {
    return soft(p.shadow, opacity: p.isDark ? 0.35 : opacity, blur: 20, dy: 8);
  }
}
