/// คณิตศาสตร์จำนวนเต็มสำหรับเปอร์เซ็นต์และการหาร (ไม่ใช้ double กับยอดเงิน)
class IntMath {
  IntMath._();

  /// หารแล้วปัดเศษแบบใกล้สุด (0.5 ปัดออกจากศูนย์) [b] ต้องมากกว่า 0
  static int roundedDiv(int a, int b) {
    assert(b > 0);
    if (a >= 0) return (2 * a + b) ~/ (2 * b);
    return -((-2 * a + b) ~/ (2 * b));
  }

  /// หารแล้วปัดขึ้น ([a] >= 0, [b] > 0)
  static int ceilDiv(int a, int b) {
    assert(a >= 0 && b > 0);
    return (a + b - 1) ~/ b;
  }

  /// สัดส่วนเป็นเปอร์เซ็นต์ (ปัดใกล้สุด) คืน 0 ถ้า [whole] <= 0
  static int percentOf(int part, int whole) {
    if (whole <= 0) return 0;
    return roundedDiv(part * 100, whole);
  }

  /// เปลี่ยนแปลงจาก [previous] เป็น [current] เป็นเปอร์เซ็นต์ (ปัดใกล้สุด)
  /// คืน null ถ้า [previous] <= 0 (เทียบไม่ได้)
  static int? percentChange(int previous, int current) {
    if (previous <= 0) return null;
    return roundedDiv((current - previous) * 100, previous);
  }
}
