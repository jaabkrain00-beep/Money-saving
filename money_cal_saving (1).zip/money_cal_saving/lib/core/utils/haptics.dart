import 'package:flutter/services.dart';

/// Haptic feedback ตอนกดปุ่ม/เปลี่ยนค่า
class Haptics {
  Haptics._();

  static void light() => HapticFeedback.lightImpact();
  static void medium() => HapticFeedback.mediumImpact();
  static void heavy() => HapticFeedback.heavyImpact();
  static void selection() => HapticFeedback.selectionClick();
}
