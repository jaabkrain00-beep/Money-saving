import '../../data/db/app_database.dart';

/// ชื่อที่ใช้แสดงของสมาชิก (ชื่อเล่นก่อน) — null คือ "ส่วนกลาง"
String memberLabel(Member? member) {
  if (member == null) return 'ส่วนกลาง';
  final nick = member.nickname.trim();
  return nick.isNotEmpty ? nick : member.name;
}

/// อีโมจิสำหรับแสดงเป็นไอคอนเล็กๆ ของสมาชิก (รูปจากเครื่องใช้ 🙂 แทน)
String memberEmoji(Member? member) {
  if (member == null) return '🏠';
  final a = member.avatar;
  return a.startsWith('file:') ? '🙂' : a;
}
