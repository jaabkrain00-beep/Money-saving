import 'package:flutter/services.dart';

/// ช่องกรอกจำนวนเงิน: รับเฉพาะตัวเลขและจุดทศนิยม (ไม่เกิน 2 ตำแหน่ง)
/// ใส่ลูกน้ำคั่นหลักพันให้อัตโนมัติ
/// ใช้คู่กับ keyboardType: TextInputType.numberWithOptions(decimal: true)
class AmountInputFormatter extends TextInputFormatter {
  AmountInputFormatter({this.maxIntDigits = 10});

  final int maxIntDigits;

  static bool _isDigit(String c) =>
      c.codeUnitAt(0) >= 48 && c.codeUnitAt(0) <= 57;

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final raw = newValue.text;
    if (raw.isEmpty) return newValue.copyWith(text: '');

    final cursor = newValue.selection.baseOffset.clamp(0, raw.length);
    final cursorAtEnd = cursor >= raw.length;

    // กรองให้เหลือเฉพาะตัวเลขและจุดแรกจุดเดียว ทศนิยมไม่เกิน 2 หลัก
    final intDigits = StringBuffer();
    final fracDigits = StringBuffer();
    var seenDot = false;
    var keptBeforeCursor = 0;

    for (var i = 0; i < raw.length; i++) {
      final c = raw[i];
      var kept = false;
      if (c == '.') {
        if (!seenDot) {
          seenDot = true;
          kept = true;
        }
      } else if (_isDigit(c)) {
        if (!seenDot) {
          if (intDigits.length < maxIntDigits) {
            intDigits.write(c);
            kept = true;
          }
        } else if (fracDigits.length < 2) {
          fracDigits.write(c);
          kept = true;
        }
      }
      if (kept && i < cursor) keptBeforeCursor++;
    }

    var intText = intDigits.toString().replaceFirst(RegExp(r'^0+(?=\d)'), '');
    if (intText.isEmpty && seenDot) intText = '0';

    final formattedInt = _group(intText);
    final text = seenDot ? '$formattedInt.$fracDigits' : formattedInt;

    if (cursorAtEnd) {
      return TextEditingValue(
        text: text,
        selection: TextSelection.collapsed(offset: text.length),
      );
    }

    // คำนวณตำแหน่งเคอร์เซอร์ใหม่จากจำนวน "ตัวที่มีความหมาย" ก่อนเคอร์เซอร์
    var count = 0;
    var offset = 0;
    while (offset < text.length && count < keptBeforeCursor) {
      if (text[offset] != ',') count++;
      offset++;
    }
    return TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: offset),
    );
  }

  static String _group(String digits) {
    final buffer = StringBuffer();
    for (var i = 0; i < digits.length; i++) {
      if (i > 0 && (digits.length - i) % 3 == 0) buffer.write(',');
      buffer.write(digits[i]);
    }
    return buffer.toString();
  }
}
