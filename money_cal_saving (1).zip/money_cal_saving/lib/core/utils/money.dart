/// ฟังก์ชันเกี่ยวกับเงิน: เก็บเป็น "สตางค์" (int) เสมอ ห้ามใช้ double คำนวณ
/// แปลงเป็นบาทเฉพาะตอนแสดงผลเท่านั้น
class Money {
  Money._();

  static const int satangPerBaht = 100;

  static int fromBaht(int baht) => baht * satangPerBaht;

  /// จัดรูปแบบ 1,234.50 (ติดลบเป็น -1,234.50)
  /// [symbol] เติม ฿ ด้านหน้า, [signed] แสดง + สำหรับค่าบวก
  static String format(int satang, {bool symbol = false, bool signed = false}) {
    final negative = satang < 0;
    final abs = negative ? -satang : satang;
    final baht = abs ~/ satangPerBaht;
    final sat = abs % satangPerBaht;
    final text = '${_group(baht)}.${sat.toString().padLeft(2, '0')}';
    final sign = negative ? '-' : (signed && satang > 0 ? '+' : '');
    return '$sign${symbol ? '฿' : ''}$text';
  }

  /// ข้อความสำหรับใส่ในช่องกรอก: "1,234" หรือ "1,234.50"
  static String toInputText(int satang) {
    if (satang % satangPerBaht == 0) {
      return _group(satang.abs() ~/ satangPerBaht);
    }
    return format(satang.abs());
  }

  /// แบบย่อสำหรับแกนกราฟ: 1.2K, 3.4M (ใช้เลขจำนวนเต็มล้วน)
  static String formatCompact(int satang) {
    final negative = satang < 0;
    final baht = (negative ? -satang : satang) ~/ satangPerBaht;
    String body;
    if (baht >= 1000000) {
      body = '${_oneDecimal(baht, 1000000, 100000)}M';
    } else if (baht >= 1000) {
      body = '${_oneDecimal(baht, 1000, 100)}K';
    } else {
      body = baht.toString();
    }
    return negative ? '-$body' : body;
  }

  /// แปลงข้อความที่ผู้ใช้กรอก (มีลูกน้ำ/฿ ได้) เป็นสตางค์
  /// คืน null ถ้ารูปแบบไม่ถูกต้อง (ทศนิยมได้ไม่เกิน 2 ตำแหน่ง)
  static int? parse(String input) {
    final cleaned = input.replaceAll(RegExp(r'[,\s฿]'), '');
    final match = RegExp(r'^(\d*)(?:\.(\d{0,2}))?$').firstMatch(cleaned);
    if (match == null) return null;
    final intPart = match.group(1) ?? '';
    final fracPart = match.group(2) ?? '';
    if (intPart.isEmpty && fracPart.isEmpty) return null;
    if (intPart.length > 12) return null; // กันค่าใหญ่เกินจริง
    final baht = intPart.isEmpty ? 0 : int.parse(intPart);
    final sat = fracPart.isEmpty ? 0 : int.parse(fracPart.padRight(2, '0'));
    return baht * satangPerBaht + sat;
  }

  static String _oneDecimal(int baht, int unit, int tenthUnit) {
    final whole = baht ~/ unit;
    final tenth = (baht % unit) ~/ tenthUnit;
    return tenth == 0 ? '$whole' : '$whole.$tenth';
  }

  static String _group(int n) {
    final s = n.toString();
    final buffer = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buffer.write(',');
      buffer.write(s[i]);
    }
    return buffer.toString();
  }
}
