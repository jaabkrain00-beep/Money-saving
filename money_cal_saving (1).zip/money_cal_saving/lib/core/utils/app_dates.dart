/// ฟังก์ชันวันที่/เดือน (ไม่พึ่ง intl เพื่อให้ผลลัพธ์คงที่และทดสอบง่าย)
/// monthKey รูปแบบ "yyyy-MM" (ค.ศ.) ใช้เป็นคีย์ของเดือนทั้งแอป
class AppDates {
  AppDates._();

  static const List<String> thaiMonths = [
    'มกราคม',
    'กุมภาพันธ์',
    'มีนาคม',
    'เมษายน',
    'พฤษภาคม',
    'มิถุนายน',
    'กรกฎาคม',
    'สิงหาคม',
    'กันยายน',
    'ตุลาคม',
    'พฤศจิกายน',
    'ธันวาคม',
  ];

  static const List<String> thaiMonthsShort = [
    'ม.ค.',
    'ก.พ.',
    'มี.ค.',
    'เม.ย.',
    'พ.ค.',
    'มิ.ย.',
    'ก.ค.',
    'ส.ค.',
    'ก.ย.',
    'ต.ค.',
    'พ.ย.',
    'ธ.ค.',
  ];

  /// index 0 = จันทร์ (ตรงกับ DateTime.weekday - 1)
  static const List<String> thaiWeekdays = [
    'จันทร์',
    'อังคาร',
    'พุธ',
    'พฤหัสบดี',
    'ศุกร์',
    'เสาร์',
    'อาทิตย์',
  ];

  static const List<String> thaiWeekdaysShort = [
    'จ.',
    'อ.',
    'พ.',
    'พฤ.',
    'ศ.',
    'ส.',
    'อา.',
  ];

  // ---------- monthKey ----------

  static String monthKeyOf(int year, int month) =>
      '${year.toString().padLeft(4, '0')}-${month.toString().padLeft(2, '0')}';

  static String monthKey(DateTime d) => monthKeyOf(d.year, d.month);

  static ({int year, int month}) parseKey(String key) {
    final parts = key.split('-');
    return (year: int.parse(parts[0]), month: int.parse(parts[1]));
  }

  static DateTime firstOfMonth(String key) {
    final k = parseKey(key);
    return DateTime(k.year, k.month, 1);
  }

  static int _index(String key) {
    final k = parseKey(key);
    return k.year * 12 + (k.month - 1);
  }

  static String addMonths(String key, int n) {
    final idx = _index(key) + n;
    return monthKeyOf(idx ~/ 12, idx % 12 + 1);
  }

  /// จำนวนเดือนจาก [from] ถึง [to] (to - from)
  static int monthsBetween(String from, String to) => _index(to) - _index(from);

  /// รายการ monthKey จาก [from] ถึง [to] รวมหัวท้าย
  static List<String> monthRange(String from, String to) {
    final n = monthsBetween(from, to);
    if (n < 0) return const [];
    return [for (var i = 0; i <= n; i++) addMonths(from, i)];
  }

  /// [count] เดือนที่ลงท้ายที่ [end] เรียงจากเก่าไปใหม่
  static List<String> monthsBack(String end, int count) {
    return [for (var i = count - 1; i >= 0; i--) addMonths(end, -i)];
  }

  // ---------- วันในเดือน ----------

  static bool isLeapYear(int year) =>
      (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;

  static int daysInMonth(int year, int month) => DateTime(year, month + 1, 0).day;

  /// วันที่ [day] ของเดือน [key] ถ้าเกินจำนวนวันของเดือน ใช้วันสุดท้ายของเดือนแทน
  /// (เช่น 31 ในเดือน ก.พ. -> 28/29)
  static DateTime dateInMonth(String key, int day) {
    final k = parseKey(key);
    final last = daysInMonth(k.year, k.month);
    final d = day < 1 ? 1 : (day > last ? last : day);
    return DateTime(k.year, k.month, d);
  }

  static DateTime dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

  /// จำนวนวันจาก [from] ถึง [to] (to - from) นับตามปฏิทิน
  static int daysBetween(DateTime from, DateTime to) {
    final a = DateTime.utc(from.year, from.month, from.day);
    final b = DateTime.utc(to.year, to.month, to.day);
    return b.difference(a).inDays;
  }

  // ---------- การแสดงผล ----------

  static int displayYear(int year, {required bool buddhist}) =>
      buddhist ? year + 543 : year;

  /// "พฤษภาคม 2568"
  static String formatMonthYear(int year, int month, {required bool buddhist}) =>
      '${thaiMonths[month - 1]} ${displayYear(year, buddhist: buddhist)}';

  static String formatMonthYearFromKey(String key, {required bool buddhist}) {
    final k = parseKey(key);
    return formatMonthYear(k.year, k.month, buddhist: buddhist);
  }

  /// "พ.ค. 2568"
  static String formatShortMonthYear(String key, {required bool buddhist}) {
    final k = parseKey(key);
    return '${thaiMonthsShort[k.month - 1]} ${displayYear(k.year, buddhist: buddhist)}';
  }

  /// "5 พ.ค." หรือ "5 พ.ค. 2568"
  static String formatDayMonth(
    DateTime d, {
    bool withYear = false,
    bool buddhist = true,
  }) {
    final base = '${d.day} ${thaiMonthsShort[d.month - 1]}';
    return withYear ? '$base ${displayYear(d.year, buddhist: buddhist)}' : base;
  }

  /// "วันพฤหัสบดีที่ 5 พฤษภาคม 2568"
  static String formatFullDate(DateTime d, {bool buddhist = true}) =>
      'วัน${thaiWeekdays[d.weekday - 1]}ที่ ${d.day} ${thaiMonths[d.month - 1]} '
      '${displayYear(d.year, buddhist: buddhist)}';

  /// "HH:mm"
  static String formatTime(int hour, int minute) =>
      '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';

  static String greeting(DateTime now) {
    final h = now.hour;
    if (h < 5) return 'สวัสดีตอนดึก 🌙';
    if (h < 12) return 'สวัสดีตอนเช้า ☀️';
    if (h < 17) return 'สวัสดีตอนบ่าย 🌤️';
    if (h < 20) return 'สวัสดีตอนเย็น 🌇';
    return 'สวัสดีตอนค่ำ 🌙';
  }
}
