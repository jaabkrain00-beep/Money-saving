import 'package:drift/drift.dart';

import '../core/utils/app_dates.dart';
import '../data/db/app_database.dart';
import 'template_rules.dart';

/// สร้างรายการประจำเดือน (instance) จากแม่แบบ — ฟังก์ชันล้วน ไม่แตะฐานข้อมูล
///
/// กติกา:
/// - สร้างเฉพาะแม่แบบที่ active ในเดือนนั้น (startMonth <= เดือน <= เดือนสุดท้าย)
/// - ห้ามสร้างซ้ำ: [existingTemplateIds] ต้องรวมแม่แบบที่มีแถวในเดือนนั้นอยู่แล้ว
///   รวมถึงแถวที่ถูกลบเฉพาะเดือน (isSkipped) ด้วย
/// - วันที่เกินจำนวนวันของเดือนใช้วันสุดท้ายของเดือน (31 -> 30/28/29)
/// - สถานะเริ่มต้นคือ "ยังไม่จ่าย" / "รอเงินเข้า" เสมอ
class MonthlyGenerator {
  MonthlyGenerator._();

  static List<IncomeEntriesCompanion> incomeToCreate({
    required String monthKey,
    required Iterable<IncomeTemplate> templates,
    required Set<int> existingTemplateIds,
  }) {
    final result = <IncomeEntriesCompanion>[];
    for (final t in templates) {
      if (existingTemplateIds.contains(t.id)) continue;
      if (!TemplateRules.isActiveIn(
        monthKey,
        startMonth: t.startMonth,
        endMonth: t.endMonth,
      )) {
        continue;
      }
      result.add(
        IncomeEntriesCompanion.insert(
          templateId: Value(t.id),
          name: t.name,
          amountSatang: t.amountSatang,
          memberId: Value(t.memberId),
          date: AppDates.dateInMonth(monthKey, t.dayOfMonth),
          monthKey: monthKey,
          categoryId: Value(t.categoryId),
          note: Value(t.note),
        ),
      );
    }
    return result;
  }

  static List<ExpenseEntriesCompanion> expenseToCreate({
    required String monthKey,
    required Iterable<ExpenseTemplate> templates,
    required Set<int> existingTemplateIds,
  }) {
    final result = <ExpenseEntriesCompanion>[];
    for (final t in templates) {
      if (existingTemplateIds.contains(t.id)) continue;
      if (!TemplateRules.isActiveIn(
        monthKey,
        startMonth: t.startMonth,
        endMonth: t.endMonth,
        totalInstallments: t.totalInstallments,
      )) {
        continue;
      }
      result.add(
        ExpenseEntriesCompanion.insert(
          templateId: Value(t.id),
          name: t.name,
          amountSatang: t.amountSatang,
          memberId: Value(t.memberId),
          dueDate: AppDates.dateInMonth(monthKey, t.dueDay),
          monthKey: monthKey,
          categoryId: Value(t.categoryId),
          note: Value(t.note),
        ),
      );
    }
    return result;
  }

  /// templateId ที่มีแถวอยู่แล้วในเดือน (รวม tombstone)
  static Set<int> incomeTemplateIds(Iterable<IncomeEntry> entries) => {
        for (final e in entries)
          if (e.templateId != null) e.templateId!,
      };

  static Set<int> expenseTemplateIds(Iterable<ExpenseEntry> entries) => {
        for (final e in entries)
          if (e.templateId != null) e.templateId!,
      };
}
