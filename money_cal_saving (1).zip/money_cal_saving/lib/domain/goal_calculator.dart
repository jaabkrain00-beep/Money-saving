import '../core/utils/app_dates.dart';
import '../core/utils/int_math.dart';
import '../data/db/app_database.dart';

class GoalProgress {
  const GoalProgress({
    required this.saved,
    required this.target,
    required this.remaining,
    required this.percent,
    required this.isReached,
  });

  final int saved;
  final int target;

  /// ยอดที่ยังขาด (ไม่ติดลบ)
  final int remaining;

  /// เปอร์เซ็นต์ 0-100 ปัดลง (ขึ้น 100 ก็ต่อเมื่อครบเป้าหมายจริง)
  final int percent;
  final bool isReached;

  /// สัดส่วน 0.0-1.0 สำหรับวาดวงแหวน/แถบเท่านั้น (ใช้แสดงผล ไม่ใช้คำนวณเงิน)
  double get fraction {
    if (target <= 0) return 0;
    final f = saved / target;
    return f < 0 ? 0 : (f > 1 ? 1 : f);
  }
}

class MonthlyPlan {
  const MonthlyPlan({
    required this.perMonthSatang,
    required this.months,
    required this.overdue,
  });

  /// ต้องออมเดือนละเท่าไร (ปัดขึ้นเป็นสตางค์ เพื่อให้ทันกำหนดแน่นอน)
  final int perMonthSatang;

  /// จำนวนเดือนที่เหลือ (นับรวมเดือนปัจจุบัน)
  final int months;

  /// เลยวันที่ต้องการแล้ว
  final bool overdue;
}

class GoalCalculator {
  GoalCalculator._();

  /// ยอดออมสุทธิ = Σ ฝาก − Σ ถอน
  static int balance(Iterable<SavingTransaction> transactions) {
    var total = 0;
    for (final t in transactions) {
      total += t.type == SavingTxType.deposit ? t.amountSatang : -t.amountSatang;
    }
    return total;
  }

  static GoalProgress progress({required int saved, required int target}) {
    final remaining = target - saved;
    final reached = target > 0 && saved >= target;
    int percent;
    if (target <= 0 || saved <= 0) {
      percent = 0;
    } else if (reached) {
      percent = 100;
    } else {
      percent = (saved * 100) ~/ target;
    }
    return GoalProgress(
      saved: saved,
      target: target,
      remaining: remaining < 0 ? 0 : remaining,
      percent: percent,
      isReached: reached,
    );
  }

  /// เป้าหมายควรอยู่ในสถานะ "สำเร็จแล้ว" หรือไม่
  /// (ถอนจนต่ำกว่าเป้าหมาย -> กลับมาเป็นยังไม่สำเร็จ)
  static bool shouldBeCompleted({required int saved, required int target}) =>
      target > 0 && saved >= target;

  /// คำนวณว่าต้องออมเดือนละเท่าไรจึงทันวันที่ต้องการ
  /// คืน null ถ้าไม่ได้กำหนดวันที่
  static MonthlyPlan? monthlyPlan({
    required int remaining,
    required DateTime? targetDate,
    required DateTime today,
  }) {
    if (targetDate == null) return null;

    final todayDate = AppDates.dateOnly(today);
    final target = AppDates.dateOnly(targetDate);
    final passed = target.isBefore(todayDate);

    var months = AppDates.monthsBetween(
          AppDates.monthKey(todayDate),
          AppDates.monthKey(target),
        ) +
        1;
    if (passed || months < 1) months = 1;

    final perMonth = remaining <= 0 ? 0 : IntMath.ceilDiv(remaining, months);
    return MonthlyPlan(
      perMonthSatang: perMonth,
      months: months,
      overdue: passed && remaining > 0,
    );
  }
}
