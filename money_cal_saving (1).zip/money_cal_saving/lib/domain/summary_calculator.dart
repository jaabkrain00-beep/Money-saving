import '../core/utils/app_dates.dart';
import '../core/utils/int_math.dart';
import '../data/db/app_database.dart';

/// สรุปการเงินของ 1 เดือน (หน่วยสตางค์ทั้งหมด)
class MonthSummary {
  const MonthSummary({
    required this.monthKey,
    this.incomeTotal = 0,
    this.incomeReceived = 0,
    this.expenseTotal = 0,
    this.expensePaid = 0,
    this.savings = 0,
    this.carryOver = 0,
  });

  final String monthKey;

  /// รายรับรวม (ประจำ + พิเศษ + ยอดยกมา)
  final int incomeTotal;

  /// รายรับที่ได้รับแล้ว (รวมยอดยกมา เพราะเป็นเงินที่มีอยู่แล้ว)
  final int incomeReceived;

  /// รายจ่ายรวม (ประจำทั้งจ่ายแล้วและยังไม่จ่าย + ทั่วไป)
  final int expenseTotal;
  final int expensePaid;

  /// เงินออมเดือนนี้ = Σ ฝาก − Σ ถอน
  final int savings;

  /// ยอดยกมาที่รวมอยู่ใน incomeTotal แล้ว (เก็บไว้เพื่อแสดงผล)
  final int carryOver;

  /// ค้างจ่าย = รายจ่ายรวม − จ่ายแล้ว
  int get expenseUnpaid => expenseTotal - expensePaid;

  /// เงินคงเหลือ (ตามแผน) = รายรับรวม − รายจ่ายรวม − เงินออม
  int get balancePlanned => incomeTotal - expenseTotal - savings;

  /// เงินคงเหลือ (ตอนนี้) = รายรับที่ได้รับแล้ว − รายจ่ายที่จ่ายแล้ว − เงินออม
  int get balanceNow => incomeReceived - expensePaid - savings;

  /// รายรับที่ยังไม่เข้า
  int get incomePending => incomeTotal - incomeReceived;
}

/// ยอดรายจ่ายรวมต่อหมวดหมู่
class CategoryTotal {
  const CategoryTotal(this.categoryId, this.amountSatang);

  /// null = ไม่มีหมวด
  final int? categoryId;
  final int amountSatang;
}

/// จุดข้อมูลของกราฟเส้นรายเดือน
class MonthPoint {
  const MonthPoint({
    required this.monthKey,
    required this.incomeSatang,
    required this.expenseSatang,
  });

  final String monthKey;
  final int incomeSatang;
  final int expenseSatang;
}

/// ฟังก์ชันคำนวณทั้งหมด — ฟังก์ชันล้วน ใช้จำนวนเต็ม (สตางค์) เท่านั้น
/// รายการที่ถูกลบเฉพาะเดือน (isSkipped) จะไม่ถูกนับเสมอ
class SummaryCalculator {
  SummaryCalculator._();

  /// ผลรวมเงินออมสุทธิ (ฝาก − ถอน)
  static int savingsNet(Iterable<SavingTransaction> transactions) {
    var total = 0;
    for (final t in transactions) {
      total += t.type == SavingTxType.deposit ? t.amountSatang : -t.amountSatang;
    }
    return total;
  }

  /// คำนวณสรุปของเดือน [monthKey]
  ///
  /// - [memberId] = null คือทั้งครอบครัว, ระบุ id คือเฉพาะรายคน
  /// - [goalOwners] แมป goalId -> เจ้าของเป้าหมาย (ใช้กรองเงินออมรายคน)
  /// - [carryOver] ยอดยกมา (บวกเข้ารายรับรวมและรายรับที่ได้รับแล้ว)
  static MonthSummary compute({
    required String monthKey,
    required Iterable<IncomeEntry> income,
    required Iterable<ExpenseEntry> expenses,
    required Iterable<SavingTransaction> savings,
    int carryOver = 0,
    int? memberId,
    Map<int, int?> goalOwners = const {},
  }) {
    var incomeTotal = carryOver;
    var incomeReceived = carryOver;
    for (final e in income) {
      if (e.isSkipped || e.monthKey != monthKey) continue;
      if (memberId != null && e.memberId != memberId) continue;
      incomeTotal += e.amountSatang;
      if (e.isReceived) incomeReceived += e.amountSatang;
    }

    var expenseTotal = 0;
    var expensePaid = 0;
    for (final e in expenses) {
      if (e.isSkipped || e.monthKey != monthKey) continue;
      if (memberId != null && e.memberId != memberId) continue;
      expenseTotal += e.amountSatang;
      if (e.isPaid) expensePaid += e.amountSatang;
    }

    var savingsNetTotal = 0;
    for (final t in savings) {
      if (t.monthKey != monthKey) continue;
      if (memberId != null && goalOwners[t.goalId] != memberId) continue;
      savingsNetTotal +=
          t.type == SavingTxType.deposit ? t.amountSatang : -t.amountSatang;
    }

    return MonthSummary(
      monthKey: monthKey,
      incomeTotal: incomeTotal,
      incomeReceived: incomeReceived,
      expenseTotal: expenseTotal,
      expensePaid: expensePaid,
      savings: savingsNetTotal,
      carryOver: carryOver,
    );
  }

  /// สรุปทุกเดือนที่มีข้อมูลในครั้งเดียว (ไม่รวมยอดยกมา) คืน Map<monthKey, summary>
  /// ใช้คำนวณยอดยกมาและกราฟย้อนหลัง
  static Map<String, MonthSummary> computeAll({
    required Iterable<IncomeEntry> income,
    required Iterable<ExpenseEntry> expenses,
    required Iterable<SavingTransaction> savings,
    int? memberId,
    Map<int, int?> goalOwners = const {},
  }) {
    final months = <String>{
      for (final e in income)
        if (!e.isSkipped) e.monthKey,
      for (final e in expenses)
        if (!e.isSkipped) e.monthKey,
      for (final t in savings) t.monthKey,
    };
    return {
      for (final m in months)
        m: compute(
          monthKey: m,
          income: income,
          expenses: expenses,
          savings: savings,
          memberId: memberId,
          goalOwners: goalOwners,
        ),
    };
  }

  /// ยอดยกมาเข้าเดือน [monthKey] จากการยกเงินคงเหลือ (ตามแผน) ของเดือนก่อนๆ ต่อกันเป็นทอด
  ///
  /// - ยกเฉพาะยอดบวก (ถ้าเดือนก่อนติดลบ ยอดยกมาเป็น 0)
  /// - [baseSummary] ต้องคืนสรุปที่ "ไม่รวมยอดยกมา" ของเดือนนั้น (เดือนที่ไม่มีข้อมูล = ว่าง)
  /// - [firstMonth] คือเดือนแรกสุดที่มีข้อมูล
  static int carryOverInto({
    required String monthKey,
    required String firstMonth,
    required MonthSummary Function(String monthKey) baseSummary,
    int maxMonths = 600,
  }) {
    if (monthKey.compareTo(firstMonth) <= 0) return 0;

    var start = firstMonth;
    if (AppDates.monthsBetween(firstMonth, monthKey) > maxMonths) {
      start = AppDates.addMonths(monthKey, -maxMonths);
    }

    var carry = 0;
    for (final m
        in AppDates.monthRange(start, AppDates.addMonths(monthKey, -1))) {
      final balance = baseSummary(m).balancePlanned + carry;
      carry = balance > 0 ? balance : 0;
    }
    return carry;
  }

  /// รายจ่ายแยกตามหมวด เรียงมากไปน้อย (เท่ากันเรียงตาม id, ไม่มีหมวดอยู่ท้าย)
  static List<CategoryTotal> expenseByCategory(
    Iterable<ExpenseEntry> expenses, {
    String? monthKey,
    int? memberId,
  }) {
    final totals = <int?, int>{};
    for (final e in expenses) {
      if (e.isSkipped) continue;
      if (monthKey != null && e.monthKey != monthKey) continue;
      if (memberId != null && e.memberId != memberId) continue;
      totals[e.categoryId] = (totals[e.categoryId] ?? 0) + e.amountSatang;
    }
    final list = [
      for (final entry in totals.entries) CategoryTotal(entry.key, entry.value),
    ];
    list.sort((a, b) {
      final byAmount = b.amountSatang.compareTo(a.amountSatang);
      if (byAmount != 0) return byAmount;
      if (a.categoryId == null) return 1;
      if (b.categoryId == null) return -1;
      return a.categoryId!.compareTo(b.categoryId!);
    });
    return list;
  }

  /// ข้อมูลกราฟเส้น รายรับเทียบรายจ่ายของ [months] (ไม่รวมยอดยกมา)
  static List<MonthPoint> series({
    required List<String> months,
    required Iterable<IncomeEntry> income,
    required Iterable<ExpenseEntry> expenses,
    int? memberId,
  }) {
    final incomeByMonth = <String, int>{};
    final expenseByMonth = <String, int>{};
    for (final e in income) {
      if (e.isSkipped) continue;
      if (memberId != null && e.memberId != memberId) continue;
      incomeByMonth[e.monthKey] = (incomeByMonth[e.monthKey] ?? 0) + e.amountSatang;
    }
    for (final e in expenses) {
      if (e.isSkipped) continue;
      if (memberId != null && e.memberId != memberId) continue;
      expenseByMonth[e.monthKey] =
          (expenseByMonth[e.monthKey] ?? 0) + e.amountSatang;
    }
    return [
      for (final m in months)
        MonthPoint(
          monthKey: m,
          incomeSatang: incomeByMonth[m] ?? 0,
          expenseSatang: expenseByMonth[m] ?? 0,
        ),
    ];
  }

  /// ข้อความเปรียบเทียบกับเดือนก่อน เช่น "รายจ่ายเพิ่มขึ้น 12%"
  /// คืน null ถ้าเดือนก่อนเป็น 0 (เทียบไม่ได้)
  static String? changeText(String label, int previous, int current) {
    final change = IntMath.percentChange(previous, current);
    if (change == null) return null;
    if (change == 0) return '$labelเท่ากับเดือนก่อน';
    return change > 0
        ? '$labelเพิ่มขึ้น $change%'
        : '$labelลดลง ${-change}%';
  }

  /// ข้อความแนะนำ เช่น "หมวดอาหารใช้เงินมากที่สุด 35%"
  static String? topCategoryInsight(
    List<CategoryTotal> slices,
    String Function(int? categoryId) nameOf,
  ) {
    if (slices.isEmpty) return null;
    final total = slices.fold<int>(0, (sum, s) => sum + s.amountSatang);
    if (total <= 0) return null;
    final top = slices.first;
    final percent = IntMath.percentOf(top.amountSatang, total);
    return 'หมวด${nameOf(top.categoryId)}ใช้เงินมากที่สุด $percent%';
  }
}
