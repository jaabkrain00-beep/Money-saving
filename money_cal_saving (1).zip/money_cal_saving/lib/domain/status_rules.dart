import '../core/utils/app_dates.dart';

/// สถานะของรายจ่าย
enum ExpenseStatus { paid, overdue, dueSoon, unpaid }

/// ช่วงเวลาของรายการที่กำลังจะถึงกำหนด (หน้า "การแจ้งเตือน")
enum DueBucket { overdue, today, thisWeek, later }

class ExpenseRules {
  ExpenseRules._();

  /// "ใกล้ครบกำหนด" = ภายใน 3 วัน (รวมวันนี้)
  static const int dueSoonDays = 3;

  static ExpenseStatus status({
    required bool isPaid,
    required DateTime dueDate,
    required DateTime today,
  }) {
    if (isPaid) return ExpenseStatus.paid;
    final days = AppDates.daysBetween(today, dueDate);
    if (days < 0) return ExpenseStatus.overdue;
    if (days <= dueSoonDays) return ExpenseStatus.dueSoon;
    return ExpenseStatus.unpaid;
  }

  static DueBucket bucket({required DateTime dueDate, required DateTime today}) {
    final days = AppDates.daysBetween(today, dueDate);
    if (days < 0) return DueBucket.overdue;
    if (days == 0) return DueBucket.today;
    if (days <= 7) return DueBucket.thisWeek;
    return DueBucket.later;
  }
}

class IncomeRules {
  IncomeRules._();

  /// ถึงวันเงินเข้าแล้วแต่ยังไม่ได้ยืนยัน -> ถามว่า "เงินเข้าแล้วหรือยัง"
  static bool needsConfirmation({
    required bool isReceived,
    required DateTime date,
    required DateTime today,
  }) {
    if (isReceived) return false;
    return AppDates.daysBetween(today, date) <= 0;
  }
}
