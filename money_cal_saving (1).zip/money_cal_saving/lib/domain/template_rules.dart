import '../core/utils/app_dates.dart';

/// กติกาของแม่แบบรายการประจำ (รายรับ/รายจ่าย)
/// monthKey เป็น "yyyy-MM" จึงเทียบด้วย compareTo ได้ตรงตามลำดับเวลา
class TemplateRules {
  TemplateRules._();

  /// เดือนสุดท้ายจริงของแม่แบบ:
  /// - มี [totalInstallments] -> เดือนที่ครบงวด (startMonth + total - 1)
  /// - มี [endMonth] (ปิดยอดด้วยมือ) -> endMonth
  /// - มีทั้งสอง -> เดือนที่มาถึงก่อน
  /// - ไม่มีเลย -> null (ไม่มีกำหนดสิ้นสุด)
  static String? effectiveEndMonth({
    required String startMonth,
    String? endMonth,
    int? totalInstallments,
  }) {
    String? byCount;
    if (totalInstallments != null && totalInstallments > 0) {
      byCount = AppDates.addMonths(startMonth, totalInstallments - 1);
    }
    if (endMonth == null) return byCount;
    if (byCount == null) return endMonth;
    return endMonth.compareTo(byCount) < 0 ? endMonth : byCount;
  }

  /// แม่แบบยัง active ในเดือน [monthKey] หรือไม่ (อยู่ระหว่าง start ถึง end รวมหัวท้าย)
  static bool isActiveIn(
    String monthKey, {
    required String startMonth,
    String? endMonth,
    int? totalInstallments,
  }) {
    if (monthKey.compareTo(startMonth) < 0) return false;
    final end = effectiveEndMonth(
      startMonth: startMonth,
      endMonth: endMonth,
      totalInstallments: totalInstallments,
    );
    return end == null || monthKey.compareTo(end) <= 0;
  }

  /// งวดที่เท่าไรในเดือน [monthKey] (เดือนเริ่มต้น = งวดที่ 1)
  static int installmentNumber(String startMonth, String monthKey) =>
      AppDates.monthsBetween(startMonth, monthKey) + 1;

  /// เดือนนี้เป็น "งวดสุดท้าย" หรือไม่ (ปิดยอดแล้ว หรือครบงวดพอดี)
  static bool isFinalMonth(
    String monthKey, {
    required String startMonth,
    String? endMonth,
    int? totalInstallments,
  }) {
    final end = effectiveEndMonth(
      startMonth: startMonth,
      endMonth: endMonth,
      totalInstallments: totalInstallments,
    );
    return end != null && end == monthKey;
  }
}
