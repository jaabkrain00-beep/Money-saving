import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/app_dates.dart';
import '../../core/utils/haptics.dart';
import '../../core/utils/money.dart';
import '../../data/db/app_database.dart';
import '../../domain/goal_calculator.dart';
import '../../domain/status_rules.dart';
import '../../domain/summary_calculator.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';
import '../more/more_menu.dart';
import '../savings/savings_screen.dart';
import '../shared/entry_card.dart';

/// หน้าแรก: ยอดคงเหลือ (ตามแผน/ตอนนี้) สรุปรับ-จ่าย-ออม รายการใกล้ครบกำหนด เป้าหมาย และ insight
class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key, required this.onOpenTab});

  final ValueChanged<int> onOpenTab;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final ready = ref.watch(monthReadyProvider);
    final s = ref.watch(monthSummaryProvider(null));
    final prev = ref.watch(previousMonthSummaryProvider(null));
    final byCategory = ref.watch(monthExpenseByCategoryProvider(null));
    final categoryMap = ref.watch(categoryMapProvider);
    final buddhist = ref.watch(useBuddhistYearProvider);
    final unpaid = ref.watch(unpaidExpensesProvider).valueOrNull ??
        const <ExpenseEntry>[];
    final goals = ref.watch(goalsProvider).valueOrNull ?? const <SavingGoal>[];
    final balances = ref.watch(goalBalancesProvider);
    final today = AppDates.dateOnly(DateTime.now());

    // ใกล้ครบกำหนด: เลยกำหนดแล้ว หรือครบภายใน 7 วัน (ทุกเดือน ไม่ใช่เฉพาะเดือนที่เลือก)
    final upcoming = [
      for (final e in unpaid)
        if (AppDates.daysBetween(today, e.dueDate) <= 7) e,
    ]..sort((a, b) => a.dueDate.compareTo(b.dueDate));

    final insights = <String>[
      SummaryCalculator.changeText(
        'รายจ่ายเดือนนี้',
        prev.expenseTotal,
        s.expenseTotal,
      ),
      SummaryCalculator.changeText(
        'รายรับเดือนนี้',
        prev.incomeTotal,
        s.incomeTotal,
      ),
      SummaryCalculator.topCategoryInsight(
        byCategory,
        (id) => categoryMap[id]?.name ?? 'อื่นๆ',
      ),
    ].whereType<String>().toList();

    Widget stat({
      required String label,
      required int satang,
      required String sub,
      required LinearGradient gradient,
      required VoidCallback onTap,
    }) {
      return Expanded(
        child: GradientCard(
          gradient: gradient,
          padding: const EdgeInsets.all(14),
          onTap: onTap,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.bodySmall),
              AmountText(
                satang,
                animate: true,
                style: theme.textTheme.titleMedium,
              ),
              const SizedBox(height: 2),
              Text(
                sub,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: theme.textTheme.bodySmall,
              ),
            ],
          ),
        ),
      );
    }

    return MonthSwipe(
      child: CustomScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        slivers: [
          PastelSliverAppBar(
            title: AppDates.greeting(DateTime.now()),
            actions: const [MoreMenuButton()],
          ),
          const SliverToBoxAdapter(child: MonthSelector()),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.screenH,
                vertical: AppSpacing.sm,
              ),
              child: GradientCard(
                gradient: AppGradients.hero,
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('เงินคงเหลือเดือนนี้ (ตามแผน)',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.bodyMedium),
                    const SizedBox(height: 2),
                    AmountText(
                      s.balancePlanned,
                      animate: true,
                      redWhenNegative: true,
                      style: theme.textTheme.displaySmall,
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    Wrap(
                      spacing: 8,
                      runSpacing: 6,
                      children: [
                        InfoChip(
                          text: 'ตอนนี้ ฿${Money.format(s.balanceNow)}',
                          emoji: '💼',
                        ),
                        if (s.carryOver != 0)
                          InfoChip(
                            text: 'ยกมา ฿${Money.format(s.carryOver)}',
                            emoji: '↪️',
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.screenH,
                vertical: AppSpacing.sm,
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  stat(
                    label: 'รายรับ',
                    satang: s.incomeTotal,
                    sub: 'ได้รับแล้ว ${Money.formatCompact(s.incomeReceived)}',
                    gradient: AppGradients.income,
                    onTap: () => onOpenTab(1),
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  stat(
                    label: 'รายจ่าย',
                    satang: s.expenseTotal,
                    sub: 'ค้างจ่าย ${Money.formatCompact(s.expenseUnpaid)}',
                    gradient: AppGradients.expense,
                    onTap: () => onOpenTab(2),
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  stat(
                    label: 'เงินออม',
                    satang: s.savings,
                    sub: 'เดือนนี้',
                    gradient: AppGradients.saving,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const SavingsScreen(),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (ready && insights.isNotEmpty)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSpacing.screenH,
                  vertical: AppSpacing.sm,
                ),
                child: GlassCard(
                  radius: AppRadius.r24,
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      for (final text in insights)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('💡 '),
                              Expanded(
                                child: Text(text,
                                    style: theme.textTheme.bodyMedium),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          SliverToBoxAdapter(
            child: SectionHeader(
              title: 'ใกล้ครบกำหนด',
              actionLabel: upcoming.isEmpty ? null : 'ดูทั้งหมด',
              onAction: () => onOpenTab(2),
            ),
          ),
          if (upcoming.isEmpty)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSpacing.screenH,
                  vertical: AppSpacing.sm,
                ),
                child: GlassCard(
                  radius: AppRadius.r24,
                  padding: const EdgeInsets.all(18),
                  child: Row(
                    children: [
                      const Text('🎉', style: TextStyle(fontSize: 28)),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'ไม่มีรายการค้างจ่ายใน 7 วันนี้ สบายใจได้เลย',
                          style: theme.textTheme.bodyMedium,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            )
          else
            SliverList.builder(
              itemCount: upcoming.length > 4 ? 4 : upcoming.length,
              itemBuilder: (context, i) => _DueTile(
                entry: upcoming[i],
                index: i,
                today: today,
                buddhist: buddhist,
                category: categoryMap[upcoming[i].categoryId],
              ),
            ),
          if (goals.isNotEmpty) ...[
            SectionHeader(
              title: 'เป้าหมายออม',
              actionLabel: 'ดูทั้งหมด',
              onAction: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const SavingsScreen()),
              ),
            ),
            SliverToBoxAdapter(
              child: SizedBox(
                height: 132,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(
                    horizontal: AppSpacing.screenH,
                    vertical: 6,
                  ),
                  itemCount: goals.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 12),
                  itemBuilder: (context, i) => _MiniGoal(
                    goal: goals[i],
                    saved: balances[goals[i].id] ?? 0,
                  ),
                ),
              ),
            ),
          ],
          const SliverToBoxAdapter(
            child: SizedBox(height: AppSpacing.navBarClearance),
          ),
        ],
      ),
    );
  }
}

class _DueTile extends ConsumerWidget {
  const _DueTile({
    required this.entry,
    required this.index,
    required this.today,
    required this.buddhist,
    required this.category,
  });

  final ExpenseEntry entry;
  final int index;
  final DateTime today;
  final bool buddhist;
  final Category? category;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final status = ExpenseRules.status(
      isPaid: false,
      dueDate: entry.dueDate,
      today: today,
    );
    final days = AppDates.daysBetween(today, entry.dueDate);
    final dueText = days < 0
        ? 'เลยกำหนด ${-days} วัน'
        : (days == 0 ? 'ครบกำหนดวันนี้' : 'อีก $days วัน');

    return EntryCard(
      slidableKey: ValueKey('home-due-${entry.id}'),
      index: index,
      emoji: category?.icon ?? '🧾',
      color: Color(category?.color ?? AppColors.expenseA.toARGB32()),
      title: entry.name,
      subtitle:
          '$dueText · ${AppDates.formatDayMonth(entry.dueDate, buddhist: buddhist)}',
      amountSatang: entry.amountSatang,
      amountColor: AppColors.dangerInk,
      chips: [
        status == ExpenseStatus.overdue
            ? const StatusChip.overdue()
            : (status == ExpenseStatus.dueSoon
                ? const StatusChip.dueSoon()
                : const StatusChip.unpaid()),
      ],
      trailingAction: MiniActionButton(
        label: 'จ่ายเลย',
        icon: PhosphorIconsBold.check,
        onTap: () async {
          Haptics.medium();
          final messenger = ScaffoldMessenger.of(context);
          final repo = ref.read(expenseRepositoryProvider);
          await repo.setPaid(entry.id, true);
          showUndoSnackBarOn(
            messenger,
            message: 'จ่าย "${entry.name}" แล้ว ✅',
            onUndo: () => repo.setPaid(entry.id, false),
          );
        },
      ),
    );
  }
}

class _MiniGoal extends StatelessWidget {
  const _MiniGoal({required this.goal, required this.saved});

  final SavingGoal goal;
  final int saved;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final progress =
        GoalCalculator.progress(saved: saved, target: goal.targetSatang);
    final color = Color(goal.color);
    return SizedBox(
      width: 150,
      child: GlassCard(
        radius: AppRadius.r24,
        padding: const EdgeInsets.all(12),
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => const SavingsScreen()),
        ),
        child: Row(
          children: [
            ProgressRing(
              fraction: progress.fraction,
              colors: [color, AppColors.brandB, color],
              size: 52,
              strokeWidth: 7,
              child: Text(goal.emoji, style: const TextStyle(fontSize: 20)),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    goal.name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.labelLarge,
                  ),
                  Text('${progress.percent}%',
                      style: theme.textTheme.bodySmall),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
