import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/haptics.dart';
import '../../widgets/widgets.dart';
import '../expense/expense_form_sheet.dart';
import '../income/income_form_sheet.dart';
import '../savings/saving_tx_form_sheet.dart';

enum QuickAddAction { income, incomeOneTime, expense, expenseOneTime, saving }

/// ชีตปุ่ม "+" กลางแถบเมนู: เลือกชนิดรายการที่จะเพิ่มแล้วเปิดฟอร์มทันที
Future<void> showQuickAddSheet(BuildContext context) async {
  Haptics.light();
  final action = await showModalBottomSheet<QuickAddAction>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    builder: (ctx) {
      final theme = Theme.of(ctx);
      Widget tile({
        required String emoji,
        required String title,
        required String subtitle,
        required LinearGradient gradient,
        required QuickAddAction action,
      }) {
        return GradientCard(
          gradient: gradient,
          padding: const EdgeInsets.all(14),
          onTap: () => Navigator.of(ctx).pop(action),
          child: ConstrainedBox(
            constraints: const BoxConstraints(minHeight: 96),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(emoji, style: const TextStyle(fontSize: 28)),
                const SizedBox(height: 6),
                Text(
                  title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.titleSmall,
                ),
                Text(
                  subtitle,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.bodySmall,
                ),
              ],
            ),
          ),
        );
      }

      return SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.screenH,
          0,
          AppSpacing.screenH,
          AppSpacing.xxl,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('เพิ่มรายการ', style: theme.textTheme.titleLarge),
            const SizedBox(height: AppSpacing.md),
            Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(
                  child: tile(
                    emoji: '💰',
                    title: 'รายรับประจำ',
                    subtitle: 'เงินเดือน ค่าเช่า',
                    gradient: AppGradients.income,
                    action: QuickAddAction.income,
                  ),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: tile(
                    emoji: '🎁',
                    title: 'รายรับพิเศษ',
                    subtitle: 'โบนัส ขายของ',
                    gradient: AppGradients.income,
                    action: QuickAddAction.incomeOneTime,
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.md),
            Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(
                  child: tile(
                    emoji: '🧾',
                    title: 'รายจ่ายประจำ / ผ่อน',
                    subtitle: 'ค่าไฟ ค่าผ่อน',
                    gradient: AppGradients.expense,
                    action: QuickAddAction.expense,
                  ),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: tile(
                    emoji: '🛍️',
                    title: 'รายจ่ายจร',
                    subtitle: 'ค่าอาหาร ซื้อของ',
                    gradient: AppGradients.expense,
                    action: QuickAddAction.expenseOneTime,
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.md),
            tile(
              emoji: '🐷',
              title: 'ฝาก/ถอนเงินออม',
              subtitle: 'เก็บเงินเข้าเป้าหมายของครอบครัว',
              gradient: AppGradients.saving,
              action: QuickAddAction.saving,
            ),
          ],
        ),
      );
    },
  );

  if (action == null || !context.mounted) return;
  switch (action) {
    case QuickAddAction.income:
      await showIncomeForm(context);
    case QuickAddAction.incomeOneTime:
      await showIncomeForm(context, startOneTime: true);
    case QuickAddAction.expense:
      await showExpenseForm(context);
    case QuickAddAction.expenseOneTime:
      await showExpenseForm(context, startOneTime: true);
    case QuickAddAction.saving:
      await showSavingTxForm(context);
  }
}
