import 'package:animations/animations.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../data/seed/sample_data.dart';
import '../../data/settings_keys.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';
import '../expense/expense_screen.dart';
import '../home/home_screen.dart';
import '../income/income_screen.dart';
import '../report/report_screen.dart';
import 'quick_add_sheet.dart';

/// โครงหลัก: 4 แท็บ + ปุ่ม "+" กลาง บน Floating Bottom Nav
/// เปลี่ยนแท็บด้วย Fade-through, กดย้อนกลับจากแท็บอื่นจะกลับหน้าแรกก่อน
class AppShell extends ConsumerStatefulWidget {
  const AppShell({super.key});

  @override
  ConsumerState<AppShell> createState() => _AppShellState();
}

class _AppShellState extends ConsumerState<AppShell> {
  int _index = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _offerSampleData());
  }

  /// เปิดแอปครั้งแรก: ถามว่าจะลองด้วยข้อมูลตัวอย่างหรือเริ่มจากว่าง (ถามครั้งเดียว)
  Future<void> _offerSampleData() async {
    final repo = ref.read(settingsRepositoryProvider);
    if (await repo.getString(SettingKeys.seeded) != null) return;
    await repo.setString(SettingKeys.seeded, 'true');
    if (!mounted) return;
    final useSample = await showConfirmDialog(
      context,
      emoji: '👋',
      title: 'ยินดีต้อนรับสู่ Money Cal Saving',
      message: 'อยากลองดูแอปด้วยข้อมูลตัวอย่างก่อนไหม? ลบได้ทุกเมื่อที่ ตั้งค่า > ล้างข้อมูลทั้งหมด',
      confirmLabel: 'ลองด้วยข้อมูลตัวอย่าง',
      cancelLabel: 'เริ่มจากว่างเปล่า',
    );
    if (useSample) {
      await insertSampleData(ref.read(databaseProvider));
    }
  }

  static const List<NavItemData> _items = [
    NavItemData(
      icon: PhosphorIconsRegular.house,
      activeIcon: PhosphorIconsFill.house,
      label: 'หน้าแรก',
    ),
    NavItemData(
      icon: PhosphorIconsRegular.trendUp,
      activeIcon: PhosphorIconsFill.trendUp,
      label: 'รายรับ',
    ),
    NavItemData(
      icon: PhosphorIconsRegular.receipt,
      activeIcon: PhosphorIconsFill.receipt,
      label: 'รายจ่าย',
    ),
    NavItemData(
      icon: PhosphorIconsRegular.chartPieSlice,
      activeIcon: PhosphorIconsFill.chartPieSlice,
      label: 'สรุป',
    ),
  ];

  Widget _page(int i) {
    switch (i) {
      case 0:
        return HomeScreen(
          key: const ValueKey('tab-home'),
          onOpenTab: _select,
        );
      case 1:
        return const IncomeScreen(key: ValueKey('tab-income'));
      case 2:
        return const ExpenseScreen(key: ValueKey('tab-expense'));
      default:
        return const ReportScreen(key: ValueKey('tab-report'));
    }
  }

  void _select(int i) {
    if (i == _index) return;
    setState(() => _index = i);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _index == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && _index != 0) setState(() => _index = 0);
      },
      child: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          systemNavigationBarColor: Colors.transparent,
          statusBarIconBrightness:
              Theme.of(context).brightness == Brightness.dark
                  ? Brightness.light
                  : Brightness.dark,
        ),
        child: Scaffold(
          extendBody: true,
          body: PageTransitionSwitcher(
            duration: const Duration(milliseconds: 350),
            transitionBuilder: (child, primary, secondary) =>
                FadeThroughTransition(
              animation: primary,
              secondaryAnimation: secondary,
              fillColor: Colors.transparent,
              child: child,
            ),
            child: _page(_index),
          ),
          bottomNavigationBar: FloatingNavBar(
            currentIndex: _index,
            items: _items,
            onSelected: _select,
            onAdd: () => showQuickAddSheet(context),
          ),
        ),
      ),
    );
  }
}
