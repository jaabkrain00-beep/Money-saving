import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:share_plus/share_plus.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/haptics.dart';
import '../../data/seed/sample_data.dart';
import '../../data/settings_keys.dart';
import '../../providers/providers.dart';
import '../../services/backup_service.dart';
import '../../widgets/widgets.dart';
import '../lock/pin_sheets.dart';
import '../shared/form_kit.dart';
import '../shared/page_kit.dart';

/// หน้าตั้งค่า: ลักษณะ ความปลอดภัย (PIN/ลายนิ้วมือ) ข้อมูล (สำรอง/กู้คืน/CSV/ตัวอย่าง/ล้าง)
class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  bool _busy = false;

  Future<void> _run(Future<void> Function() job) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await job();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _backup() => _run(() async {
        final messenger = ScaffoldMessenger.of(context);
        try {
          final path = await ref.read(backupServiceProvider).writeBackupFile();
          await Share.shareXFiles(
            [XFile(path, mimeType: 'application/json')],
            subject: 'ไฟล์สำรอง Money Cal Saving',
          );
        } catch (_) {
          showAppSnackBarOn(messenger, 'สำรองข้อมูลไม่สำเร็จ', emoji: '😢');
        }
      });

  Future<void> _restore() => _run(() async {
        final messenger = ScaffoldMessenger.of(context);
        final picked = await FilePicker.platform.pickFiles(
          type: FileType.any,
          withData: true,
        );
        if (picked == null || picked.files.isEmpty) return;
        final file = picked.files.single;
        if (!mounted) return;

        final ok = await showConfirmDialog(
          context,
          emoji: '♻️',
          title: 'กู้คืนข้อมูลจาก "${file.name}" ?',
          message: 'ข้อมูลปัจจุบันทั้งหมดจะถูกแทนที่ด้วยข้อมูลในไฟล์ และไม่สามารถย้อนกลับได้',
          confirmLabel: 'กู้คืน',
          destructive: true,
        );
        if (!ok) return;

        try {
          final bytes = file.bytes ?? await File(file.path!).readAsBytes();
          await ref
              .read(backupServiceProvider)
              .restoreFromJson(utf8.decode(bytes).replaceFirst('\uFEFF', ''));
          Haptics.heavy();
          showAppSnackBarOn(messenger, 'กู้คืนข้อมูลเรียบร้อย', emoji: '✅');
        } on BackupException catch (e) {
          showAppSnackBarOn(messenger, e.message, emoji: '⚠️');
        } catch (_) {
          showAppSnackBarOn(messenger, 'กู้คืนไม่สำเร็จ ข้อมูลเดิมไม่ถูกเปลี่ยนแปลง', emoji: '😢');
        }
      });

  Future<void> _csv() => _run(() async {
        final messenger = ScaffoldMessenger.of(context);
        try {
          final paths = await ref.read(backupServiceProvider).writeCsvFiles();
          await Share.shareXFiles(
            [for (final p in paths) XFile(p, mimeType: 'text/csv')],
            subject: 'ข้อมูล Money Cal Saving (CSV)',
          );
        } catch (_) {
          showAppSnackBarOn(messenger, 'ส่งออก CSV ไม่สำเร็จ', emoji: '😢');
        }
      });

  Future<void> _sample() => _run(() async {
        final messenger = ScaffoldMessenger.of(context);
        final ok = await showConfirmDialog(
          context,
          emoji: '🧪',
          title: 'เพิ่มข้อมูลตัวอย่าง?',
          message: 'ระบบจะเพิ่มสมาชิก รายรับ รายจ่าย และเป้าหมายออมตัวอย่างเข้าไป (ไม่ลบข้อมูลเดิม)',
          confirmLabel: 'เพิ่มข้อมูลตัวอย่าง',
        );
        if (!ok) return;
        await insertSampleData(ref.read(databaseProvider));
        showAppSnackBarOn(messenger, 'เพิ่มข้อมูลตัวอย่างแล้ว', emoji: '🎉');
      });

  Future<void> _clear() => _run(() async {
        final messenger = ScaffoldMessenger.of(context);
        final first = await showConfirmDialog(
          context,
          title: 'ล้างข้อมูลทั้งหมด?',
          message: 'สมาชิก รายรับ รายจ่าย และเงินออมทั้งหมดจะถูกลบ (หมวดหมู่และการตั้งค่าจะยังอยู่)',
          confirmLabel: 'ต่อไป',
          destructive: true,
        );
        if (!first || !mounted) return;
        final second = await showConfirmDialog(
          context,
          emoji: '⚠️',
          title: 'ยืนยันอีกครั้ง',
          message: 'การลบนี้ย้อนกลับไม่ได้ แนะนำให้สำรองข้อมูลก่อน',
          confirmLabel: 'ลบทั้งหมดเลย',
          destructive: true,
        );
        if (!second) return;
        await ref.read(databaseProvider).clearAllData();
        Haptics.heavy();
        showAppSnackBarOn(messenger, 'ล้างข้อมูลแล้ว', emoji: '🧹');
      });

  Future<void> _setPin() async {
    final s = ref.read(settingsProvider);
    if (s.hasPin && !await showPinVerify(context)) return;
    if (!mounted) return;
    final ok = await showPinSetup(context);
    if (ok && mounted) {
      showAppSnackBar(context, 'ตั้ง PIN เรียบร้อย', emoji: '🔒');
    }
  }

  Future<void> _removePin() async {
    if (!await showPinVerify(context, title: 'ยืนยัน PIN เพื่อลบ')) return;
    await ref.read(pinServiceProvider).clearPin();
    ref.read(appLockProvider.notifier).unlock();
    if (mounted) showAppSnackBar(context, 'ลบ PIN แล้ว', emoji: '🔓');
  }

  Future<void> _toggleBiometric(bool on) async {
    final repo = ref.read(settingsRepositoryProvider);
    if (on) {
      final svc = ref.read(pinServiceProvider);
      if (!await svc.biometricAvailable()) {
        if (mounted) {
          showAppSnackBar(context, 'เครื่องนี้ยังไม่ได้ตั้งค่าลายนิ้วมือ/ใบหน้า', emoji: '⚠️');
        }
        return;
      }
      if (!await svc.authenticateBiometric()) return;
    }
    await repo.setBool(SettingKeys.biometric, on);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final s = ref.watch(settingsProvider);
    final repo = ref.read(settingsRepositoryProvider);

    return Scaffold(
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        slivers: [
          const PastelSliverAppBar(title: 'ตั้งค่า', leading: PastelBackButton()),
          SliverList(
            delegate: SliverChildListDelegate([
              const SectionHeader(title: 'ลักษณะ'),
              _Card(
                children: [
                  const FieldLabel('ธีม'),
                  SegmentSwitch(
                    labels: const ['ตามระบบ', 'สว่าง', 'มืด'],
                    index: switch (s.themeMode) {
                      ThemeMode.system => 0,
                      ThemeMode.light => 1,
                      ThemeMode.dark => 2,
                    },
                    onChanged: (i) => repo.setThemeMode(
                      const [ThemeMode.system, ThemeMode.light, ThemeMode.dark][i],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  SwitchListTile.adaptive(
                    contentPadding: EdgeInsets.zero,
                    value: s.buddhistYear,
                    title: const Text('แสดงปี พ.ศ.'),
                    subtitle: Text(
                      s.buddhistYear ? 'เช่น พฤษภาคม 2568' : 'เช่น พฤษภาคม 2025',
                      style: theme.textTheme.bodySmall,
                    ),
                    onChanged: (v) => repo.setBool(SettingKeys.buddhistYear, v),
                  ),
                  SwitchListTile.adaptive(
                    contentPadding: EdgeInsets.zero,
                    value: s.carryOver,
                    title: const Text('ยกยอดคงเหลือไปเดือนถัดไป'),
                    subtitle: Text(
                      'เงินคงเหลือที่เป็นบวกจะถูกนับเป็นรายรับยกมาของเดือนถัดไป',
                      style: theme.textTheme.bodySmall,
                    ),
                    onChanged: (v) => repo.setBool(SettingKeys.carryOver, v),
                  ),
                ],
              ),
              const SectionHeader(title: 'ความปลอดภัย'),
              _Card(
                children: [
                  _ActionTile(
                    icon: PhosphorIconsRegular.lockKey,
                    title: s.hasPin ? 'เปลี่ยน PIN' : 'ตั้ง PIN เข้าแอป',
                    onTap: _setPin,
                  ),
                  if (s.hasPin) ...[
                    SwitchListTile.adaptive(
                      contentPadding: EdgeInsets.zero,
                      value: s.biometric,
                      title: const Text('ใช้ลายนิ้วมือ/ใบหน้า'),
                      onChanged: _toggleBiometric,
                    ),
                    _ActionTile(
                      icon: PhosphorIconsRegular.lockKeyOpen,
                      title: 'ลบ PIN',
                      onTap: _removePin,
                      danger: true,
                    ),
                  ],
                ],
              ),
              const SectionHeader(title: 'ข้อมูล'),
              _Card(
                children: [
                  _ActionTile(
                    icon: PhosphorIconsRegular.cloudArrowUp,
                    title: 'สำรองข้อมูล (JSON)',
                    subtitle: 'ส่งไฟล์ไปเก็บใน Drive, LINE หรืออีเมล',
                    onTap: _busy ? null : _backup,
                  ),
                  _ActionTile(
                    icon: PhosphorIconsRegular.cloudArrowDown,
                    title: 'กู้คืนข้อมูลจากไฟล์สำรอง',
                    onTap: _busy ? null : _restore,
                  ),
                  _ActionTile(
                    icon: PhosphorIconsRegular.fileCsv,
                    title: 'ส่งออกเป็น CSV',
                    subtitle: 'รายรับ รายจ่าย เงินออม (เปิดใน Excel ได้)',
                    onTap: _busy ? null : _csv,
                  ),
                  _ActionTile(
                    icon: PhosphorIconsRegular.flask,
                    title: 'เพิ่มข้อมูลตัวอย่าง',
                    onTap: _busy ? null : _sample,
                  ),
                  _ActionTile(
                    icon: PhosphorIconsRegular.trash,
                    title: 'ล้างข้อมูลทั้งหมด',
                    onTap: _busy ? null : _clear,
                    danger: true,
                  ),
                ],
              ),
              const SectionHeader(title: 'เกี่ยวกับ'),
              _Card(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Text(
                      'Money Cal Saving เวอร์ชัน 1.0.0\n'
                      'บันทึกรายรับ รายจ่าย และเงินออมของครอบครัว '
                      'ข้อมูลทั้งหมดเก็บในเครื่องนี้ ใช้งานได้โดยไม่ต้องมีอินเทอร์เน็ต',
                      style: theme.textTheme.bodyMedium,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.huge),
            ]),
          ),
        ],
      ),
    );
  }
}

class _Card extends StatelessWidget {
  const _Card({required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.screenH,
        vertical: AppSpacing.xs,
      ),
      child: GlassCard(
        radius: AppRadius.r24,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: children,
        ),
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({
    required this.icon,
    required this.title,
    required this.onTap,
    this.subtitle,
    this.danger = false,
  });

  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback? onTap;
  final bool danger;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final p = context.palette;
    final color = danger ? AppColors.dangerInk : p.ink;
    return InkWell(
      borderRadius: BorderRadius.circular(AppRadius.r16),
      onTap: onTap,
      child: ConstrainedBox(
        constraints: const BoxConstraints(minHeight: 56),
        child: Opacity(
          opacity: onTap == null ? 0.5 : 1,
          child: Row(
            children: [
              Icon(icon, color: color),
              const SizedBox(width: 14),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: theme.textTheme.titleSmall?.copyWith(color: color),
                      ),
                      if (subtitle != null)
                        Text(subtitle!, style: theme.textTheme.bodySmall),
                    ],
                  ),
                ),
              ),
              Icon(PhosphorIconsRegular.caretRight, size: 18, color: p.inkSoft),
            ],
          ),
        ),
      ),
    );
  }
}
