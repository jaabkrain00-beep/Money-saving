import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/app_dates.dart';
import '../../core/utils/int_math.dart';
import '../../core/utils/money.dart';
import '../../data/db/app_database.dart';
import '../../domain/summary_calculator.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';
import '../more/more_menu.dart';
import '../shared/entry_card.dart';
import '../shared/form_kit.dart';

/// หน้าสรุป: กราฟเส้นรายรับ-รายจ่าย 6/12 เดือน, วงกลมแยกหมวด, เปรียบเทียบกับเดือนก่อน, insight
class ReportScreen extends ConsumerStatefulWidget {
  const ReportScreen({super.key});

  @override
  ConsumerState<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends ConsumerState<ReportScreen> {
  int _rangeIndex = 0; // 0 = 6 เดือน, 1 = 12 เดือน
  int? _memberFilter;

  int get _months => _rangeIndex == 0 ? 6 : 12;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final month = ref.watch(selectedMonthProvider);
    final buddhist = ref.watch(useBuddhistYearProvider);
    final members = ref.watch(membersProvider).valueOrNull ?? const <Member>[];
    final memberMap = ref.watch(memberMapProvider);
    final categoryMap = ref.watch(categoryMapProvider);

    final filterId =
        (_memberFilter != null && memberMap.containsKey(_memberFilter))
            ? _memberFilter
            : null;

    final keys = AppDates.monthsBack(month, _months);
    // ให้แน่ใจว่าสร้างรายการประจำของทุกเดือนในช่วงกราฟแล้ว
    ref.watch(ensureWindowProvider('${keys.first}|${keys.last}'));

    final income =
        ref.watch(allIncomeProvider).valueOrNull ?? const <IncomeEntry>[];
    final expenses =
        ref.watch(allExpenseProvider).valueOrNull ?? const <ExpenseEntry>[];
    final points = SummaryCalculator.series(
      months: keys,
      income: income,
      expenses: expenses,
      memberId: filterId,
    );

    final s = ref.watch(monthSummaryProvider(filterId));
    final prev = ref.watch(previousMonthSummaryProvider(filterId));
    final slices = ref.watch(monthExpenseByCategoryProvider(filterId));

    final insights = <String>[
      SummaryCalculator.changeText('รายจ่าย', prev.expenseTotal, s.expenseTotal),
      SummaryCalculator.changeText('รายรับ', prev.incomeTotal, s.incomeTotal),
      SummaryCalculator.topCategoryInsight(
        slices,
        (id) => categoryMap[id]?.name ?? 'อื่นๆ',
      ),
    ].whereType<String>().toList();

    return MonthSwipe(
      child: CustomScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        slivers: [
          const PastelSliverAppBar(title: 'สรุป', actions: [MoreMenuButton()]),
          const SliverToBoxAdapter(child: MonthSelector()),
          SliverToBoxAdapter(
            child: MemberFilterBar(
              members: members,
              selectedId: filterId,
              onChanged: (id) => setState(() => _memberFilter = id),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.screenH,
                vertical: AppSpacing.sm,
              ),
              child: GradientCard(
                gradient: AppGradients.hero,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('คงเหลือเดือนนี้ (ตามแผน)',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.bodyMedium),
                    AmountText(
                      s.balancePlanned,
                      animate: true,
                      redWhenNegative: true,
                      style: theme.textTheme.headlineMedium,
                    ),
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: _Section(
              title: 'รายรับ-รายจ่ายย้อนหลัง',
              trailing: SizedBox(
                width: 150,
                child: SegmentSwitch(
                  labels: const ['6 เดือน', '12 เดือน'],
                  index: _rangeIndex,
                  onChanged: (i) => setState(() => _rangeIndex = i),
                ),
              ),
              child: _TrendChart(points: points, buddhist: buddhist),
            ),
          ),
          SliverToBoxAdapter(
            child: _Section(
              title: 'รายจ่ายแยกหมวดหมู่',
              child: _CategoryDonut(
                slices: slices,
                categoryMap: categoryMap,
                total: s.expenseTotal,
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: _Section(
              title: 'เทียบกับเดือนก่อน',
              child: Column(
                children: [
                  _CompareRow(
                    label: 'รายรับ',
                    emoji: '💰',
                    current: s.incomeTotal,
                    previous: prev.incomeTotal,
                    gradient: AppGradients.income,
                  ),
                  _CompareRow(
                    label: 'รายจ่าย',
                    emoji: '🧾',
                    current: s.expenseTotal,
                    previous: prev.expenseTotal,
                    gradient: AppGradients.expense,
                    lowerIsBetter: true,
                  ),
                  _CompareRow(
                    label: 'เงินออม',
                    emoji: '🐷',
                    current: s.savings,
                    previous: prev.savings,
                    gradient: AppGradients.saving,
                  ),
                ],
              ),
            ),
          ),
          if (insights.isNotEmpty)
            SliverToBoxAdapter(
              child: _Section(
                title: 'ข้อสังเกต',
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    for (final t in insights)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('💡 '),
                            Expanded(
                              child: Text(t, style: theme.textTheme.bodyMedium),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            ),
          const SliverToBoxAdapter(
            child: SizedBox(height: AppSpacing.navBarClearance),
          ),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title, required this.child, this.trailing});

  final String title;
  final Widget child;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.screenH,
        vertical: AppSpacing.sm,
      ),
      child: GlassCard(
        radius: AppRadius.r24,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.titleMedium,
                  ),
                ),
                if (trailing != null) ...[
                  const SizedBox(width: 8),
                  trailing!,
                ],
              ],
            ),
            const SizedBox(height: AppSpacing.md),
            child,
          ],
        ),
      ),
    );
  }
}

class _TrendChart extends StatelessWidget {
  const _TrendChart({required this.points, required this.buddhist});

  final List<MonthPoint> points;
  final bool buddhist;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final theme = Theme.of(context);
    final hasData =
        points.any((e) => e.incomeSatang > 0 || e.expenseSatang > 0);
    if (!hasData) {
      return const SizedBox(
        height: 160,
        child: EmptyState(
          emoji: '📈',
          title: 'ยังไม่มีข้อมูลให้แสดงกราฟ',
        ),
      );
    }

    var maxY = 0.0;
    for (final e in points) {
      final a = e.incomeSatang / 100;
      final b = e.expenseSatang / 100;
      if (a > maxY) maxY = a;
      if (b > maxY) maxY = b;
    }
    maxY = maxY <= 0 ? 100 : maxY * 1.2;

    final incomeColor = AppColors.successInk;
    final expenseColor = AppColors.dangerInk;

    LineChartBarData line(List<double> ys, Color color) {
      return LineChartBarData(
        spots: [for (var i = 0; i < ys.length; i++) FlSpot(i.toDouble(), ys[i])],
        isCurved: true,
        curveSmoothness: 0.25,
        preventCurveOverShooting: true,
        color: color,
        barWidth: 3.5,
        isStrokeCapRound: true,
        dotData: FlDotData(
          show: points.length <= 6,
          getDotPainter: (a, b, c, d) => FlDotCirclePainter(
            radius: 4,
            color: Colors.white,
            strokeWidth: 2.5,
            strokeColor: color,
          ),
        ),
        belowBarData: BarAreaData(
          show: true,
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              color.withValues(alpha: 0.28),
              color.withValues(alpha: 0.0),
            ],
          ),
        ),
      );
    }

    final step = points.length > 6 ? 2 : 1;

    return Column(
      children: [
        SizedBox(
          height: 220,
          child: LineChart(
            duration: AppDurations.chart,
            curve: Curves.easeOutCubic,
            LineChartData(
              minY: 0,
              maxY: maxY,
              gridData: FlGridData(
                drawVerticalLine: false,
                horizontalInterval: maxY / 4,
                getDrawingHorizontalLine: (_) =>
                    FlLine(color: p.divider, strokeWidth: 1, dashArray: [4, 4]),
              ),
              borderData: FlBorderData(show: false),
              titlesData: FlTitlesData(
                topTitles: const AxisTitles(),
                rightTitles: const AxisTitles(),
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 44,
                    interval: maxY / 4,
                    getTitlesWidget: (v, meta) {
                      if (v == meta.max) return const SizedBox.shrink();
                      return Text(
                        Money.formatCompact((v * 100).round()),
                        style: theme.textTheme.labelSmall,
                      );
                    },
                  ),
                ),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 28,
                    interval: 1,
                    getTitlesWidget: (v, meta) {
                      final i = v.round();
                      if (i < 0 || i >= points.length || i % step != 0) {
                        return const SizedBox.shrink();
                      }
                      final k = AppDates.parseKey(points[i].monthKey);
                      return Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Text(
                          AppDates.thaiMonthsShort[k.month - 1],
                          style: theme.textTheme.labelSmall,
                        ),
                      );
                    },
                  ),
                ),
              ),
              lineTouchData: LineTouchData(
                handleBuiltInTouches: true,
                touchTooltipData: LineTouchTooltipData(
                  getTooltipColor: (_) => p.surface,
                  tooltipBorder: BorderSide(color: p.divider),
                  fitInsideHorizontally: true,
                  fitInsideVertically: true,
                  getTooltipItems: (spots) => [
                    for (final s in spots)
                      LineTooltipItem(
                        '${s.barIndex == 0 ? 'รับ' : 'จ่าย'} ฿${Money.format((s.y * 100).round())}',
                        TextStyle(
                          color: s.barIndex == 0 ? incomeColor : expenseColor,
                          fontWeight: FontWeight.w700,
                          fontSize: 12.5,
                        ),
                      ),
                  ],
                ),
              ),
              lineBarsData: [
                line([for (final e in points) e.incomeSatang / 100], incomeColor),
                line([for (final e in points) e.expenseSatang / 100], expenseColor),
              ],
            ),
          ),
        ),
        const SizedBox(height: AppSpacing.sm),
        Wrap(
          spacing: 16,
          runSpacing: 4,
          alignment: WrapAlignment.center,
          children: [
            _Legend(color: incomeColor, label: 'รายรับ'),
            _Legend(color: expenseColor, label: 'รายจ่าย'),
          ],
        ),
      ],
    );
  }
}

class _Legend extends StatelessWidget {
  const _Legend({required this.color, required this.label});

  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 6),
        Text(label, style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }
}

class _CategoryDonut extends StatefulWidget {
  const _CategoryDonut({
    required this.slices,
    required this.categoryMap,
    required this.total,
  });

  final List<CategoryTotal> slices;
  final Map<int, Category> categoryMap;
  final int total;

  @override
  State<_CategoryDonut> createState() => _CategoryDonutState();
}

class _CategoryDonutState extends State<_CategoryDonut> {
  int _touched = -1;

  Color _colorOf(CategoryTotal s) => s.categoryId == null
      ? AppColors.savingA
      : Color(widget.categoryMap[s.categoryId]?.color ?? AppColors.savingA.toARGB32());

  String _nameOf(CategoryTotal s) =>
      s.categoryId == null ? 'ไม่ระบุหมวด' : (widget.categoryMap[s.categoryId]?.name ?? 'อื่นๆ');

  String _iconOf(CategoryTotal s) =>
      s.categoryId == null ? '➖' : (widget.categoryMap[s.categoryId]?.icon ?? '✨');

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final p = context.palette;
    final slices = widget.slices;
    final total = slices.fold<int>(0, (a, b) => a + b.amountSatang);

    if (slices.isEmpty || total <= 0) {
      return const SizedBox(
        height: 160,
        child: EmptyState(emoji: '🍩', title: 'ยังไม่มีรายจ่ายเดือนนี้'),
      );
    }

    return Column(
      children: [
        SizedBox(
          height: 220,
          child: Stack(
            alignment: Alignment.center,
            children: [
              PieChart(
                duration: AppDurations.chart,
                curve: Curves.easeOutCubic,
                PieChartData(
                  sectionsSpace: 3,
                  centerSpaceRadius: 66,
                  startDegreeOffset: -90,
                  pieTouchData: PieTouchData(
                    touchCallback: (event, response) {
                      final i =
                          response?.touchedSection?.touchedSectionIndex ?? -1;
                      if (!event.isInterestedForInteractions) {
                        if (_touched != -1) setState(() => _touched = -1);
                        return;
                      }
                      if (i != _touched) setState(() => _touched = i);
                    },
                  ),
                  sections: [
                    for (var i = 0; i < slices.length; i++)
                      PieChartSectionData(
                        value: slices[i].amountSatang.toDouble(),
                        color: _colorOf(slices[i]),
                        radius: i == _touched ? 38 : 30,
                        showTitle: false,
                      ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(70),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _touched >= 0 && _touched < slices.length
                            ? _nameOf(slices[_touched])
                            : 'รวม',
                        style: theme.textTheme.bodySmall,
                      ),
                      Text(
                        '฿${Money.format(_touched >= 0 && _touched < slices.length ? slices[_touched].amountSatang : total)}',
                        style: theme.textTheme.titleMedium,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: AppSpacing.sm),
        for (final s in slices)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Row(
              children: [
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    color: _colorOf(s),
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                Text(_iconOf(s)),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    _nameOf(s),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.bodyMedium,
                  ),
                ),
                const SizedBox(width: 8),
                ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 120),
                  child: AmountText(
                    s.amountSatang,
                    alignment: Alignment.centerRight,
                    style: theme.textTheme.bodyMedium,
                  ),
                ),
                SizedBox(
                  width: 44,
                  child: Text(
                    '${IntMath.percentOf(s.amountSatang, total)}%',
                    textAlign: TextAlign.right,
                    style: theme.textTheme.bodySmall?.copyWith(color: p.inkSoft),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}

class _CompareRow extends StatelessWidget {
  const _CompareRow({
    required this.label,
    required this.emoji,
    required this.current,
    required this.previous,
    required this.gradient,
    this.lowerIsBetter = false,
  });

  final String label;
  final String emoji;
  final int current;
  final int previous;
  final LinearGradient gradient;
  final bool lowerIsBetter;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final p = context.palette;
    final change = IntMath.percentChange(previous, current);
    final maxV = [current.abs(), previous.abs(), 1].reduce((a, b) => a > b ? a : b);

    Color? changeColor;
    if (change != null && change != 0) {
      final good = lowerIsBetter ? change < 0 : change > 0;
      changeColor = good ? AppColors.successInk : AppColors.dangerInk;
    }

    Widget bar(String tag, int v, {required bool strong}) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          children: [
            SizedBox(
              width: 52,
              child: Text(tag, style: theme.textTheme.bodySmall),
            ),
            Expanded(
              child: TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: (v.abs() / maxV).clamp(0.0, 1.0)),
                duration: AppDurations.chart,
                curve: Curves.easeOutCubic,
                builder: (context, f, _) => ClipRRect(
                  borderRadius: BorderRadius.circular(AppRadius.pill),
                  child: Stack(
                    children: [
                      Container(height: 10, color: p.divider),
                      FractionallySizedBox(
                        widthFactor: f,
                        child: Container(
                          height: 10,
                          decoration: BoxDecoration(
                            gradient: gradient,
                            backgroundBlendMode: null,
                          ),
                          foregroundDecoration: strong
                              ? null
                              : BoxDecoration(
                                  color: p.surface.withValues(alpha: 0.45),
                                ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 96),
              child: AmountText(
                v,
                showSymbol: false,
                alignment: Alignment.centerRight,
                style: theme.textTheme.bodySmall?.copyWith(color: p.ink),
              ),
            ),
          ],
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Text(emoji),
              const SizedBox(width: 6),
              Expanded(
                child: Text(label, style: theme.textTheme.titleSmall),
              ),
              if (change != null)
                InfoChip(
                  text: change == 0
                      ? 'เท่าเดิม'
                      : '${change > 0 ? '▲' : '▼'} ${change.abs()}%',
                  color: changeColor,
                )
              else
                const InfoChip(text: 'เดือนก่อน 0'),
            ],
          ),
          const SizedBox(height: 4),
          bar('เดือนนี้', current, strong: true),
          bar('เดือนก่อน', previous, strong: false),
        ],
      ),
    );
  }
}
