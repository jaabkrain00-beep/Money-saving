import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/haptics.dart';
import '../../data/db/app_database.dart';
import '../../data/repositories/categories_repository.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';
import '../shared/form_kit.dart';
import '../shared/page_kit.dart';

const List<String> _categoryEmojis = [
  '💰', '🎁', '💼', '📈', '🍜', '🏠', '💡', '🚌', '🛍️', '💊',
  '📚', '💳', '🎬', '👶', '🐶', '☕', '⛽', '📱', '✈️', '🎓',
  '🧴', '🛒', '🎮', '🏋️', '🎂', '🔧', '✨', '🌟',
];

/// จัดการหมวดหมู่รายรับ/รายจ่าย: เพิ่ม แก้ไข ลบ (มี Undo) และลากเรียงลำดับ
class CategoriesScreen extends ConsumerStatefulWidget {
  const CategoriesScreen({super.key});

  @override
  ConsumerState<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends ConsumerState<CategoriesScreen> {
  CategoryType _type = CategoryType.expense;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final p = context.palette;
    final list = _type == CategoryType.expense
        ? ref.watch(expenseCategoriesProvider)
        : ref.watch(incomeCategoriesProvider);

    return Scaffold(
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        slivers: [
          PastelSliverAppBar(
            title: 'หมวดหมู่',
            leading: const PastelBackButton(),
            actions: [
              AppBarIconButton(
                icon: PhosphorIconsBold.plusCircle,
                tooltip: 'เพิ่มหมวดหมู่',
                onPressed: () => showCategoryForm(context, type: _type),
              ),
            ],
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.screenH,
                vertical: AppSpacing.sm,
              ),
              child: SegmentSwitch(
                labels: const ['รายจ่าย', 'รายรับ'],
                index: _type == CategoryType.expense ? 0 : 1,
                gradient: _type == CategoryType.expense
                    ? AppGradients.expense
                    : AppGradients.income,
                onChanged: (i) => setState(
                  () => _type = i == 0 ? CategoryType.expense : CategoryType.income,
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.screenH,
                vertical: 4,
              ),
              child: Text(
                'กดค้างที่ไอคอนด้านขวาแล้วลากเพื่อจัดลำดับ ปัดซ้ายเพื่อลบ',
                style: theme.textTheme.bodySmall,
              ),
            ),
          ),
          if (list.isEmpty)
            SliverFillRemaining(
              hasScrollBody: false,
              child: EmptyState(
                emoji: '🏷️',
                title: 'ยังไม่มีหมวดหมู่',
                actionLabel: 'เพิ่มหมวดหมู่',
                onAction: () => showCategoryForm(context, type: _type),
              ),
            )
          else
            SliverReorderableList(
              itemCount: list.length,
              onReorder: (oldIndex, newIndex) async {
                if (newIndex > oldIndex) newIndex -= 1;
                final ids = [for (final c in list) c.id];
                final moved = ids.removeAt(oldIndex);
                ids.insert(newIndex, moved);
                Haptics.selection();
                await ref.read(categoriesRepositoryProvider).reorder(ids);
              },
              proxyDecorator: (child, _, __) =>
                  Material(color: Colors.transparent, child: child),
              itemBuilder: (context, i) {
                final c = list[i];
                return Padding(
                  key: ValueKey('cat-${c.id}'),
                  padding: const EdgeInsets.symmetric(
                    horizontal: AppSpacing.screenH,
                    vertical: 5,
                  ),
                  child: Dismissible(
                    key: ValueKey('dismiss-cat-${c.id}'),
                    direction: DismissDirection.endToStart,
                    confirmDismiss: (_) async {
                      await _delete(c);
                      return false;
                    },
                    background: Container(
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.only(right: 24),
                      decoration: BoxDecoration(
                        gradient: AppGradients.expense,
                        borderRadius: BorderRadius.circular(AppRadius.r24),
                      ),
                      child: const Icon(PhosphorIconsBold.trash,
                          color: AppColors.ink),
                    ),
                    child: GlassCard(
                      radius: AppRadius.r24,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 8),
                      onTap: () => showCategoryForm(context, editing: c),
                      child: ConstrainedBox(
                        constraints:
                            const BoxConstraints(minHeight: AppSpacing.minTap),
                        child: Row(
                          children: [
                            EmojiBadge(
                              emoji: c.icon,
                              color: Color(c.color),
                              size: 42,
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                c.name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: theme.textTheme.titleSmall,
                              ),
                            ),
                            ReorderableDragStartListener(
                              index: i,
                              child: SizedBox(
                                width: AppSpacing.minTap,
                                height: AppSpacing.minTap,
                                child: Icon(
                                  PhosphorIconsRegular.dotsSixVertical,
                                  color: p.inkSoft,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          const SliverToBoxAdapter(child: SizedBox(height: AppSpacing.huge)),
        ],
      ),
    );
  }

  Future<void> _delete(Category c) async {
    final repo = ref.read(categoriesRepositoryProvider);
    final messenger = ScaffoldMessenger.of(context);
    final used = await repo.usageCount(c.id);
    if (!mounted) return;
    final ok = await showConfirmDialog(
      context,
      title: 'ลบหมวด "${c.name}" ?',
      message: used > 0
          ? 'มี $used รายการใช้หมวดนี้อยู่ รายการเหล่านั้นจะกลายเป็น "ไม่ระบุหมวด"'
          : null,
      confirmLabel: 'ลบ',
      destructive: true,
    );
    if (!ok) return;
    final snapshot = await repo.deleteCategory(c.id);
    Haptics.medium();
    showUndoSnackBarOn(
      messenger,
      message: 'ลบหมวด "${c.name}" แล้ว',
      onUndo: () => repo.restoreCategory(snapshot),
    );
  }
}

Future<void> showCategoryForm(
  BuildContext context, {
  Category? editing,
  CategoryType type = CategoryType.expense,
}) {
  return showFormSheet<void>(
    context,
    builder: (_) => _CategoryFormSheet(editing: editing, type: type),
  );
}

class _CategoryFormSheet extends ConsumerStatefulWidget {
  const _CategoryFormSheet({this.editing, required this.type});

  final Category? editing;
  final CategoryType type;

  @override
  ConsumerState<_CategoryFormSheet> createState() => _CategoryFormSheetState();
}

class _CategoryFormSheetState extends ConsumerState<_CategoryFormSheet> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late String _icon;
  late int _color;
  late CategoryType _type;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final c = widget.editing;
    _name = TextEditingController(text: c?.name ?? '');
    _icon = c?.icon ?? '✨';
    _color = c?.color ?? AppColors.pickerColors[6].toARGB32();
    _type = c?.type ?? widget.type;
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!(_formKey.currentState?.validate() ?? false)) {
      Haptics.medium();
      return;
    }
    final repo = ref.read(categoriesRepositoryProvider);
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);
    setState(() => _saving = true);
    try {
      final c = widget.editing;
      if (c == null) {
        await repo.addCategory(
          CategoryInput(
            name: _name.text.trim(),
            type: _type,
            color: _color,
            icon: _icon,
          ),
        );
      } else {
        await repo.updateCategory(
          c.copyWith(name: _name.text.trim(), icon: _icon, color: _color),
        );
      }
      Haptics.light();
      navigator.pop();
      showAppSnackBarOn(messenger, 'บันทึกหมวดหมู่แล้ว', emoji: '🏷️');
    } catch (_) {
      if (mounted) setState(() => _saving = false);
      showAppSnackBarOn(messenger, 'บันทึกไม่สำเร็จ ลองใหม่อีกครั้ง', emoji: '😢');
    }
  }

  @override
  Widget build(BuildContext context) {
    final pal = context.palette;
    return Form(
      key: _formKey,
      child: FormSheetScaffold(
        emoji: _icon,
        title: widget.editing == null ? 'เพิ่มหมวดหมู่' : 'แก้ไขหมวดหมู่',
        saving: _saving,
        onSave: _save,
        children: [
          if (widget.editing == null) ...[
            SegmentSwitch(
              labels: const ['รายจ่าย', 'รายรับ'],
              index: _type == CategoryType.expense ? 0 : 1,
              onChanged: (i) => setState(
                () => _type =
                    i == 0 ? CategoryType.expense : CategoryType.income,
              ),
            ),
          ],
          const FieldLabel('ชื่อหมวดหมู่'),
          NameField(controller: _name, hint: 'เช่น กาแฟ, ค่าโทรศัพท์', maxLength: 30),
          const FieldLabel('ไอคอน'),
          Wrap(
            spacing: AppSpacing.sm,
            runSpacing: AppSpacing.sm,
            children: [
              for (final e in _categoryEmojis)
                Semantics(
                  button: true,
                  label: 'เลือกไอคอน $e',
                  child: GestureDetector(
                    onTap: () {
                      Haptics.selection();
                      setState(() => _icon = e);
                    },
                    child: AnimatedContainer(
                      duration: AppDurations.fast,
                      width: AppSpacing.minTap,
                      height: AppSpacing.minTap,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: _icon == e
                            ? Color(_color).withValues(alpha: 0.5)
                            : pal.inputFill,
                        borderRadius: BorderRadius.circular(AppRadius.r16),
                        border: Border.all(
                          color: _icon == e ? Color(_color) : Colors.transparent,
                          width: 2,
                        ),
                      ),
                      child: Text(e, style: const TextStyle(fontSize: 24)),
                    ),
                  ),
                ),
            ],
          ),
          const FieldLabel('สี'),
          Wrap(
            spacing: AppSpacing.md,
            runSpacing: AppSpacing.sm,
            children: [
              for (final c in AppColors.pickerColors)
                GestureDetector(
                  onTap: () {
                    Haptics.selection();
                    setState(() => _color = c.toARGB32());
                  },
                  child: SizedBox(
                    width: AppSpacing.minTap,
                    height: AppSpacing.minTap,
                    child: Center(
                      child: AnimatedContainer(
                        duration: AppDurations.fast,
                        width: _color == c.toARGB32() ? 40 : 34,
                        height: _color == c.toARGB32() ? 40 : 34,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: AppGradients.fromColor(c),
                          border: Border.all(
                            color: _color == c.toARGB32()
                                ? pal.ink
                                : Colors.white.withValues(alpha: 0.8),
                            width: _color == c.toARGB32() ? 2.5 : 1.5,
                          ),
                        ),
                        child: _color == c.toARGB32()
                            ? const Icon(PhosphorIconsBold.check,
                                size: 18, color: AppColors.ink)
                            : null,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: AppSpacing.sm),
        ],
      ),
    );
  }
}
