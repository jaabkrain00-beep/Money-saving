import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/app_dates.dart';
import '../../core/utils/haptics.dart';
import '../../data/db/app_database.dart';
import '../../data/repositories/settings_repository.dart';
import '../../data/settings_keys.dart';
import '../../domain/status_rules.dart';
import '../../providers/providers.dart';
import '../../services/notification_service.dart';
import '../../widgets/widgets.dart';
import '../shared/entry_card.dart';
import '../shared/form_kit.dart';
import '../shared/page_kit.dart';

/// หน้าการแจ้งเตือน: ตั้งค่าเตือน + รายการที่เลยกำหนด/ใกล้ครบกำหนด/ที่จะถึง
class NotificationsScreen extends ConsumerStatefulWidget {
  const NotificationsScreen({super.key});

  @override
  ConsumerState<NotificationsScreen> createState() =>
      _NotificationsScreenState();
}

class _NotificationsScreenState extends ConsumerState<NotificationsScreen> {
  bool? _allowed;

  @override
  void initState() {
    super.initState();
    _refreshPermission();
  }

  Future<void> _refreshPermission() async {
    final ok = await NotificationService.instance.notificationsEnabled();
    if (mounted) setState(() => _allowed = ok);
  }

  Future<void> _askPermission() async {
    await NotificationService.instance.requestPermissions();
    await _refreshPermission();
    await NotificationService.instance.rescheduleAll(ref.read(databaseProvider));
  }

  Future<void> _pickTime(SettingsState s) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: s.remindHour, minute: s.remindMinute),
      builder: (ctx, child) => MediaQuery(
        data: MediaQuery.of(ctx).copyWith(alwaysUse24HourFormat: true),
        child: child!,
      ),
    );
    if (picked != null) {
      await ref
          .read(settingsRepositoryProvider)
          .setRemindTime(AppDates.formatTime(picked.hour, picked.minute));
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final p = context.palette;
    final s = ref.watch(settingsProvider);
    final repo = ref.read(settingsRepositoryProvider);
    final unpaid =
        ref.watch(unpaidExpensesProvider).valueOrNull ?? const <ExpenseEntry>[];
    final categoryMap = ref.watch(categoryMapProvider);
    final buddhist = ref.watch(useBuddhistYearProvider);
    final today = AppDates.dateOnly(DateTime.now());

    final overdue = <ExpenseEntry>[];
    final soon = <ExpenseEntry>[];
    final later = <ExpenseEntry>[];
    for (final e in unpaid) {
      switch (ExpenseRules.bucket(dueDate: e.dueDate, today: today)) {
        case DueBucket.overdue:
          overdue.add(e);
        case DueBucket.today:
        case DueBucket.thisWeek:
          soon.add(e);
        case DueBucket.later:
          later.add(e);
      }
    }

    Widget group(String title, List<ExpenseEntry> items, {int limit = 50}) {
      if (items.isEmpty) return const SliverToBoxAdapter(child: SizedBox.shrink());
      final shown = items.take(limit).toList();
      return SliverMainAxisGroup(
        slivers: [
          SliverToBoxAdapter(child: SectionHeader(title: '$title (${items.length})')),
          SliverList.builder(
            itemCount: shown.length,
            itemBuilder: (context, i) {
              final e = shown[i];
              final days = AppDates.daysBetween(today, e.dueDate);
              final text = days < 0
                  ? 'เลยกำหนด ${-days} วัน'
                  : (days == 0 ? 'ครบกำหนดวันนี้' : 'อีก $days วัน');
              final c = categoryMap[e.categoryId];
              return EntryCard(
                slidableKey: ValueKey('noti-${e.id}'),
                index: i,
                emoji: c?.icon ?? '🧾',
                color: Color(c?.color ?? AppColors.expenseA.toARGB32()),
                title: e.name,
                subtitle:
                    '$text · ${AppDates.formatDayMonth(e.dueDate, buddhist: buddhist)}',
                amountSatang: e.amountSatang,
                amountColor: AppColors.dangerInk,
                trailingAction: MiniActionButton(
                  label: 'จ่ายเลย',
                  icon: PhosphorIconsBold.check,
                  onTap: () async {
                    Haptics.medium();
                    final messenger = ScaffoldMessenger.of(context);
                    final r = ref.read(expenseRepositoryProvider);
                    await r.setPaid(e.id, true);
                    showUndoSnackBarOn(
                      messenger,
                      message: 'จ่าย "${e.name}" แล้ว ✅',
                      onUndo: () => r.setPaid(e.id, false),
                    );
                  },
                ),
              );
            },
          ),
        ],
      );
    }

    return Scaffold(
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        slivers: [
          const PastelSliverAppBar(
            title: 'การแจ้งเตือน',
            leading: PastelBackButton(),
          ),
          if (_allowed == false)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSpacing.screenH,
                  vertical: AppSpacing.sm,
                ),
                child: GradientCard(
                  gradient: AppGradients.statusDueSoon,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text('ยังไม่ได้อนุญาตการแจ้งเตือน 🔕',
                          style: theme.textTheme.titleSmall),
                      const SizedBox(height: 4),
                      Text(
                        'เปิดสิทธิ์เพื่อให้แอปเตือนก่อนครบกำหนดจ่ายและวันเงินเข้า',
                        style: theme.textTheme.bodyMedium,
                      ),
                      const SizedBox(height: AppSpacing.md),
                      GradientButton(
                        label: 'อนุญาตการแจ้งเตือน',
                        expand: true,
                        onPressed: _askPermission,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.screenH,
                vertical: AppSpacing.sm,
              ),
              child: GlassCard(
                radius: AppRadius.r24,
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    SwitchListTile.adaptive(
                      contentPadding: EdgeInsets.zero,
                      value: s.notifyExpense,
                      title: const Text('เตือนก่อนครบกำหนดจ่าย'),
                      onChanged: (v) =>
                          repo.setBool(SettingKeys.notifyExpense, v),
                    ),
                    SwitchListTile.adaptive(
                      contentPadding: EdgeInsets.zero,
                      value: s.notifyPayday,
                      title: const Text('เตือนวันเงินเข้า'),
                      onChanged: (v) =>
                          repo.setBool(SettingKeys.notifyPayday, v),
                    ),
                    const FieldLabel('เตือนล่วงหน้า'),
                    Wrap(
                      spacing: AppSpacing.sm,
                      runSpacing: AppSpacing.sm,
                      children: [
                        for (final d in SettingsState.remindDayOptions)
                          _DayChip(
                            label: d == 0 ? 'วันครบกำหนด' : '$d วัน',
                            selected: s.remindDaysBefore == d,
                            onTap: () => repo.setRemindDays(d),
                          ),
                      ],
                    ),
                    const FieldLabel('เวลาแจ้งเตือน'),
                    PressableScale(
                      onTap: () => _pickTime(s),
                      child: Container(
                        constraints: const BoxConstraints(minHeight: 56),
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        decoration: BoxDecoration(
                          color: p.inputFill,
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Row(
                          children: [
                            Icon(PhosphorIconsRegular.clock,
                                size: 20, color: p.inkSoft),
                            const SizedBox(width: 10),
                            Text('${s.remindTime} น.'),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSpacing.md),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: TextButton.icon(
                        onPressed: () async {
                          await NotificationService.instance
                              .requestPermissions();
                          await NotificationService.instance.showTest();
                          _refreshPermission();
                        },
                        icon: const Icon(PhosphorIconsRegular.bellRinging),
                        label: const Text('ทดสอบการแจ้งเตือน'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          if (unpaid.isEmpty)
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 260,
                child: EmptyState(
                  emoji: '🎉',
                  title: 'ไม่มีรายการค้างจ่าย',
                  message: 'ทุกอย่างเรียบร้อย ไม่มีอะไรต้องเตือน',
                  gradient: AppGradients.income,
                ),
              ),
            ),
          group('เลยกำหนดแล้ว', overdue),
          group('วันนี้ - 7 วันข้างหน้า', soon),
          group('ที่จะถึง', later, limit: 10),
          const SliverToBoxAdapter(child: SizedBox(height: AppSpacing.huge)),
        ],
      ),
    );
  }
}

class _DayChip extends StatelessWidget {
  const _DayChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return PressableScale(
      onTap: onTap,
      child: ConstrainedBox(
        constraints: const BoxConstraints(minHeight: AppSpacing.minTap),
        child: Center(
          child: AnimatedContainer(
            duration: AppDurations.fast,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              gradient: selected ? AppGradients.expense : null,
              color: selected ? null : p.inputFill,
              borderRadius: BorderRadius.circular(AppRadius.pill),
            ),
            child: Text(
              label,
              style: TextStyle(
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                color: selected ? AppColors.ink : p.ink,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
