import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/haptics.dart';
import '../../core/utils/labels.dart';
import '../../data/db/app_database.dart';
import '../../widgets/widgets.dart';

/// การกระทำที่โผล่ตอนปัดการ์ดไปทางซ้าย
class CardSwipeAction {
  const CardSwipeAction({
    required this.label,
    required this.icon,
    required this.gradient,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final LinearGradient gradient;
  final VoidCallback onTap;
}

/// การ์ดรายการ (ใช้ร่วมกันของรายรับ/รายจ่าย)
/// - ปัดซ้าย: แก้ไข/ลบ  - แตะ: ดูรายละเอียด
/// - ข้อความทุกส่วนตัดด้วย ellipsis และจำนวนเงินย่อให้พอดี ไม่ล้นที่ 360dp / ตัวอักษร 1.3x
class EntryCard extends StatelessWidget {
  const EntryCard({
    super.key,
    required this.slidableKey,
    required this.emoji,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.amountSatang,
    this.amountColor,
    this.chips = const [],
    this.footer,
    this.trailingAction,
    this.swipeActions = const [],
    this.onTap,
    this.index = 0,
    this.strikeTitle = false,
    this.leading,
  });

  final Key slidableKey;
  final String emoji;
  final Color color;
  final String title;
  final String subtitle;
  final int amountSatang;
  final Color? amountColor;
  final List<Widget> chips;
  final Widget? footer;

  /// ปุ่มด่วนใต้จำนวนเงิน เช่น "จ่ายเลย"
  final Widget? trailingAction;
  final List<CardSwipeAction> swipeActions;
  final VoidCallback? onTap;
  final int index;
  final bool strikeTitle;

  /// แทนที่ไอคอนอีโมจิด้านหน้า (เช่น รูปสมาชิก)
  final Widget? leading;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final p = context.palette;
    final textScale = MediaQuery.textScalerOf(context).scale(1);
    final wide = textScale > 1.15;

    final card = GlassCard(
      radius: AppRadius.r24,
      padding: const EdgeInsets.all(14),
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              leading ?? EmojiBadge(emoji: emoji, color: color, size: 46),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.titleSmall?.copyWith(
                        decoration:
                            strikeTitle ? TextDecoration.lineThrough : null,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodySmall
                          ?.copyWith(color: p.inkSoft),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              ConstrainedBox(
                constraints: BoxConstraints(maxWidth: wide ? 120 : 132),
                child: AmountText(
                  amountSatang,
                  alignment: Alignment.centerRight,
                  style: theme.textTheme.titleMedium?.copyWith(
                    color: amountColor ?? p.ink,
                  ),
                ),
              ),
            ],
          ),
          if (chips.isNotEmpty || trailingAction != null) ...[
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: chips,
                  ),
                ),
                if (trailingAction != null) ...[
                  const SizedBox(width: 8),
                  trailingAction!,
                ],
              ],
            ),
          ],
          if (footer != null) ...[
            const SizedBox(height: 10),
            footer!,
          ],
        ],
      ),
    );

    Widget child = card;
    if (swipeActions.isNotEmpty) {
      child = Slidable(
        key: slidableKey,
        endActionPane: ActionPane(
          motion: const BehindMotion(),
          extentRatio: swipeActions.length == 1 ? 0.3 : 0.52,
          children: [
            for (final a in swipeActions)
              CustomSlidableAction(
                padding: EdgeInsets.zero,
                backgroundColor: Colors.transparent,
                foregroundColor: AppColors.ink,
                onPressed: (_) {
                  Haptics.light();
                  a.onTap();
                },
                child: Padding(
                  padding: const EdgeInsets.only(left: 8),
                  child: Container(
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration(
                      gradient: a.gradient,
                      borderRadius: BorderRadius.circular(AppRadius.r24),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(a.icon, size: 22, color: AppColors.ink),
                        const SizedBox(height: 4),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: FittedBox(
                            fit: BoxFit.scaleDown,
                            child: Text(
                              a.label,
                              maxLines: 1,
                              style: const TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w700,
                                color: AppColors.ink,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
        child: card,
      );
    }

    return StaggeredItem(
      index: index,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.screenH,
          vertical: 5,
        ),
        child: child,
      ),
    );
  }
}

/// ปุ่มกดเล็กแบบ gradient ใช้เป็นปุ่มด่วนในการ์ด (สูง ≥ 40 และพื้นที่กดขยายเป็น 48)
class MiniActionButton extends StatelessWidget {
  const MiniActionButton({
    super.key,
    required this.label,
    required this.onTap,
    this.icon,
    this.gradient = AppGradients.income,
  });

  final String label;
  final VoidCallback onTap;
  final IconData? icon;
  final LinearGradient gradient;

  @override
  Widget build(BuildContext context) {
    return PressableScale(
      onTap: onTap,
      semanticLabel: label,
      child: ConstrainedBox(
        constraints: const BoxConstraints(
          minHeight: AppSpacing.minTap,
          maxWidth: 150,
        ),
        child: Center(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              gradient: gradient,
              borderRadius: BorderRadius.circular(AppRadius.pill),
              border: Border.all(color: Colors.white.withValues(alpha: 0.7)),
              boxShadow: AppShadows.soft(
                gradient.colors.first,
                opacity: 0.35,
                blur: 10,
                dy: 3,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (icon != null) ...[
                  Icon(icon, size: 16, color: AppColors.ink),
                  const SizedBox(width: 4),
                ],
                Flexible(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: AppColors.ink,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// ชิปข้อมูลเล็กๆ (สมาชิก / หมวดหมู่ / วันที่) สีกลาง ไม่ฉูดฉาด
class InfoChip extends StatelessWidget {
  const InfoChip({super.key, required this.text, this.emoji, this.color});

  final String text;
  final String? emoji;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      constraints: BoxConstraints(
        maxWidth: MediaQuery.of(context).size.width * 0.42,
      ),
      decoration: BoxDecoration(
        color: (color ?? p.inkSoft).withValues(alpha: p.isDark ? 0.25 : 0.16),
        borderRadius: BorderRadius.circular(AppRadius.pill),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (emoji != null) ...[
            Text(emoji!, style: const TextStyle(fontSize: 12)),
            const SizedBox(width: 4),
          ],
          Flexible(
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 12, color: p.ink),
            ),
          ),
        ],
      ),
    );
  }
}

/// แถวตัวกรองสมาชิก (ทั้งหมด / รายคน) เลื่อนแนวนอนได้
class MemberFilterBar extends StatelessWidget {
  const MemberFilterBar({
    super.key,
    required this.members,
    required this.selectedId,
    required this.onChanged,
  });

  final List<Member> members;
  final int? selectedId;
  final ValueChanged<int?> onChanged;

  @override
  Widget build(BuildContext context) {
    if (members.isEmpty) return const SizedBox.shrink();
    final p = context.palette;

    Widget chip(String label, bool selected, VoidCallback onTap) {
      return Padding(
        padding: const EdgeInsets.only(right: 8),
        child: PressableScale(
          onTap: onTap,
          child: ConstrainedBox(
            constraints: const BoxConstraints(minHeight: AppSpacing.minTap),
            child: Center(
              child: AnimatedContainer(
                duration: AppDurations.fast,
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  gradient: selected ? AppGradients.brand : null,
                  color: selected ? null : p.inputFill,
                  borderRadius: BorderRadius.circular(AppRadius.pill),
                ),
                child: Text(
                  label,
                  maxLines: 1,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                    color: selected ? AppColors.ink : p.ink,
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    }

    return SizedBox(
      height: AppSpacing.minTap + 4,
      child: ListView(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH),
        children: [
          chip('ทั้งหมด', selectedId == null, () => onChanged(null)),
          for (final m in members)
            chip(
              '${memberEmoji(m)} ${memberLabel(m)}',
              selectedId == m.id,
              () => onChanged(m.id),
            ),
        ],
      ),
    );
  }
}
