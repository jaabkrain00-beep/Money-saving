import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../widgets/widgets.dart';

class DetailRowData {
  const DetailRowData(this.label, this.value);

  final String label;
  final String value;
}

class DetailAction {
  const DetailAction({
    required this.label,
    required this.icon,
    required this.onTap,
    this.gradient = AppGradients.brand,
  });

  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final LinearGradient gradient;
}

/// หน้ารายละเอียดรายการ (Bottom Sheet) แตะรายการในลิสต์เพื่อเปิด
Future<void> showEntryDetailSheet(
  BuildContext context, {
  required String emoji,
  required Color color,
  required String title,
  required int amountSatang,
  required List<Widget> chips,
  required List<DetailRowData> rows,
  required List<DetailAction> actions,
  String? note,
}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    builder: (ctx) {
      final theme = Theme.of(ctx);
      final p = ctx.palette;
      return SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.screenH,
          0,
          AppSpacing.screenH,
          AppSpacing.xxl,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                EmojiBadge(emoji: emoji, color: color, size: 56),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.titleMedium,
                      ),
                      const SizedBox(height: 2),
                      AmountText(
                        amountSatang,
                        animate: true,
                        style: theme.textTheme.headlineSmall,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            if (chips.isNotEmpty) ...[
              const SizedBox(height: AppSpacing.md),
              Wrap(spacing: 6, runSpacing: 6, children: chips),
            ],
            const SizedBox(height: AppSpacing.lg),
            GlassCard(
              radius: AppRadius.r20,
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.lg,
                vertical: AppSpacing.sm,
              ),
              child: Column(
                children: [
                  for (var i = 0; i < rows.length; i++) ...[
                    if (i > 0) Divider(height: 1, color: p.divider),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 4,
                            child: Text(
                              rows[i].label,
                              style: theme.textTheme.bodyMedium
                                  ?.copyWith(color: p.inkSoft),
                            ),
                          ),
                          Expanded(
                            flex: 6,
                            child: Text(
                              rows[i].value,
                              textAlign: TextAlign.right,
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
            if (note != null && note.trim().isNotEmpty) ...[
              const SizedBox(height: AppSpacing.md),
              GlassCard(
                radius: AppRadius.r20,
                padding: const EdgeInsets.all(AppSpacing.lg),
                child: Text('📝  ${note.trim()}',
                    style: theme.textTheme.bodyMedium),
              ),
            ],
            const SizedBox(height: AppSpacing.xl),
            for (final a in actions) ...[
              GradientButton(
                label: a.label,
                icon: a.icon,
                expand: true,
                gradient: a.gradient,
                onPressed: () {
                  Navigator.of(ctx).pop();
                  a.onTap();
                },
              ),
              const SizedBox(height: AppSpacing.sm),
            ],
          ],
        ),
      );
    },
  );
}
