import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/amount_input_formatter.dart';
import '../../core/utils/app_dates.dart';
import '../../core/utils/haptics.dart';
import '../../core/utils/labels.dart';
import '../../core/utils/money.dart';
import '../../data/db/app_database.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';

/// เปิดฟอร์มแบบ Bottom Sheet โค้งมน เลื่อนหนีคีย์บอร์ดอัตโนมัติ
Future<T?> showFormSheet<T>(
  BuildContext context, {
  required WidgetBuilder builder,
}) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
      child: builder(ctx),
    ),
  );
}

/// โครงฟอร์ม: หัวเรื่อง + เนื้อหาเลื่อนได้ + ปุ่มบันทึกติดด้านล่าง
class FormSheetScaffold extends StatelessWidget {
  const FormSheetScaffold({
    super.key,
    required this.emoji,
    required this.title,
    required this.children,
    required this.onSave,
    this.saveLabel = 'บันทึก',
    this.gradient = AppGradients.brand,
    this.saving = false,
  });

  final String emoji;
  final String title;
  final List<Widget> children;
  final VoidCallback onSave;
  final String saveLabel;
  final LinearGradient gradient;
  final bool saving;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenH,
            0,
            AppSpacing.screenH,
            AppSpacing.md,
          ),
          child: Row(
            children: [
              Text(emoji, style: const TextStyle(fontSize: 26)),
              const SizedBox(width: AppSpacing.sm),
              Expanded(
                child: Text(
                  title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.titleLarge,
                ),
              ),
            ],
          ),
        ),
        Flexible(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenH),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: children,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenH,
            AppSpacing.md,
            AppSpacing.screenH,
            AppSpacing.lg,
          ),
          child: GradientButton(
            label: saveLabel,
            expand: true,
            gradient: gradient,
            loading: saving,
            onPressed: onSave,
          ),
        ),
      ],
    );
  }
}

/// ป้ายกำกับเหนือช่องกรอก
class FieldLabel extends StatelessWidget {
  const FieldLabel(this.text, {super.key, this.trailing});

  final String text;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(top: AppSpacing.lg, bottom: AppSpacing.sm),
      child: Row(
        children: [
          Expanded(
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.labelLarge
                  ?.copyWith(color: context.palette.inkSoft),
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

/// ช่องกรอกชื่อรายการ
class NameField extends StatelessWidget {
  const NameField({
    super.key,
    required this.controller,
    this.hint = 'เช่น เงินเดือน',
    this.maxLength = 60,
  });

  final TextEditingController controller;
  final String hint;
  final int maxLength;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      maxLength: maxLength,
      textInputAction: TextInputAction.next,
      textCapitalization: TextCapitalization.sentences,
      decoration: InputDecoration(hintText: hint, counterText: ''),
      validator: (v) =>
          (v == null || v.trim().isEmpty) ? 'กรุณากรอกชื่อรายการ' : null,
    );
  }
}

/// ช่องกรอกจำนวนเงิน (คีย์บอร์ดตัวเลข, ใส่ลูกน้ำให้อัตโนมัติ, ทศนิยมไม่เกิน 2 ตำแหน่ง)
class AmountField extends StatelessWidget {
  const AmountField({
    super.key,
    required this.controller,
    this.hint = '0.00',
    this.allowZero = false,
    this.autofocus = false,
  });

  final TextEditingController controller;
  final String hint;
  final bool allowZero;
  final bool autofocus;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      autofocus: autofocus,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      textInputAction: TextInputAction.next,
      inputFormatters: [
        AmountInputFormatter(),
        LengthLimitingTextInputFormatter(16),
      ],
      style: Theme.of(context).textTheme.titleMedium,
      decoration: InputDecoration(
        hintText: hint,
        prefixIcon: const Padding(
          padding: EdgeInsets.only(left: 16, right: 8),
          child: Text('฿', style: TextStyle(fontSize: 18)),
        ),
        prefixIconConstraints: const BoxConstraints(minWidth: 0, minHeight: 0),
      ),
      validator: (v) {
        final satang = Money.parse(v ?? '');
        if (satang == null) return 'กรุณากรอกจำนวนเงิน';
        if (satang < 0 || (satang == 0 && !allowZero)) {
          return 'จำนวนเงินต้องมากกว่า 0';
        }
        return null;
      },
    );
  }
}

/// ตัวเลือกสมาชิกแบบ Chip (มี "ส่วนกลาง" = ไม่ระบุคน)
class MemberChips extends ConsumerWidget {
  const MemberChips({
    super.key,
    required this.selectedId,
    required this.onChanged,
  });

  final int? selectedId;
  final ValueChanged<int?> onChanged;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final members = ref.watch(membersProvider).valueOrNull ?? const <Member>[];
    return Wrap(
      spacing: AppSpacing.sm,
      runSpacing: AppSpacing.sm,
      children: [
        _PickChip(
          emoji: '🏠',
          label: 'ส่วนกลาง',
          selected: selectedId == null,
          onTap: () => onChanged(null),
        ),
        for (final m in members)
          _PickChip(
            emoji: memberEmoji(m),
            label: memberLabel(m),
            color: Color(m.color),
            selected: selectedId == m.id,
            onTap: () => onChanged(m.id),
          ),
      ],
    );
  }
}

/// ตัวเลือกหมวดหมู่แบบ Chip
class CategoryChips extends StatelessWidget {
  const CategoryChips({
    super.key,
    required this.categories,
    required this.selectedId,
    required this.onChanged,
  });

  final List<Category> categories;
  final int? selectedId;
  final ValueChanged<int?> onChanged;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: AppSpacing.sm,
      runSpacing: AppSpacing.sm,
      children: [
        _PickChip(
          emoji: '➖',
          label: 'ไม่ระบุ',
          selected: selectedId == null,
          onTap: () => onChanged(null),
        ),
        for (final c in categories)
          _PickChip(
            emoji: c.icon,
            label: c.name,
            color: Color(c.color),
            selected: selectedId == c.id,
            onTap: () => onChanged(c.id),
          ),
      ],
    );
  }
}

class _PickChip extends StatelessWidget {
  const _PickChip({
    required this.emoji,
    required this.label,
    required this.selected,
    required this.onTap,
    this.color,
  });

  final String emoji;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final base = color ?? AppColors.brandA;
    return PressableScale(
      onTap: () {
        Haptics.selection();
        onTap();
      },
      semanticLabel: label,
      child: AnimatedContainer(
        duration: AppDurations.fast,
        constraints: const BoxConstraints(minHeight: AppSpacing.minTap - 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          gradient: selected ? AppGradients.fromColor(base) : null,
          color: selected ? null : p.inputFill,
          borderRadius: BorderRadius.circular(AppRadius.pill),
          border: Border.all(
            color: selected ? Colors.white.withValues(alpha: 0.8) : p.divider,
            width: selected ? 1.5 : 1,
          ),
          boxShadow: selected
              ? AppShadows.soft(base, opacity: 0.35, blur: 10, dy: 4)
              : null,
        ),
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.6,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(emoji, style: const TextStyle(fontSize: 16)),
              const SizedBox(width: 6),
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                    color: selected ? AppColors.ink : p.ink,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// สลับ 2 โหมด เช่น "ประจำทุกเดือน" / "ครั้งเดียว"
class SegmentSwitch extends StatelessWidget {
  const SegmentSwitch({
    super.key,
    required this.labels,
    required this.index,
    required this.onChanged,
    this.gradient = AppGradients.brand,
  });

  final List<String> labels;
  final int index;
  final ValueChanged<int> onChanged;
  final LinearGradient gradient;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: p.inputFill,
        borderRadius: BorderRadius.circular(AppRadius.r20),
      ),
      child: Row(
        children: [
          for (var i = 0; i < labels.length; i++)
            Expanded(
              child: PressableScale(
                onTap: () {
                  Haptics.selection();
                  onChanged(i);
                },
                child: AnimatedContainer(
                  duration: AppDurations.fast,
                  constraints:
                      const BoxConstraints(minHeight: AppSpacing.minTap - 4),
                  alignment: Alignment.center,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: i == index ? gradient : null,
                    borderRadius: BorderRadius.circular(AppRadius.r16),
                    boxShadow: i == index
                        ? AppShadows.soft(gradient.colors.first,
                            opacity: 0.35, blur: 10, dy: 3)
                        : null,
                  ),
                  child: Text(
                    labels[i],
                    maxLines: 2,
                    textAlign: TextAlign.center,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight:
                          i == index ? FontWeight.w700 : FontWeight.w500,
                      color: i == index ? AppColors.ink : p.inkSoft,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// ช่องเลือกวันที่ (แตะแล้วเปิดปฏิทิน) แสดงปีตามการตั้งค่า พ.ศ./ค.ศ.
class DateField extends ConsumerWidget {
  const DateField({
    super.key,
    required this.value,
    required this.onChanged,
    this.firstDate,
    this.lastDate,
  });

  final DateTime value;
  final ValueChanged<DateTime> onChanged;
  final DateTime? firstDate;
  final DateTime? lastDate;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final buddhist = ref.watch(useBuddhistYearProvider);
    return _TapField(
      icon: PhosphorIconsRegular.calendarBlank,
      text: AppDates.formatDayMonth(value, withYear: true, buddhist: buddhist),
      onTap: () async {
        final picked = await showDatePicker(
          context: context,
          initialDate: value,
          firstDate: firstDate ?? DateTime(2000),
          lastDate: lastDate ?? DateTime(2100),
          locale: const Locale('th', 'TH'),
        );
        if (picked != null) onChanged(AppDates.dateOnly(picked));
      },
    );
  }
}

/// ช่องเลือก "วันที่ของเดือน" 1-31 (เดือนสั้นจะใช้วันสุดท้ายของเดือนให้อัตโนมัติ)
class DayOfMonthField extends StatelessWidget {
  const DayOfMonthField({
    super.key,
    required this.value,
    required this.onChanged,
    this.suffix = 'ของทุกเดือน',
  });

  final int value;
  final ValueChanged<int> onChanged;
  final String suffix;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        DropdownButtonFormField<int>(
          value: value,
          isExpanded: true,
          menuMaxHeight: 320,
          borderRadius: BorderRadius.circular(AppRadius.r20),
          decoration: const InputDecoration(),
          items: [
            for (var d = 1; d <= 31; d++)
              DropdownMenuItem(
                value: d,
                child: Text('วันที่ $d $suffix', overflow: TextOverflow.ellipsis),
              ),
          ],
          onChanged: (v) {
            if (v != null) onChanged(v);
          },
        ),
        if (value > 28)
          Padding(
            padding: const EdgeInsets.only(top: 6, left: 4),
            child: Text(
              'เดือนที่มีวันน้อยกว่านี้ ระบบจะใช้วันสุดท้ายของเดือนให้',
              style: Theme.of(context)
                  .textTheme
                  .bodySmall
                  ?.copyWith(color: context.palette.inkSoft),
            ),
          ),
      ],
    );
  }
}

/// ช่องเลือกเดือน (yyyy-MM) พร้อมปุ่มล้างค่า (ถ้า [onCleared] ไม่เป็น null)
class MonthKeyField extends ConsumerWidget {
  const MonthKeyField({
    super.key,
    required this.value,
    required this.onChanged,
    this.placeholder = 'เลือกเดือน',
    this.onCleared,
    this.minKey,
  });

  final String? value;
  final ValueChanged<String> onChanged;
  final String placeholder;
  final VoidCallback? onCleared;
  final String? minKey;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final buddhist = ref.watch(useBuddhistYearProvider);
    final v = value;
    return _TapField(
      icon: PhosphorIconsRegular.calendarDots,
      text: v == null
          ? placeholder
          : AppDates.formatMonthYearFromKey(v, buddhist: buddhist),
      muted: v == null,
      onClear: (v != null && onCleared != null) ? onCleared : null,
      onTap: () async {
        final picked = await showMonthKeyPicker(
          context,
          initial: v ?? AppDates.monthKey(DateTime.now()),
          buddhist: buddhist,
          minKey: minKey,
        );
        if (picked != null) onChanged(picked);
      },
    );
  }
}

class _TapField extends StatelessWidget {
  const _TapField({
    required this.icon,
    required this.text,
    required this.onTap,
    this.muted = false,
    this.onClear,
  });

  final IconData icon;
  final String text;
  final VoidCallback onTap;
  final bool muted;
  final VoidCallback? onClear;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return PressableScale(
      onTap: onTap,
      scale: 0.99,
      child: Container(
        constraints: const BoxConstraints(minHeight: 56),
        padding: const EdgeInsets.only(left: 16, right: 8),
        decoration: BoxDecoration(
          color: p.inputFill,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
          children: [
            Icon(icon, size: 20, color: p.inkSoft),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 15,
                  color: muted ? p.inkSoft : p.ink,
                ),
              ),
            ),
            if (onClear != null)
              IconButton(
                tooltip: 'ล้างค่า',
                constraints: const BoxConstraints(
                  minWidth: AppSpacing.minTap,
                  minHeight: AppSpacing.minTap,
                ),
                icon: Icon(PhosphorIconsRegular.x, size: 18, color: p.inkSoft),
                onPressed: onClear,
              )
            else
              const SizedBox(width: 8),
          ],
        ),
      ),
    );
  }
}

/// เลือกเดือน/ปีแบบ Dialog: ลูกศรเปลี่ยนปี + ตาราง 12 เดือน
Future<String?> showMonthKeyPicker(
  BuildContext context, {
  required String initial,
  required bool buddhist,
  String? minKey,
}) {
  return showDialog<String>(
    context: context,
    builder: (ctx) => _MonthKeyPickerDialog(
      initial: initial,
      buddhist: buddhist,
      minKey: minKey,
    ),
  );
}

class _MonthKeyPickerDialog extends StatefulWidget {
  const _MonthKeyPickerDialog({
    required this.initial,
    required this.buddhist,
    this.minKey,
  });

  final String initial;
  final bool buddhist;
  final String? minKey;

  @override
  State<_MonthKeyPickerDialog> createState() => _MonthKeyPickerDialogState();
}

class _MonthKeyPickerDialogState extends State<_MonthKeyPickerDialog> {
  late int _year = AppDates.parseKey(widget.initial).year;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final p = context.palette;
    final selected = AppDates.parseKey(widget.initial);

    return Dialog(
      backgroundColor: p.surface,
      surfaceTintColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.r28),
      ),
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                IconButton(
                  tooltip: 'ปีก่อนหน้า',
                  constraints: const BoxConstraints(
                    minWidth: AppSpacing.minTap,
                    minHeight: AppSpacing.minTap,
                  ),
                  icon: const Icon(PhosphorIconsBold.caretLeft),
                  onPressed: () => setState(() => _year--),
                ),
                Expanded(
                  child: Text(
                    '${AppDates.displayYear(_year, buddhist: widget.buddhist)}',
                    textAlign: TextAlign.center,
                    style: theme.textTheme.titleMedium,
                  ),
                ),
                IconButton(
                  tooltip: 'ปีถัดไป',
                  constraints: const BoxConstraints(
                    minWidth: AppSpacing.minTap,
                    minHeight: AppSpacing.minTap,
                  ),
                  icon: const Icon(PhosphorIconsBold.caretRight),
                  onPressed: () => setState(() => _year++),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 3,
              mainAxisSpacing: AppSpacing.sm,
              crossAxisSpacing: AppSpacing.sm,
              childAspectRatio: 2.0,
              children: [
                for (var m = 1; m <= 12; m++)
                  _monthCell(context, m, selected.year == _year && selected.month == m),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _monthCell(BuildContext context, int month, bool isSelected) {
    final p = context.palette;
    final key = AppDates.monthKeyOf(_year, month);
    final disabled =
        widget.minKey != null && key.compareTo(widget.minKey!) < 0;
    return Opacity(
      opacity: disabled ? 0.35 : 1,
      child: PressableScale(
        onTap: disabled
            ? null
            : () {
                Haptics.selection();
                Navigator.of(context).pop(key);
              },
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            gradient: isSelected ? AppGradients.brand : null,
            color: isSelected ? null : p.inputFill,
            borderRadius: BorderRadius.circular(AppRadius.r16),
          ),
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              AppDates.thaiMonthsShort[month - 1],
              style: TextStyle(
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                color: isSelected ? AppColors.ink : p.ink,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// แปลงข้อความจำนวนเงินเป็นสตางค์ (ใช้หลัง validate แล้ว)
int parseAmountOrZero(String text) => Money.parse(text) ?? 0;

/// ช่องหมายเหตุหลายบรรทัด
class NoteField extends StatelessWidget {
  const NoteField({super.key, required this.controller});

  final TextEditingController controller;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      maxLines: 3,
      minLines: 2,
      maxLength: 200,
      textCapitalization: TextCapitalization.sentences,
      decoration: const InputDecoration(
        hintText: 'บันทึกเพิ่มเติม (ไม่บังคับ)',
        counterText: '',
      ),
    );
  }
}
