import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../core/theme/app_theme.dart';
import '../../widgets/widgets.dart';

/// ปุ่มย้อนกลับของหน้าที่เปิดซ้อน (พื้นที่กด 48dp)
class PastelBackButton extends StatelessWidget {
  const PastelBackButton({super.key});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: 'ย้อนกลับ',
      constraints: const BoxConstraints(
        minWidth: AppSpacing.minTap,
        minHeight: AppSpacing.minTap,
      ),
      icon: const Icon(PhosphorIconsBold.caretLeft),
      onPressed: () => Navigator.of(context).maybePop(),
    );
  }
}

/// ปุ่มไอคอนบน AppBar ขนาดกดสบาย
class AppBarIconButton extends StatelessWidget {
  const AppBarIconButton({
    super.key,
    required this.icon,
    required this.tooltip,
    required this.onPressed,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: tooltip,
      constraints: const BoxConstraints(
        minWidth: AppSpacing.minTap,
        minHeight: AppSpacing.minTap,
      ),
      icon: Icon(icon),
      onPressed: onPressed,
    );
  }
}

/// โครงหน้าที่เปิดซ้อน: Scaffold โปร่งใส (พื้นหลังมาจาก AppBackground) + sliver app bar
class SubPage extends StatelessWidget {
  const SubPage({
    super.key,
    required this.title,
    required this.slivers,
    this.actions = const [],
    this.bottomPadding = AppSpacing.huge,
  });

  final String title;
  final List<Widget> slivers;
  final List<Widget> actions;
  final double bottomPadding;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        slivers: [
          PastelSliverAppBar(
            title: title,
            leading: const PastelBackButton(),
            actions: actions,
          ),
          ...slivers,
          SliverToBoxAdapter(child: SizedBox(height: bottomPadding)),
        ],
      ),
    );
  }
}

/// หน้าชั่วคราวสำหรับเมนูที่ยังไม่พร้อม
class ComingSoonPage extends StatelessWidget {
  const ComingSoonPage({super.key, required this.title, required this.emoji});

  final String title;
  final String emoji;

  @override
  Widget build(BuildContext context) {
    return SubPage(
      title: title,
      slivers: [
        SliverFillRemaining(
          hasScrollBody: false,
          child: EmptyState(
            emoji: emoji,
            title: 'กำลังมาเร็วๆ นี้',
            message: 'ฟีเจอร์นี้อยู่ระหว่างเตรียมความพร้อม',
          ),
        ),
      ],
    );
  }
}
