import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_theme.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';

/// ล็อกแอปด้วย PIN/ลายนิ้วมือ: ล็อกตอนเปิดแอป และล็อกซ้ำเมื่อกลับมาหลังพักเกิน 20 วินาที
class LockGate extends ConsumerStatefulWidget {
  const LockGate({super.key, required this.child});

  final Widget child;

  @override
  ConsumerState<LockGate> createState() => _LockGateState();
}

class _LockGateState extends ConsumerState<LockGate>
    with WidgetsBindingObserver {
  static const Duration _relockAfter = Duration(seconds: 20);
  DateTime? _pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      final at = _pausedAt;
      _pausedAt = null;
      if (at != null &&
          DateTime.now().difference(at) > _relockAfter &&
          ref.read(settingsProvider).hasPin) {
        ref.read(appLockProvider.notifier).lock();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final hasPin = ref.watch(settingsProvider.select((s) => s.hasPin));
    final locked = ref.watch(appLockProvider) && hasPin;

    return Stack(
      fit: StackFit.expand,
      children: [
        widget.child,
        if (locked) const Positioned.fill(child: LockScreen()),
      ],
    );
  }
}

class LockScreen extends ConsumerStatefulWidget {
  const LockScreen({super.key});

  @override
  ConsumerState<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends ConsumerState<LockScreen> {
  bool _tryingBio = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (ref.read(settingsProvider).biometric) _biometric();
    });
  }

  Future<void> _biometric() async {
    if (_tryingBio) return;
    _tryingBio = true;
    final ok = await ref.read(pinServiceProvider).authenticateBiometric();
    _tryingBio = false;
    if (ok && mounted) ref.read(appLockProvider.notifier).unlock();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final p = context.palette;
    final bio = ref.watch(settingsProvider.select((s) => s.biometric));

    return Material(
      color: p.background,
      child: AppBackground(
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(AppSpacing.xxl),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const EmojiBadge(emoji: '🔒', size: 72),
                  const SizedBox(height: AppSpacing.lg),
                  Text('Money Cal Saving', style: theme.textTheme.titleLarge),
                  const SizedBox(height: 4),
                  Text('กรอก PIN เพื่อเข้าใช้งาน', style: theme.textTheme.bodyMedium),
                  const SizedBox(height: AppSpacing.xxl),
                  PinPad(
                    onBiometric: bio ? _biometric : null,
                    onCompleted: (pin) async {
                      final ok = await ref.read(pinServiceProvider).verify(pin);
                      if (ok) ref.read(appLockProvider.notifier).unlock();
                      return ok;
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
