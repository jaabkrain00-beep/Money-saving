import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_theme.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';

/// ตั้ง PIN ใหม่ (กรอก 2 ครั้งให้ตรงกัน) คืน true เมื่อบันทึกสำเร็จ
Future<bool> showPinSetup(BuildContext context) async {
  final ok = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    builder: (_) => const _PinSetupSheet(),
  );
  return ok ?? false;
}

/// ให้ผู้ใช้ยืนยัน PIN ปัจจุบัน (ก่อนเปลี่ยน/ลบ PIN) คืน true เมื่อถูกต้อง
Future<bool> showPinVerify(BuildContext context, {String title = 'ยืนยัน PIN ปัจจุบัน'}) async {
  final ok = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    builder: (_) => _PinVerifySheet(title: title),
  );
  return ok ?? false;
}

class _PinSetupSheet extends ConsumerStatefulWidget {
  const _PinSetupSheet();

  @override
  ConsumerState<_PinSetupSheet> createState() => _PinSetupSheetState();
}

class _PinSetupSheetState extends ConsumerState<_PinSetupSheet> {
  String? _first;
  String? _error;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.xxl, 0, AppSpacing.xxl, AppSpacing.xxl,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            _first == null ? 'ตั้ง PIN 4 หลัก' : 'กรอก PIN อีกครั้งเพื่อยืนยัน',
            style: theme.textTheme.titleLarge,
          ),
          const SizedBox(height: 6),
          SizedBox(
            height: 22,
            child: Text(
              _error ?? 'PIN เก็บไว้ในเครื่องนี้เท่านั้น',
              style: theme.textTheme.bodySmall?.copyWith(
                color: _error == null ? null : AppColors.dangerInk,
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.xl),
          PinPad(
            onCompleted: (pin) async {
              final navigator = Navigator.of(context);
              if (_first == null) {
                setState(() {
                  _first = pin;
                  _error = null;
                });
                return true;
              }
              if (_first == pin) {
                await ref.read(pinServiceProvider).setPin(pin);
                navigator.pop(true);
                return true;
              }
              setState(() {
                _first = null;
                _error = 'PIN ไม่ตรงกัน ลองใหม่อีกครั้ง';
              });
              return false;
            },
          ),
        ],
      ),
    );
  }
}

class _PinVerifySheet extends ConsumerWidget {
  const _PinVerifySheet({required this.title});

  final String title;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.xxl, 0, AppSpacing.xxl, AppSpacing.xxl,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(title, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: AppSpacing.xxl),
          PinPad(
            onCompleted: (pin) async {
              final navigator = Navigator.of(context);
              final ok = await ref.read(pinServiceProvider).verify(pin);
              if (ok) navigator.pop(true);
              return ok;
            },
          ),
        ],
      ),
    );
  }
}
