import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/haptics.dart';
import '../../core/utils/labels.dart';
import '../../core/utils/money.dart';
import '../../data/db/app_database.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';
import '../shared/entry_card.dart';
import '../shared/page_kit.dart';
import 'member_avatar.dart';
import 'member_detail_screen.dart';
import 'member_form_sheet.dart';

/// หน้าสมาชิกครอบครัว: รายชื่อ + สรุปรับ/จ่ายของเดือนที่เลือก
class MembersScreen extends ConsumerWidget {
  const MembersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(membersProvider);
    final members = async.valueOrNull ?? const <Member>[];

    return Scaffold(
      body: MonthSwipe(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics(),
          ),
          slivers: [
            PastelSliverAppBar(
              title: 'สมาชิกครอบครัว',
              leading: const PastelBackButton(),
              actions: [
                AppBarIconButton(
                  icon: PhosphorIconsBold.userPlus,
                  tooltip: 'เพิ่มสมาชิก',
                  onPressed: () => showMemberForm(context),
                ),
              ],
            ),
            const SliverToBoxAdapter(child: MonthSelector()),
            if (async.isLoading && members.isEmpty)
              const SliverFillRemaining(
                hasScrollBody: false,
                child: Center(child: CircularProgressIndicator()),
              )
            else if (members.isEmpty)
              SliverFillRemaining(
                hasScrollBody: false,
                child: EmptyState(
                  emoji: '👨‍👩‍👧',
                  title: 'ยังไม่มีสมาชิก',
                  message: 'เพิ่มสมาชิกเพื่อดูรายรับ รายจ่าย และเงินออมแยกรายคน',
                  actionLabel: 'เพิ่มสมาชิก',
                  onAction: () => showMemberForm(context),
                ),
              )
            else ...[
              SliverPadding(
                padding: const EdgeInsets.only(top: AppSpacing.sm),
                sliver: SliverList.builder(
                  itemCount: members.length,
                  itemBuilder: (context, i) => _MemberCard(
                    key: ValueKey('member-${members[i].id}'),
                    member: members[i],
                    index: i,
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(AppSpacing.screenH),
                  child: GradientButton(
                    label: 'เพิ่มสมาชิก',
                    icon: PhosphorIconsBold.userPlus,
                    expand: true,
                    onPressed: () => showMemberForm(context),
                  ),
                ),
              ),
            ],
            const SliverToBoxAdapter(child: SizedBox(height: AppSpacing.huge)),
          ],
        ),
      ),
    );
  }
}

class _MemberCard extends ConsumerWidget {
  const _MemberCard({super.key, required this.member, required this.index});

  final Member member;
  final int index;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(monthSummaryProvider(member.id));

    return EntryCard(
      slidableKey: ValueKey('slide-member-${member.id}'),
      index: index,
      emoji: member.avatar,
      color: Color(member.color),
      leading: MemberAvatar(member: member),
      title: memberLabel(member),
      subtitle: member.nickname.trim().isNotEmpty
          ? member.name
          : 'คงเหลือเดือนนี้',
      amountSatang: s.balancePlanned,
      amountColor: s.balancePlanned < 0 ? AppColors.dangerInk : null,
      chips: [
        InfoChip(
          text: 'รับ ${Money.formatCompact(s.incomeTotal)}',
          emoji: '💰',
          color: AppColors.incomeA,
        ),
        InfoChip(
          text: 'จ่าย ${Money.formatCompact(s.expenseTotal)}',
          emoji: '🧾',
          color: AppColors.expenseA,
        ),
        if (s.savings != 0)
          InfoChip(
            text: 'ออม ${Money.formatCompact(s.savings)}',
            emoji: '🐷',
            color: AppColors.savingA,
          ),
      ],
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (_) => MemberDetailScreen(memberId: member.id),
        ),
      ),
      swipeActions: [
        CardSwipeAction(
          label: 'แก้ไข',
          icon: PhosphorIconsBold.pencilSimple,
          gradient: AppGradients.brand,
          onTap: () => showMemberForm(context, editing: member),
        ),
        CardSwipeAction(
          label: 'ลบ',
          icon: PhosphorIconsBold.trash,
          gradient: AppGradients.expense,
          onTap: () => deleteMemberWithUndo(context, ref, member),
        ),
      ],
    );
  }
}

/// ลบสมาชิก: ถ้ามีรายการผูกอยู่ ให้เลือก "ย้ายไปส่วนกลาง" หรือ "ลบรายการทั้งหมด"
Future<void> deleteMemberWithUndo(
  BuildContext context,
  WidgetRef ref,
  Member member,
) async {
  final repo = ref.read(membersRepositoryProvider);
  final messenger = ScaffoldMessenger.of(context);
  final count = await repo.countRecords(member.id);
  if (!context.mounted) return;

  bool deleteRecords = false;
  if (count == 0) {
    final ok = await showConfirmDialog(
      context,
      title: 'ลบสมาชิก "${memberLabel(member)}" ?',
      confirmLabel: 'ลบ',
      destructive: true,
    );
    if (!ok) return;
  } else {
    final choice = await showDialog<bool>(
      context: context,
      builder: (ctx) => _DeleteMemberDialog(name: memberLabel(member), count: count),
    );
    if (choice == null) return;
    deleteRecords = choice;
  }

  final snapshot =
      await repo.deleteMember(member.id, deleteRecords: deleteRecords);
  Haptics.medium();
  showUndoSnackBarOn(
    messenger,
    message: deleteRecords
        ? 'ลบสมาชิกและรายการของ "${memberLabel(member)}" แล้ว'
        : 'ลบสมาชิก "${memberLabel(member)}" แล้ว (รายการย้ายไปส่วนกลาง)',
    onUndo: () => repo.restoreMember(snapshot),
  );
}

class _DeleteMemberDialog extends StatelessWidget {
  const _DeleteMemberDialog({required this.name, required this.count});

  final String name;
  final int count;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final p = context.palette;
    return Dialog(
      backgroundColor: p.surface,
      surfaceTintColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.r28),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(AppSpacing.xxl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Center(child: Text('🗑️', style: TextStyle(fontSize: 40))),
            const SizedBox(height: AppSpacing.sm),
            Text(
              'ลบ "$name" ?',
              textAlign: TextAlign.center,
              style: theme.textTheme.titleMedium,
            ),
            const SizedBox(height: AppSpacing.sm),
            Text(
              'สมาชิกคนนี้มี $count รายการผูกอยู่ ต้องการจัดการรายการเหล่านั้นอย่างไร?',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium?.copyWith(color: p.inkSoft),
            ),
            const SizedBox(height: AppSpacing.xl),
            GradientButton(
              label: 'ย้ายรายการไป "ส่วนกลาง"',
              expand: true,
              onPressed: () => Navigator.of(context).pop(false),
            ),
            const SizedBox(height: AppSpacing.sm),
            GradientButton(
              label: 'ลบรายการทั้งหมดด้วย',
              expand: true,
              gradient: AppGradients.expense,
              onPressed: () => Navigator.of(context).pop(true),
            ),
            const SizedBox(height: AppSpacing.xs),
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('ยกเลิก'),
            ),
          ],
        ),
      ),
    );
  }
}
