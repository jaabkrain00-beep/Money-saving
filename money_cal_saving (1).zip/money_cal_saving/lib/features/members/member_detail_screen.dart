import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/app_dates.dart';
import '../../core/utils/labels.dart';
import '../../data/db/app_database.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';
import '../shared/entry_card.dart';
import '../shared/page_kit.dart';
import 'member_avatar.dart';
import 'member_form_sheet.dart';

/// สรุปรายคนของเดือนที่เลือก: รับ/จ่าย/ออม/คงเหลือ + รายการของสมาชิกคนนี้
class MemberDetailScreen extends ConsumerWidget {
  const MemberDetailScreen({super.key, required this.memberId});

  final int memberId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final member = ref.watch(memberMapProvider)[memberId];
    if (member == null) {
      // สมาชิกถูกลบ (เช่นกด Undo ไม่ทัน) → กลับหน้าก่อนหน้า
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final theme = Theme.of(context);
    final s = ref.watch(monthSummaryProvider(memberId));
    final buddhist = ref.watch(useBuddhistYearProvider);
    final categoryMap = ref.watch(categoryMapProvider);
    final income = [
      for (final e in ref.watch(monthIncomeProvider))
        if (e.memberId == memberId) e,
    ];
    final expenses = [
      for (final e in ref.watch(monthExpenseProvider))
        if (e.memberId == memberId) e,
    ];

    Widget stat(String label, int satang, LinearGradient g) => Expanded(
          child: GradientCard(
            gradient: g,
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.bodySmall),
                const SizedBox(height: 2),
                AmountText(
                  satang,
                  animate: true,
                  style: theme.textTheme.titleMedium,
                ),
              ],
            ),
          ),
        );

    return Scaffold(
      body: MonthSwipe(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics(),
          ),
          slivers: [
            PastelSliverAppBar(
              title: memberLabel(member),
              leading: const PastelBackButton(),
              actions: [
                AppBarIconButton(
                  icon: PhosphorIconsBold.pencilSimple,
                  tooltip: 'แก้ไขสมาชิก',
                  onPressed: () => showMemberForm(context, editing: member),
                ),
              ],
            ),
            const SliverToBoxAdapter(child: MonthSelector()),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSpacing.screenH,
                  vertical: AppSpacing.sm,
                ),
                child: Row(
                  children: [
                    MemberAvatar(member: member, size: 64),
                    const SizedBox(width: AppSpacing.lg),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            member.name,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.titleMedium,
                          ),
                          Text('คงเหลือเดือนนี้ (ตามแผน)',
                              style: theme.textTheme.bodySmall),
                          AmountText(
                            s.balancePlanned,
                            animate: true,
                            redWhenNegative: true,
                            style: theme.textTheme.headlineSmall,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSpacing.screenH,
                  vertical: AppSpacing.sm,
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        stat('รายรับ', s.incomeTotal, AppGradients.income),
                        const SizedBox(width: AppSpacing.md),
                        stat('รายจ่าย', s.expenseTotal, AppGradients.expense),
                      ],
                    ),
                    const SizedBox(height: AppSpacing.md),
                    Row(
                      children: [
                        stat('เงินออม', s.savings, AppGradients.saving),
                        const SizedBox(width: AppSpacing.md),
                        stat('ค้างจ่าย', s.expenseUnpaid, AppGradients.brand),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SliverToBoxAdapter(child: SectionHeader(title: 'รายรับเดือนนี้')),
            if (income.isEmpty)
              const SliverToBoxAdapter(child: _EmptyLine('ยังไม่มีรายรับ'))
            else
              SliverList.builder(
                itemCount: income.length,
                itemBuilder: (context, i) {
                  final e = income[i];
                  final c = categoryMap[e.categoryId];
                  return EntryCard(
                    slidableKey: ValueKey('md-income-${e.id}'),
                    index: i,
                    emoji: c?.icon ?? '💰',
                    color: Color(c?.color ?? AppColors.incomeA.toARGB32()),
                    title: e.name,
                    subtitle: AppDates.formatDayMonth(e.date, buddhist: buddhist),
                    amountSatang: e.amountSatang,
                    amountColor: AppColors.successInk,
                    chips: [
                      e.isReceived
                          ? const StatusChip.received()
                          : const StatusChip.waiting(),
                    ],
                  );
                },
              ),
            const SliverToBoxAdapter(child: SectionHeader(title: 'รายจ่ายเดือนนี้')),
            if (expenses.isEmpty)
              const SliverToBoxAdapter(child: _EmptyLine('ยังไม่มีรายจ่าย'))
            else
              SliverList.builder(
                itemCount: expenses.length,
                itemBuilder: (context, i) {
                  final e = expenses[i];
                  final c = categoryMap[e.categoryId];
                  return EntryCard(
                    slidableKey: ValueKey('md-expense-${e.id}'),
                    index: i,
                    emoji: c?.icon ?? '🧾',
                    color: Color(c?.color ?? AppColors.expenseA.toARGB32()),
                    title: e.name,
                    subtitle: 'ครบกำหนด ${AppDates.formatDayMonth(e.dueDate, buddhist: buddhist)}',
                    amountSatang: e.amountSatang,
                    amountColor:
                        e.isPaid ? AppColors.successInk : AppColors.dangerInk,
                    chips: [
                      e.isPaid
                          ? const StatusChip.paid()
                          : const StatusChip.unpaid(),
                    ],
                  );
                },
              ),
            const SliverToBoxAdapter(child: SizedBox(height: AppSpacing.huge)),
          ],
        ),
      ),
    );
  }
}

class _EmptyLine extends StatelessWidget {
  const _EmptyLine(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.screenH,
        vertical: AppSpacing.sm,
      ),
      child: Text(
        text,
        style: Theme.of(context)
            .textTheme
            .bodyMedium
            ?.copyWith(color: context.palette.inkSoft),
      ),
    );
  }
}
