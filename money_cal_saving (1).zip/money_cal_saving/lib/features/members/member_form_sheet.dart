import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/haptics.dart';
import '../../data/db/app_database.dart';
import '../../data/repositories/members_repository.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';
import '../shared/form_kit.dart';
import 'member_avatar.dart';

const List<String> _avatarEmojis = [
  '👨', '👩', '👴', '👵', '👦', '👧', '🧑', '👶',
  '🐶', '🐱', '🐰', '🐻', '🦊', '🐼', '🐥', '🦄',
  '🌸', '⭐', '🍀', '🍓',
];

/// ฟอร์มเพิ่ม/แก้ไขสมาชิก (ชื่อ ชื่อเล่น สี รูป/อีโมจิ)
Future<void> showMemberForm(BuildContext context, {Member? editing}) {
  return showFormSheet<void>(
    context,
    builder: (_) => MemberFormSheet(editing: editing),
  );
}

class MemberFormSheet extends ConsumerStatefulWidget {
  const MemberFormSheet({super.key, this.editing});

  final Member? editing;

  @override
  ConsumerState<MemberFormSheet> createState() => _MemberFormSheetState();
}

class _MemberFormSheetState extends ConsumerState<MemberFormSheet> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _nickname;
  late int _color;
  late String _avatar;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final m = widget.editing;
    _name = TextEditingController(text: m?.name ?? '');
    _nickname = TextEditingController(text: m?.nickname ?? '');
    _color = m?.color ?? AppColors.pickerColors[5].toARGB32();
    _avatar = m?.avatar ?? '🙂';
  }

  @override
  void dispose() {
    _name.dispose();
    _nickname.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 85,
      );
      if (picked == null) return;
      final dir = await getApplicationDocumentsDirectory();
      final avatarDir = Directory(p.join(dir.path, 'avatars'));
      if (!avatarDir.existsSync()) avatarDir.createSync(recursive: true);
      final ext = p.extension(picked.path).isEmpty ? '.jpg' : p.extension(picked.path);
      final dest = p.join(
        avatarDir.path,
        'member_${DateTime.now().millisecondsSinceEpoch}$ext',
      );
      await File(picked.path).copy(dest);
      if (mounted) setState(() => _avatar = 'file:$dest');
    } catch (_) {
      if (mounted) {
        showAppSnackBar(context, 'เลือกรูปไม่สำเร็จ', emoji: '😢');
      }
    }
  }

  Future<void> _save() async {
    if (!(_formKey.currentState?.validate() ?? false)) {
      Haptics.medium();
      return;
    }
    final repo = ref.read(membersRepositoryProvider);
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);
    final name = _name.text.trim();
    final nickname = _nickname.text.trim();

    setState(() => _saving = true);
    try {
      final m = widget.editing;
      if (m == null) {
        await repo.addMember(
          MemberInput(
            name: name,
            nickname: nickname,
            color: _color,
            avatar: _avatar,
          ),
        );
      } else {
        await repo.updateMember(
          m.copyWith(
            name: name,
            nickname: nickname,
            color: _color,
            avatar: _avatar,
          ),
        );
      }
      Haptics.light();
      navigator.pop();
      showAppSnackBarOn(messenger, 'บันทึกสมาชิกแล้ว', emoji: '👨‍👩‍👧');
    } catch (_) {
      if (mounted) setState(() => _saving = false);
      showAppSnackBarOn(messenger, 'บันทึกไม่สำเร็จ ลองใหม่อีกครั้ง', emoji: '😢');
    }
  }

  @override
  Widget build(BuildContext context) {
    final pal = context.palette;
    final preview = Member(
      id: widget.editing?.id ?? 0,
      name: _name.text,
      nickname: _nickname.text,
      color: _color,
      avatar: _avatar,
      createdAt: widget.editing?.createdAt ?? DateTime.now(),
    );

    return Form(
      key: _formKey,
      child: FormSheetScaffold(
        emoji: '👨‍👩‍👧',
        title: widget.editing == null ? 'เพิ่มสมาชิก' : 'แก้ไขสมาชิก',
        saving: _saving,
        onSave: _save,
        children: [
          Center(child: MemberAvatar(member: preview, size: 84)),
          const FieldLabel('ชื่อ'),
          TextFormField(
            controller: _name,
            maxLength: 40,
            textInputAction: TextInputAction.next,
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(
              hintText: 'เช่น สมชาย ใจดี',
              counterText: '',
            ),
            validator: (v) =>
                (v == null || v.trim().isEmpty) ? 'กรุณากรอกชื่อ' : null,
          ),
          const FieldLabel('ชื่อเล่น (ไม่บังคับ)'),
          TextFormField(
            controller: _nickname,
            maxLength: 20,
            textInputAction: TextInputAction.done,
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(
              hintText: 'เช่น พ่อ, แม่, น้องมิ้น',
              counterText: '',
            ),
          ),
          const FieldLabel('สีประจำตัว'),
          Wrap(
            spacing: AppSpacing.md,
            runSpacing: AppSpacing.md,
            children: [
              for (final c in AppColors.pickerColors)
                Semantics(
                  button: true,
                  label: 'เลือกสี',
                  selected: _color == c.toARGB32(),
                  child: GestureDetector(
                    onTap: () {
                      Haptics.selection();
                      setState(() => _color = c.toARGB32());
                    },
                    child: SizedBox(
                      width: AppSpacing.minTap,
                      height: AppSpacing.minTap,
                      child: Center(
                        child: AnimatedContainer(
                          duration: AppDurations.fast,
                          width: _color == c.toARGB32() ? 40 : 34,
                          height: _color == c.toARGB32() ? 40 : 34,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: AppGradients.fromColor(c),
                            border: Border.all(
                              color: _color == c.toARGB32()
                                  ? pal.ink
                                  : Colors.white.withValues(alpha: 0.8),
                              width: _color == c.toARGB32() ? 2.5 : 1.5,
                            ),
                          ),
                          child: _color == c.toARGB32()
                              ? const Icon(PhosphorIconsBold.check,
                                  size: 18, color: AppColors.ink)
                              : null,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const FieldLabel('รูปประจำตัว'),
          Wrap(
            spacing: AppSpacing.sm,
            runSpacing: AppSpacing.sm,
            children: [
              for (final e in _avatarEmojis)
                Semantics(
                  button: true,
                  label: 'เลือกอีโมจิ $e',
                  child: GestureDetector(
                    onTap: () {
                      Haptics.selection();
                      setState(() => _avatar = e);
                    },
                    child: AnimatedContainer(
                      duration: AppDurations.fast,
                      width: AppSpacing.minTap,
                      height: AppSpacing.minTap,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: _avatar == e
                            ? Color(_color).withValues(alpha: 0.45)
                            : pal.inputFill,
                        borderRadius: BorderRadius.circular(AppRadius.r16),
                        border: Border.all(
                          color: _avatar == e ? Color(_color) : Colors.transparent,
                          width: 2,
                        ),
                      ),
                      child: Text(e, style: const TextStyle(fontSize: 24)),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: AppSpacing.md),
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton.icon(
              onPressed: _pickImage,
              icon: const Icon(PhosphorIconsRegular.image),
              label: const Text('เลือกรูปจากเครื่อง'),
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
        ],
      ),
    );
  }
}
