import 'dart:io';

import 'package:flutter/material.dart';

import '../../data/db/app_database.dart';
import '../../widgets/widgets.dart';

/// รูปประจำตัวสมาชิก: อีโมจิ หรือรูปจากเครื่อง ("file:<path>")
class MemberAvatar extends StatelessWidget {
  const MemberAvatar({super.key, required this.member, this.size = 46});

  final Member? member;
  final double size;

  @override
  Widget build(BuildContext context) {
    final m = member;
    if (m == null) {
      return EmojiBadge(emoji: '🏠', size: size);
    }
    final color = Color(m.color);
    if (m.avatar.startsWith('file:')) {
      final path = m.avatar.substring(5);
      final file = File(path);
      if (file.existsSync()) {
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: color, width: 3),
          ),
          child: ClipOval(
            child: Image.file(
              file,
              fit: BoxFit.cover,
              cacheWidth: (size * 3).round(),
              errorBuilder: (_, __, ___) =>
                  EmojiBadge(emoji: '🙂', color: color, size: size),
            ),
          ),
        );
      }
      return EmojiBadge(emoji: '🙂', color: color, size: size);
    }
    return EmojiBadge(emoji: m.avatar, color: color, size: size);
  }
}
