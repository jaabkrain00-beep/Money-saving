import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/app_dates.dart';
import '../../core/utils/haptics.dart';
import '../../data/db/app_database.dart';
import '../../domain/status_rules.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';
import '../shared/entry_card.dart';
import '../shared/page_kit.dart';

/// ปฏิทินการเงิน: จุดสีบอกวันที่มีรายรับ/รายจ่าย/ออม แตะวันเพื่อดูรายการของวันนั้น
class CalendarScreen extends ConsumerStatefulWidget {
  const CalendarScreen({super.key});

  @override
  ConsumerState<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends ConsumerState<CalendarScreen> {
  int? _selectedDay;

  @override
  Widget build(BuildContext context) {
    ref.watch(monthReadyProvider);
    final theme = Theme.of(context);
    final month = ref.watch(selectedMonthProvider);
    final buddhist = ref.watch(useBuddhistYearProvider);
    final income = ref.watch(monthIncomeProvider);
    final expenses = ref.watch(monthExpenseProvider);
    final savings = ref.watch(monthSavingTxProvider);
    final categoryMap = ref.watch(categoryMapProvider);
    final goalMap = {
      for (final g in ref.watch(goalsProvider).valueOrNull ?? const <SavingGoal>[])
        g.id: g,
    };

    final k = AppDates.parseKey(month);
    final days = AppDates.daysInMonth(k.year, k.month);
    final today = AppDates.dateOnly(DateTime.now());
    final isCurrent = AppDates.monthKey(today) == month;
    final selected = (_selectedDay != null && _selectedDay! <= days)
        ? _selectedDay!
        : (isCurrent ? today.day : 1);
    final offset = DateTime(k.year, k.month, 1).weekday - 1; // จันทร์ = 0 (ตรงกับ thaiWeekdaysShort)

    Set<int> daysOf<T>(List<T> xs, DateTime Function(T) f) =>
        {for (final x in xs) f(x).day};
    final incomeDays = daysOf(income, (e) => e.date);
    final unpaidDays = daysOf([for (final e in expenses) if (!e.isPaid) e], (e) => e.dueDate);
    final paidDays = daysOf([for (final e in expenses) if (e.isPaid) e], (e) => e.dueDate);
    final savingDays = daysOf(savings, (e) => e.date);

    final dayIncome = [for (final e in income) if (e.date.day == selected) e];
    final dayExpense = [for (final e in expenses) if (e.dueDate.day == selected) e];
    final daySaving = [for (final e in savings) if (e.date.day == selected) e];
    final isEmptyDay = dayIncome.isEmpty && dayExpense.isEmpty && daySaving.isEmpty;

    final cells = <Widget>[
      for (final w in AppDates.thaiWeekdaysShort)
        Center(
          child: Text(w, style: theme.textTheme.bodySmall),
        ),
      for (var i = 0; i < offset; i++) const SizedBox.shrink(),
      for (var d = 1; d <= days; d++)
        _DayCell(
          day: d,
          selected: d == selected,
          isToday: isCurrent && d == today.day,
          hasIncome: incomeDays.contains(d),
          hasUnpaid: unpaidDays.contains(d),
          hasPaid: paidDays.contains(d),
          hasSaving: savingDays.contains(d),
          onTap: () {
            Haptics.selection();
            setState(() => _selectedDay = d);
          },
        ),
    ];

    final selectedDate = DateTime(k.year, k.month, selected);

    return Scaffold(
      body: MonthSwipe(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics(),
          ),
          slivers: [
            const PastelSliverAppBar(
              title: 'ปฏิทินการเงิน',
              leading: PastelBackButton(),
            ),
            const SliverToBoxAdapter(child: MonthSelector()),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSpacing.screenH,
                  vertical: AppSpacing.sm,
                ),
                child: GlassCard(
                  radius: AppRadius.r24,
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    children: [
                      GridView.count(
                        crossAxisCount: 7,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        childAspectRatio: 0.86,
                        children: cells,
                      ),
                      const SizedBox(height: 6),
                      const Wrap(
                        spacing: 12,
                        runSpacing: 4,
                        alignment: WrapAlignment.center,
                        children: [
                          _Key(color: AppColors.successInk, label: 'รายรับ'),
                          _Key(color: AppColors.dangerInk, label: 'ค้างจ่าย'),
                          _Key(color: AppColors.brandStrong, label: 'จ่ายแล้ว'),
                          _Key(color: Color(0xFF9B7FD6), label: 'ออม'),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: SectionHeader(
                title: AppDates.formatFullDate(selectedDate, buddhist: buddhist),
              ),
            ),
            if (isEmptyDay)
              const SliverToBoxAdapter(
                child: SizedBox(
                  height: 200,
                  child: EmptyState(
                    emoji: '🍃',
                    title: 'ไม่มีรายการในวันนี้',
                  ),
                ),
              )
            else ...[
              SliverList.builder(
                itemCount: dayIncome.length,
                itemBuilder: (context, i) {
                  final e = dayIncome[i];
                  final c = categoryMap[e.categoryId];
                  return EntryCard(
                    slidableKey: ValueKey('cal-in-${e.id}'),
                    index: i,
                    emoji: c?.icon ?? '💰',
                    color: Color(c?.color ?? AppColors.incomeA.toARGB32()),
                    title: e.name,
                    subtitle: 'รายรับ',
                    amountSatang: e.amountSatang,
                    amountColor: AppColors.successInk,
                    chips: [
                      e.isReceived
                          ? const StatusChip.received()
                          : const StatusChip.waiting(),
                    ],
                  );
                },
              ),
              SliverList.builder(
                itemCount: dayExpense.length,
                itemBuilder: (context, i) {
                  final e = dayExpense[i];
                  final c = categoryMap[e.categoryId];
                  final st = ExpenseRules.status(
                    isPaid: e.isPaid,
                    dueDate: e.dueDate,
                    today: today,
                  );
                  return EntryCard(
                    slidableKey: ValueKey('cal-ex-${e.id}'),
                    index: i,
                    emoji: c?.icon ?? '🧾',
                    color: Color(c?.color ?? AppColors.expenseA.toARGB32()),
                    title: e.name,
                    subtitle: 'ครบกำหนดจ่าย',
                    amountSatang: e.amountSatang,
                    amountColor:
                        e.isPaid ? AppColors.successInk : AppColors.dangerInk,
                    chips: [
                      switch (st) {
                        ExpenseStatus.paid => const StatusChip.paid(),
                        ExpenseStatus.overdue => const StatusChip.overdue(),
                        ExpenseStatus.dueSoon => const StatusChip.dueSoon(),
                        ExpenseStatus.unpaid => const StatusChip.unpaid(),
                      },
                    ],
                  );
                },
              ),
              SliverList.builder(
                itemCount: daySaving.length,
                itemBuilder: (context, i) {
                  final t = daySaving[i];
                  final g = goalMap[t.goalId];
                  final dep = t.type == SavingTxType.deposit;
                  return EntryCard(
                    slidableKey: ValueKey('cal-sv-${t.id}'),
                    index: i,
                    emoji: g?.emoji ?? '🐷',
                    color: Color(g?.color ?? AppColors.savingA.toARGB32()),
                    title: '${dep ? 'ฝาก' : 'ถอน'} ${g?.name ?? 'เงินออม'}',
                    subtitle: 'เงินออม',
                    amountSatang: dep ? t.amountSatang : -t.amountSatang,
                    amountColor:
                        dep ? AppColors.successInk : AppColors.dangerInk,
                  );
                },
              ),
            ],
            const SliverToBoxAdapter(child: SizedBox(height: AppSpacing.huge)),
          ],
        ),
      ),
    );
  }
}

class _Key extends StatelessWidget {
  const _Key({required this.color, required this.label});

  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 9,
          height: 9,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 4),
        Text(label, style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }
}

class _DayCell extends StatelessWidget {
  const _DayCell({
    required this.day,
    required this.selected,
    required this.isToday,
    required this.hasIncome,
    required this.hasUnpaid,
    required this.hasPaid,
    required this.hasSaving,
    required this.onTap,
  });

  final int day;
  final bool selected;
  final bool isToday;
  final bool hasIncome;
  final bool hasUnpaid;
  final bool hasPaid;
  final bool hasSaving;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;

    Widget dot(Color c) => Container(
          width: 6,
          height: 6,
          margin: const EdgeInsets.symmetric(horizontal: 1),
          decoration: BoxDecoration(color: c, shape: BoxShape.circle),
        );

    return Semantics(
      button: true,
      selected: selected,
      label: 'วันที่ $day',
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(2),
          child: AnimatedContainer(
            duration: AppDurations.fast,
            decoration: BoxDecoration(
              gradient: selected ? AppGradients.brand : null,
              borderRadius: BorderRadius.circular(AppRadius.r16),
              border: isToday && !selected
                  ? Border.all(color: AppColors.brandStrong, width: 1.5)
                  : null,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    '$day',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight:
                          selected || isToday ? FontWeight.w700 : FontWeight.w500,
                      color: selected ? AppColors.ink : p.ink,
                    ),
                  ),
                ),
                const SizedBox(height: 3),
                SizedBox(
                  height: 6,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (hasIncome) dot(AppColors.successInk),
                      if (hasUnpaid) dot(AppColors.dangerInk),
                      if (hasPaid) dot(AppColors.brandStrong),
                      if (hasSaving) dot(const Color(0xFF9B7FD6)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
