import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/app_dates.dart';
import '../../core/utils/haptics.dart';
import '../../core/utils/labels.dart';
import '../../core/utils/money.dart';
import '../../data/db/app_database.dart';
import '../../domain/status_rules.dart';
import '../../domain/template_rules.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';
import '../more/more_menu.dart';
import '../shared/detail_sheet.dart';
import '../shared/entry_card.dart';
import 'expense_form_sheet.dart';

enum _Tab { all, unpaid, paid }

/// หน้ารายจ่าย: สรุป + แท็บ (ทั้งหมด/ยังไม่จ่าย/จ่ายแล้ว) + รายการ
class ExpenseScreen extends ConsumerStatefulWidget {
  const ExpenseScreen({super.key});

  @override
  ConsumerState<ExpenseScreen> createState() => _ExpenseScreenState();
}

class _ExpenseScreenState extends ConsumerState<ExpenseScreen> {
  _Tab _tab = _Tab.all;
  int? _memberFilter;

  @override
  Widget build(BuildContext context) {
    final ready = ref.watch(monthReadyProvider);
    final all = ref.watch(monthExpenseProvider);
    final members = ref.watch(membersProvider).valueOrNull ?? const <Member>[];
    final memberMap = ref.watch(memberMapProvider);
    final categoryMap = ref.watch(categoryMapProvider);
    final templateMap = ref.watch(expenseTemplateMapProvider);
    final buddhist = ref.watch(useBuddhistYearProvider);
    final today = AppDates.dateOnly(DateTime.now());

    final filterId =
        (_memberFilter != null && memberMap.containsKey(_memberFilter))
            ? _memberFilter
            : null;
    final byMember = filterId == null
        ? all
        : [for (final e in all) if (e.memberId == filterId) e];

    final total = byMember.fold<int>(0, (s, e) => s + e.amountSatang);
    final paid = byMember
        .where((e) => e.isPaid)
        .fold<int>(0, (s, e) => s + e.amountSatang);
    final unpaidCount = byMember.where((e) => !e.isPaid).length;

    final list = switch (_tab) {
      _Tab.all => byMember,
      _Tab.unpaid => [for (final e in byMember) if (!e.isPaid) e],
      _Tab.paid => [for (final e in byMember) if (e.isPaid) e],
    };

    return MonthSwipe(
      child: CustomScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        slivers: [
          PastelSliverAppBar(
            title: 'รายจ่าย',
            actions: [
              IconButton(
                tooltip: 'เพิ่มรายจ่าย',
                constraints: const BoxConstraints(
                  minWidth: AppSpacing.minTap,
                  minHeight: AppSpacing.minTap,
                ),
                icon: const Icon(PhosphorIconsBold.plusCircle),
                onPressed: () => showExpenseForm(context),
              ),
              const MoreMenuButton(),
            ],
          ),
          const SliverToBoxAdapter(child: MonthSelector()),
          SliverToBoxAdapter(
            child: _SummaryCard(
              total: total,
              paid: paid,
              unpaidCount: unpaidCount,
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.screenH,
                vertical: AppSpacing.sm,
              ),
              child: _TabSwitch(
                tab: _tab,
                unpaidCount: unpaidCount,
                onChanged: (t) => setState(() => _tab = t),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: MemberFilterBar(
              members: members,
              selectedId: filterId,
              onChanged: (id) => setState(() => _memberFilter = id),
            ),
          ),
          if (!ready)
            const SliverFillRemaining(
              hasScrollBody: false,
              child: Center(child: CircularProgressIndicator()),
            )
          else if (list.isEmpty)
            SliverFillRemaining(
              hasScrollBody: false,
              child: Padding(
                padding:
                    const EdgeInsets.only(bottom: AppSpacing.navBarClearance),
                child: _emptyFor(context),
              ),
            )
          else ...[
            SliverPadding(
              padding: const EdgeInsets.only(top: AppSpacing.sm),
              sliver: SliverList.builder(
                itemCount: list.length,
                itemBuilder: (context, i) {
                  final e = list[i];
                  return _ExpenseCard(
                    key: ValueKey('expense-${e.id}'),
                    entry: e,
                    index: i,
                    member: memberMap[e.memberId],
                    category: categoryMap[e.categoryId],
                    template: e.templateId == null
                        ? null
                        : templateMap[e.templateId!],
                    today: today,
                    buddhist: buddhist,
                  );
                },
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(height: AppSpacing.navBarClearance),
            ),
          ],
        ],
      ),
    );
  }

  Widget _emptyFor(BuildContext context) {
    switch (_tab) {
      case _Tab.unpaid:
        return const EmptyState(
          emoji: '🎉',
          title: 'ไม่มีรายการค้างจ่าย',
          message: 'เก่งมาก! เดือนนี้จ่ายครบทุกรายการแล้ว',
          gradient: AppGradients.income,
        );
      case _Tab.paid:
        return const EmptyState(
          emoji: '🧺',
          title: 'ยังไม่มีรายการที่จ่ายแล้ว',
          message: 'เมื่อกด "จ่ายเลย" รายการจะมาอยู่ที่นี่',
          gradient: AppGradients.saving,
        );
      case _Tab.all:
        return EmptyState(
          emoji: '🧾',
          title: 'ยังไม่มีรายจ่ายเดือนนี้',
          message: 'เพิ่มค่าใช้จ่ายประจำหรือรายจ่ายจร เพื่อดูว่าเงินไปไหนบ้าง',
          actionLabel: 'เพิ่มรายจ่าย',
          gradient: AppGradients.expense,
          onAction: () => showExpenseForm(context),
        );
    }
  }
}

class _TabSwitch extends StatelessWidget {
  const _TabSwitch({
    required this.tab,
    required this.unpaidCount,
    required this.onChanged,
  });

  final _Tab tab;
  final int unpaidCount;
  final ValueChanged<_Tab> onChanged;

  @override
  Widget build(BuildContext context) {
    return SegmentSwitch(
      labels: [
        'ทั้งหมด',
        unpaidCount > 0 ? 'ยังไม่จ่าย ($unpaidCount)' : 'ยังไม่จ่าย',
        'จ่ายแล้ว',
      ],
      index: tab.index,
      gradient: AppGradients.expense,
      onChanged: (i) => onChanged(_Tab.values[i]),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.total,
    required this.paid,
    required this.unpaidCount,
  });

  final int total;
  final int paid;
  final int unpaidCount;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final remaining = total - paid;
    final ratio = total <= 0 ? 0.0 : (paid / total).clamp(0.0, 1.0);

    Widget stat(String label, int satang) => Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: theme.textTheme.bodySmall,
              ),
              AmountText(
                satang,
                animate: true,
                style: theme.textTheme.titleMedium,
              ),
            ],
          ),
        );

    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.screenH,
        vertical: AppSpacing.sm,
      ),
      child: GradientCard(
        gradient: AppGradients.expense,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'รายจ่ายรวมเดือนนี้',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodyMedium,
            ),
            const SizedBox(height: 4),
            AmountText(
              total,
              animate: true,
              style: theme.textTheme.headlineMedium,
            ),
            const SizedBox(height: AppSpacing.md),
            TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: ratio),
              duration: AppDurations.chart,
              curve: Curves.easeOutCubic,
              builder: (context, v, _) => ClipRRect(
                borderRadius: BorderRadius.circular(AppRadius.pill),
                child: LinearProgressIndicator(
                  value: v,
                  minHeight: 10,
                  backgroundColor: Colors.white.withValues(alpha: 0.5),
                  valueColor: const AlwaysStoppedAnimation(AppColors.successInk),
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.md),
            Row(
              children: [
                stat('จ่ายแล้ว', paid),
                const SizedBox(width: AppSpacing.md),
                stat(unpaidCount > 0 ? 'ค้างจ่าย ($unpaidCount)' : 'ค้างจ่าย', remaining),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ExpenseCard extends ConsumerWidget {
  const _ExpenseCard({
    super.key,
    required this.entry,
    required this.index,
    required this.member,
    required this.category,
    required this.template,
    required this.today,
    required this.buddhist,
  });

  final ExpenseEntry entry;
  final int index;
  final Member? member;
  final Category? category;
  final ExpenseTemplate? template;
  final DateTime today;
  final bool buddhist;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final e = entry;
    final tpl = template;
    final status = ExpenseRules.status(
      isPaid: e.isPaid,
      dueDate: e.dueDate,
      today: today,
    );

    final isFinal = tpl != null &&
        TemplateRules.isFinalMonth(
          e.monthKey,
          startMonth: tpl.startMonth,
          endMonth: tpl.endMonth,
          totalInstallments: tpl.totalInstallments,
        );

    final chips = <Widget>[
      _statusChip(status),
      if (isFinal) const StatusChip.lastInstallment(),
      if (tpl == null) const InfoChip(text: 'จร', emoji: '⚡') else const InfoChip(text: 'ประจำ', emoji: '🔁'),
      InfoChip(
        text: memberLabel(member),
        emoji: memberEmoji(member),
        color: member == null ? null : Color(member!.color),
      ),
    ];

    final total = tpl?.totalInstallments;
    Widget? footer;
    if (tpl != null && total != null && total > 0) {
      final n = TemplateRules.installmentNumber(tpl.startMonth, e.monthKey)
          .clamp(1, total);
      footer = _InstallmentBar(current: n, total: total);
    }

    final dueText = e.isPaid && e.paidAt != null
        ? 'จ่ายเมื่อ ${AppDates.formatDayMonth(e.paidAt!, buddhist: buddhist)}'
        : 'ครบกำหนด ${AppDates.formatDayMonth(e.dueDate, buddhist: buddhist)}';

    return EntryCard(
      slidableKey: ValueKey('slide-expense-${e.id}'),
      index: index,
      emoji: category?.icon ?? '🧾',
      color: Color(category?.color ?? AppColors.expenseA.toARGB32()),
      title: e.name,
      subtitle: '$dueText${category == null ? '' : ' · ${category!.name}'}',
      amountSatang: e.amountSatang,
      amountColor: e.isPaid ? AppColors.successInk : AppColors.dangerInk,
      strikeTitle: false,
      chips: chips,
      footer: footer,
      trailingAction: e.isPaid
          ? null
          : MiniActionButton(
              label: 'จ่ายเลย',
              icon: PhosphorIconsBold.check,
              onTap: () => _setPaid(context, ref, true),
            ),
      onTap: () => _showDetail(context, ref, isFinal),
      swipeActions: [
        CardSwipeAction(
          label: 'แก้ไข',
          icon: PhosphorIconsBold.pencilSimple,
          gradient: AppGradients.brand,
          onTap: () => showExpenseForm(context, editing: e),
        ),
        CardSwipeAction(
          label: 'ลบ',
          icon: PhosphorIconsBold.trash,
          gradient: AppGradients.expense,
          onTap: () => deleteExpenseWithUndo(context, ref, e),
        ),
      ],
    );
  }

  Widget _statusChip(ExpenseStatus s) {
    switch (s) {
      case ExpenseStatus.paid:
        return const StatusChip.paid();
      case ExpenseStatus.overdue:
        return const StatusChip.overdue();
      case ExpenseStatus.dueSoon:
        return const StatusChip.dueSoon();
      case ExpenseStatus.unpaid:
        return const StatusChip.unpaid();
    }
  }

  Future<void> _setPaid(BuildContext context, WidgetRef ref, bool value) async {
    Haptics.medium();
    final messenger = ScaffoldMessenger.of(context);
    final repo = ref.read(expenseRepositoryProvider);
    await repo.setPaid(entry.id, value);
    if (value) {
      showUndoSnackBarOn(
        messenger,
        message: 'จ่าย "${entry.name}" แล้ว ✅',
        onUndo: () => repo.setPaid(entry.id, false),
      );
    }
  }

  Future<void> _closeOut(BuildContext context, WidgetRef ref) async {
    final tpl = template;
    if (tpl == null) return;
    final ok = await showConfirmDialog(
      context,
      emoji: '🏁',
      title: 'ปิดยอด "${entry.name}" ?',
      message: 'เดือนนี้จะเป็นงวดสุดท้าย ระบบจะไม่สร้างรายการเดือนถัดไป ประวัติเดิมยังอยู่ครบ',
      confirmLabel: 'ปิดยอด',
    );
    if (!ok) return;
    final repo = ref.read(expenseRepositoryProvider);
    final messenger = ScaffoldMessenger.of(context);
    final snapshot = await repo.closeTemplate(tpl, entry.monthKey);
    Haptics.medium();
    showUndoSnackBarOn(
      messenger,
      message: 'ปิดยอด "${entry.name}" แล้ว 🏁',
      onUndo: () => repo.restoreTemplate(snapshot),
    );
  }

  void _showDetail(BuildContext context, WidgetRef ref, bool isFinal) {
    final e = entry;
    final tpl = template;
    final total = tpl?.totalInstallments;
    final status = ExpenseRules.status(
      isPaid: e.isPaid,
      dueDate: e.dueDate,
      today: today,
    );

    final canClose = tpl != null && !isFinal;
    final canReopen = tpl != null &&
        tpl.endMonth != null &&
        tpl.endMonth == e.monthKey &&
        (total == null ||
            TemplateRules.installmentNumber(tpl.startMonth, e.monthKey) < total);

    showEntryDetailSheet(
      context,
      emoji: category?.icon ?? '🧾',
      color: Color(category?.color ?? AppColors.expenseA.toARGB32()),
      title: e.name,
      amountSatang: e.amountSatang,
      note: e.note,
      chips: [
        _statusChip(status),
        if (isFinal) const StatusChip.lastInstallment(),
      ],
      rows: [
        DetailRowData('สมาชิก', memberLabel(member)),
        DetailRowData('หมวดหมู่', category?.name ?? 'ไม่ระบุ'),
        DetailRowData(
          'ครบกำหนด',
          AppDates.formatDayMonth(e.dueDate, withYear: true, buddhist: buddhist),
        ),
        if (e.isPaid && e.paidAt != null)
          DetailRowData(
            'จ่ายเมื่อ',
            AppDates.formatDayMonth(e.paidAt!, withYear: true, buddhist: buddhist),
          ),
        DetailRowData(
          'ประเภท',
          tpl == null
              ? 'รายจ่ายจร (ครั้งเดียว)'
              : (total != null ? 'ผ่อนชำระ $total งวด' : 'รายจ่ายประจำทุกเดือน'),
        ),
        if (tpl != null && total != null)
          DetailRowData(
            'งวดที่',
            '${TemplateRules.installmentNumber(tpl.startMonth, e.monthKey).clamp(1, total)} / $total',
          ),
        if (tpl != null)
          DetailRowData(
            'ช่วงเวลา',
            '${AppDates.formatShortMonthYear(tpl.startMonth, buddhist: buddhist)}'
            ' – ${_endLabel(tpl)}',
          ),
        DetailRowData('จำนวน', '฿ ${Money.format(e.amountSatang)}'),
      ],
      actions: [
        if (e.isPaid)
          DetailAction(
            label: 'ยกเลิกการจ่าย',
            icon: PhosphorIconsBold.arrowUUpLeft,
            gradient: AppGradients.saving,
            onTap: () => _setPaid(context, ref, false),
          )
        else
          DetailAction(
            label: 'จ่ายแล้ว',
            icon: PhosphorIconsBold.check,
            gradient: AppGradients.income,
            onTap: () => _setPaid(context, ref, true),
          ),
        DetailAction(
          label: 'แก้ไข',
          icon: PhosphorIconsBold.pencilSimple,
          onTap: () => showExpenseForm(context, editing: e),
        ),
        if (canClose)
          DetailAction(
            label: 'ปิดยอด (งวดนี้เป็นงวดสุดท้าย)',
            icon: PhosphorIconsBold.flagCheckered,
            gradient: AppGradients.saving,
            onTap: () => _closeOut(context, ref),
          ),
        if (canReopen)
          DetailAction(
            label: 'ยกเลิกการปิดยอด',
            icon: PhosphorIconsBold.arrowCounterClockwise,
            gradient: AppGradients.saving,
            onTap: () => ref.read(expenseRepositoryProvider).reopenTemplate(tpl!),
          ),
        DetailAction(
          label: 'ลบ',
          icon: PhosphorIconsBold.trash,
          gradient: AppGradients.expense,
          onTap: () => deleteExpenseWithUndo(context, ref, e),
        ),
      ],
    );
  }

  String _endLabel(ExpenseTemplate tpl) {
    final end = TemplateRules.effectiveEndMonth(
      startMonth: tpl.startMonth,
      endMonth: tpl.endMonth,
      totalInstallments: tpl.totalInstallments,
    );
    return end == null
        ? 'ไม่มีกำหนด'
        : AppDates.formatShortMonthYear(end, buddhist: buddhist);
  }
}

/// แถบความคืบหน้างวดผ่อน "งวดที่ 3/12"
class _InstallmentBar extends StatelessWidget {
  const _InstallmentBar({required this.current, required this.total});

  final int current;
  final int total;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final theme = Theme.of(context);
    final ratio = (current / total).clamp(0.0, 1.0);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                'งวดที่ $current/$total',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: theme.textTheme.bodySmall,
              ),
            ),
            Text(
              '${(ratio * 100).round()}%',
              style: theme.textTheme.bodySmall,
            ),
          ],
        ),
        const SizedBox(height: 4),
        TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: ratio),
          duration: AppDurations.chart,
          curve: Curves.easeOutCubic,
          builder: (context, v, _) => ClipRRect(
            borderRadius: BorderRadius.circular(AppRadius.pill),
            child: Stack(
              children: [
                Container(height: 8, color: p.divider),
                FractionallySizedBox(
                  widthFactor: v,
                  child: Container(
                    height: 8,
                    decoration: const BoxDecoration(
                      gradient: AppGradients.saving,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

/// ลบรายจ่าย: ยืนยัน (และถามขอบเขตถ้าเป็นรายการประจำ) แล้วแสดง Undo
Future<void> deleteExpenseWithUndo(
  BuildContext context,
  WidgetRef ref,
  ExpenseEntry entry,
) async {
  final repo = ref.read(expenseRepositoryProvider);
  final messenger = ScaffoldMessenger.of(context);

  if (entry.templateId == null) {
    final ok = await showConfirmDialog(
      context,
      title: 'ลบ "${entry.name}" ?',
      message: 'รายการนี้จะถูกลบออกจากเดือนนี้',
      confirmLabel: 'ลบ',
      destructive: true,
    );
    if (!ok) return;
    await repo.deleteEntry(entry);
    Haptics.medium();
    showUndoSnackBarOn(
      messenger,
      message: 'ลบ "${entry.name}" แล้ว',
      onUndo: () => repo.restoreEntry(entry),
    );
    return;
  }

  final scope = await showEditScopeDialog(
    context,
    title: 'ลบ "${entry.name}" แบบไหน?',
    message: 'รายการนี้เป็นรายจ่ายประจำ เลือกขอบเขตที่จะลบ',
  );
  if (scope == null) return;

  Haptics.medium();
  if (scope == EditScope.thisMonthOnly) {
    await repo.deleteEntry(entry);
    showUndoSnackBarOn(
      messenger,
      message: 'ลบ "${entry.name}" เฉพาะเดือนนี้แล้ว',
      onUndo: () => repo.restoreEntry(entry),
    );
  } else {
    final tpl = ref.read(expenseTemplateMapProvider)[entry.templateId!];
    if (tpl == null) return;
    final snapshot = await repo.deleteTemplateFromMonth(tpl, entry.monthKey);
    showUndoSnackBarOn(
      messenger,
      message: 'ลบ "${entry.name}" ตั้งแต่เดือนนี้เป็นต้นไปแล้ว',
      onUndo: () => repo.restoreTemplate(snapshot),
    );
  }
}
