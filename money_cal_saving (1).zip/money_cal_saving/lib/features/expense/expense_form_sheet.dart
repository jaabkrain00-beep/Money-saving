import 'package:drift/drift.dart' show Value;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/app_dates.dart';
import '../../core/utils/haptics.dart';
import '../../core/utils/money.dart';
import '../../data/db/app_database.dart';
import '../../data/repositories/expense_repository.dart';
import '../../data/repositories/settings_repository.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';
import '../shared/form_kit.dart';

/// เปิดฟอร์มรายจ่าย
/// - [editing] = null: เพิ่มใหม่ ([startOneTime] เลือกโหมด "จ่ายครั้งเดียว")
/// - [editing] != null: แก้ไข (รายการประจำ/ผ่อนจะถามขอบเขตตอนบันทึก)
Future<void> showExpenseForm(
  BuildContext context, {
  ExpenseEntry? editing,
  bool startOneTime = false,
}) {
  return showFormSheet<void>(
    context,
    builder: (_) => ExpenseFormSheet(editing: editing, startOneTime: startOneTime),
  );
}

class ExpenseFormSheet extends ConsumerStatefulWidget {
  const ExpenseFormSheet({super.key, this.editing, this.startOneTime = false});

  final ExpenseEntry? editing;
  final bool startOneTime;

  @override
  ConsumerState<ExpenseFormSheet> createState() => _ExpenseFormSheetState();
}

class _ExpenseFormSheetState extends ConsumerState<ExpenseFormSheet> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _amount;
  late final TextEditingController _note;
  late final TextEditingController _installments;

  late bool _oneTime;
  bool _useInstallments = false;
  int? _memberId;
  int? _categoryId;
  late int _day;
  late DateTime _date;
  late String _startMonth;
  String? _endMonth;

  /// null = ใช้ค่าจากหน้าตั้งค่า
  int? _remindDays;
  String? _remindTime;
  bool _saving = false;

  ExpenseEntry? get _editing => widget.editing;
  bool get _isEdit => _editing != null;
  bool get _editingInstance => _isEdit && _editing!.templateId != null;

  @override
  void initState() {
    super.initState();
    final month = ref.read(selectedMonthProvider);
    final e = _editing;
    final today = AppDates.dateOnly(DateTime.now());

    _name = TextEditingController(text: e?.name ?? '');
    _amount = TextEditingController(
      text: e == null ? '' : Money.toInputText(e.amountSatang),
    );
    _note = TextEditingController(text: e?.note ?? '');
    _installments = TextEditingController();
    _oneTime = e?.isOneTime ?? widget.startOneTime;
    _memberId = e?.memberId;
    _categoryId = e?.categoryId;

    if (e != null) {
      _day = e.dueDate.day;
      _date = e.dueDate;
      final tpl = e.templateId == null
          ? null
          : ref.read(expenseTemplateMapProvider)[e.templateId!];
      _startMonth = tpl?.startMonth ?? e.monthKey;
      if (tpl != null) {
        _day = tpl.dueDay;
        _endMonth = tpl.endMonth;
        _remindDays = tpl.remindDaysBefore;
        _remindTime = tpl.remindTime;
        if (tpl.totalInstallments != null) {
          _useInstallments = true;
          _installments.text = '${tpl.totalInstallments}';
        }
      }
    } else {
      final isCurrent = month == AppDates.monthKey(today);
      _day = isCurrent ? today.day : 1;
      _date = isCurrent ? today : AppDates.dateInMonth(month, 1);
      _startMonth = month;
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _amount.dispose();
    _note.dispose();
    _installments.dispose();
    super.dispose();
  }

  Future<void> _pickTime() async {
    final s = ref.read(settingsProvider);
    final parts = (_remindTime ?? s.remindTime).split(':');
    final initial = TimeOfDay(
      hour: int.tryParse(parts.first) ?? 9,
      minute: int.tryParse(parts.last) ?? 0,
    );
    final picked = await showTimePicker(
      context: context,
      initialTime: initial,
      builder: (ctx, child) => MediaQuery(
        data: MediaQuery.of(ctx).copyWith(alwaysUse24HourFormat: true),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() => _remindTime = AppDates.formatTime(picked.hour, picked.minute));
    }
  }

  Future<void> _save() async {
    if (!(_formKey.currentState?.validate() ?? false)) {
      Haptics.medium();
      return;
    }
    final recurring = !_oneTime && !(_isEdit && _editing!.templateId == null);
    if (recurring &&
        _endMonth != null &&
        _endMonth!.compareTo(_startMonth) < 0) {
      showAppSnackBar(context, 'เดือนสิ้นสุดต้องไม่ก่อนเดือนเริ่มต้น', emoji: '⚠️');
      return;
    }

    final repo = ref.read(expenseRepositoryProvider);
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);
    final name = _name.text.trim();
    final amount = parseAmountOrZero(_amount.text);
    final note = _note.text.trim();
    final total =
        (recurring && _useInstallments) ? int.tryParse(_installments.text) : null;

    ExpenseTemplateInput input(String startMonth) => ExpenseTemplateInput(
          name: name,
          amountSatang: amount,
          dueDay: _day,
          startMonth: startMonth,
          endMonth: _endMonth,
          totalInstallments: total,
          memberId: _memberId,
          categoryId: _categoryId,
          remindDaysBefore: _remindDays,
          remindTime: _remindTime,
          note: note,
        );

    setState(() => _saving = true);
    try {
      final e = _editing;
      if (e == null) {
        if (_oneTime) {
          await repo.addOneTime(
            name: name,
            amountSatang: amount,
            date: _date,
            memberId: _memberId,
            categoryId: _categoryId,
            note: note,
          );
        } else {
          await repo.addTemplate(input(_startMonth));
        }
      } else if (e.templateId == null) {
        await repo.updateEntry(
          e.copyWith(
            name: name,
            amountSatang: amount,
            dueDate: _date,
            memberId: Value(_memberId),
            categoryId: Value(_categoryId),
            note: note,
          ),
        );
      } else {
        final scope = await showEditScopeDialog(context);
        if (scope == null) {
          if (mounted) setState(() => _saving = false);
          return;
        }
        if (scope == EditScope.thisMonthOnly) {
          await repo.updateEntry(
            e.copyWith(
              name: name,
              amountSatang: amount,
              dueDate: AppDates.dateInMonth(e.monthKey, _day),
              memberId: Value(_memberId),
              categoryId: Value(_categoryId),
              note: note,
            ),
          );
        } else {
          final tpl = ref.read(expenseTemplateMapProvider)[e.templateId!];
          if (tpl == null) throw StateError('ไม่พบแม่แบบรายจ่าย');
          await repo.updateTemplateFromMonth(
            original: tpl,
            input: input(tpl.startMonth),
            fromMonth: e.monthKey,
          );
        }
      }
      Haptics.light();
      navigator.pop();
      showAppSnackBarOn(messenger, 'บันทึกรายจ่ายแล้ว', emoji: '🧾');
    } catch (err) {
      if (mounted) setState(() => _saving = false);
      showAppSnackBarOn(messenger, 'บันทึกไม่สำเร็จ ลองใหม่อีกครั้ง', emoji: '😢');
    }
  }

  @override
  Widget build(BuildContext context) {
    final categories = ref.watch(expenseCategoriesProvider);
    final settings = ref.watch(settingsProvider);
    final theme = Theme.of(context);
    final p = context.palette;
    final showDateOnly = _oneTime || (_isEdit && _editing!.templateId == null);

    return Form(
      key: _formKey,
      child: FormSheetScaffold(
        emoji: '🧾',
        title: _isEdit ? 'แก้ไขรายจ่าย' : 'เพิ่มรายจ่าย',
        gradient: AppGradients.expense,
        saving: _saving,
        onSave: _save,
        children: [
          if (!_isEdit)
            SegmentSwitch(
              labels: const ['ประจำ / ผ่อนชำระ', 'จ่ายครั้งเดียว'],
              index: _oneTime ? 1 : 0,
              gradient: AppGradients.expense,
              onChanged: (i) => setState(() => _oneTime = i == 1),
            ),
          const FieldLabel('ชื่อรายการ'),
          NameField(
            controller: _name,
            hint: _oneTime ? 'เช่น ค่าอาหาร, ซื้อของ' : 'เช่น ค่าไฟ, ผ่อนรถ',
          ),
          FieldLabel(_useInstallments && !showDateOnly
              ? 'ยอดต่องวด (บาท)'
              : 'จำนวนเงิน (บาท)'),
          AmountField(controller: _amount),
          const FieldLabel('ของใคร'),
          MemberChips(
            selectedId: _memberId,
            onChanged: (id) => setState(() => _memberId = id),
          ),
          const FieldLabel('หมวดหมู่'),
          CategoryChips(
            categories: categories,
            selectedId: _categoryId,
            onChanged: (id) => setState(() => _categoryId = id),
          ),
          if (showDateOnly) ...[
            FieldLabel(_oneTime ? 'วันที่จ่าย' : 'วันที่'),
            DateField(
              value: _date,
              onChanged: (d) => setState(() => _date = d),
            ),
          ] else ...[
            const FieldLabel('วันครบกำหนดจ่าย'),
            DayOfMonthField(
              value: _day,
              onChanged: (d) => setState(() => _day = d),
            ),
            if (!_isEdit) ...[
              const FieldLabel('เริ่มตั้งแต่เดือน'),
              MonthKeyField(
                value: _startMonth,
                onChanged: (m) => setState(() => _startMonth = m),
              ),
            ],
            const SizedBox(height: AppSpacing.md),
            GlassCard(
              radius: AppRadius.r20,
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.lg,
                vertical: 4,
              ),
              child: SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                value: _useInstallments,
                title: Text('ผ่อนชำระเป็นงวด', style: theme.textTheme.titleSmall),
                subtitle: Text(
                  'ระบบนับงวดให้ และหยุดเองเมื่อครบ',
                  style: theme.textTheme.bodySmall,
                ),
                onChanged: (v) => setState(() => _useInstallments = v),
              ),
            ),
            if (_useInstallments) ...[
              const FieldLabel('จำนวนงวดทั้งหมด'),
              TextFormField(
                controller: _installments,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(3),
                ],
                decoration: const InputDecoration(
                  hintText: 'เช่น 12',
                  suffixText: 'งวด',
                ),
                validator: (v) {
                  final n = int.tryParse(v ?? '');
                  if (n == null || n < 1) return 'กรุณากรอกจำนวนงวด (อย่างน้อย 1)';
                  return null;
                },
              ),
            ] else ...[
              const FieldLabel('สิ้นสุดเดือน (ไม่บังคับ)'),
              MonthKeyField(
                value: _endMonth,
                placeholder: 'ไม่มีกำหนดสิ้นสุด',
                minKey: _startMonth,
                onChanged: (m) => setState(() => _endMonth = m),
                onCleared: () => setState(() => _endMonth = null),
              ),
            ],
            const FieldLabel('แจ้งเตือนก่อนครบกำหนด'),
            DropdownButtonFormField<int?>(
              value: _remindDays,
              isExpanded: true,
              borderRadius: BorderRadius.circular(AppRadius.r20),
              items: [
                DropdownMenuItem<int?>(
                  value: null,
                  child: Text(
                    'ตามค่าตั้งต้น (${_daysLabel(settings.remindDaysBefore)})',
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                for (final d in SettingsState.remindDayOptions)
                  DropdownMenuItem<int?>(
                    value: d,
                    child: Text(_daysLabel(d), overflow: TextOverflow.ellipsis),
                  ),
              ],
              onChanged: (v) => setState(() => _remindDays = v),
            ),
            FieldLabel('เวลาแจ้งเตือน'),
            PressableScale(
              onTap: _pickTime,
              scale: 0.99,
              child: Container(
                constraints: const BoxConstraints(minHeight: 56),
                padding: const EdgeInsets.only(left: 16, right: 8),
                decoration: BoxDecoration(
                  color: p.inputFill,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Row(
                  children: [
                    Icon(PhosphorIconsRegular.bell, size: 20, color: p.inkSoft),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _remindTime == null
                            ? 'ตามค่าตั้งต้น (${settings.remindTime} น.)'
                            : '$_remindTime น.',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (_remindTime != null)
                      IconButton(
                        tooltip: 'ใช้ค่าตั้งต้น',
                        constraints: const BoxConstraints(
                          minWidth: AppSpacing.minTap,
                          minHeight: AppSpacing.minTap,
                        ),
                        icon: Icon(PhosphorIconsRegular.x,
                            size: 18, color: p.inkSoft),
                        onPressed: () => setState(() => _remindTime = null),
                      )
                    else
                      const SizedBox(width: 8),
                  ],
                ),
              ),
            ),
          ],
          const FieldLabel('หมายเหตุ'),
          NoteField(controller: _note),
          const SizedBox(height: AppSpacing.sm),
        ],
      ),
    );
  }

  static String _daysLabel(int d) => d == 0 ? 'วันที่ครบกำหนด' : 'ล่วงหน้า $d วัน';
}
