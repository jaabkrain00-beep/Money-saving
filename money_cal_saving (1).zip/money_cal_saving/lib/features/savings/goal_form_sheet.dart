import 'package:drift/drift.dart' show Value;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/app_dates.dart';
import '../../core/utils/haptics.dart';
import '../../core/utils/money.dart';
import '../../data/db/app_database.dart';
import '../../data/repositories/savings_repository.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';
import '../shared/form_kit.dart';

const List<String> _goalEmojis = [
  '🎯', '🏠', '🚗', '✈️', '🎓', '💍', '👶', '🏖️',
  '📱', '💻', '🎁', '🐷', '🩺', '🛡️', '🎄', '🌟',
];

/// ฟอร์มเพิ่ม/แก้ไขเป้าหมายออม
Future<void> showGoalForm(BuildContext context, {SavingGoal? editing}) {
  return showFormSheet<void>(
    context,
    builder: (_) => GoalFormSheet(editing: editing),
  );
}

class GoalFormSheet extends ConsumerStatefulWidget {
  const GoalFormSheet({super.key, this.editing});

  final SavingGoal? editing;

  @override
  ConsumerState<GoalFormSheet> createState() => _GoalFormSheetState();
}

class _GoalFormSheetState extends ConsumerState<GoalFormSheet> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _target;
  late String _emoji;
  late int _color;
  DateTime? _targetDate;
  int? _memberId;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final g = widget.editing;
    _name = TextEditingController(text: g?.name ?? '');
    _target = TextEditingController(
      text: g == null ? '' : Money.toInputText(g.targetSatang),
    );
    _emoji = g?.emoji ?? '🎯';
    _color = g?.color ?? AppColors.savingA.toARGB32();
    _targetDate = g?.targetDate;
    _memberId = g?.memberId;
  }

  @override
  void dispose() {
    _name.dispose();
    _target.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!(_formKey.currentState?.validate() ?? false)) {
      Haptics.medium();
      return;
    }
    final repo = ref.read(savingsRepositoryProvider);
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);
    final target = parseAmountOrZero(_target.text);
    setState(() => _saving = true);
    try {
      final g = widget.editing;
      var completedNow = false;
      if (g == null) {
        await repo.addGoal(
          GoalInput(
            name: _name.text.trim(),
            targetSatang: target,
            color: _color,
            targetDate: _targetDate,
            emoji: _emoji,
            memberId: _memberId,
          ),
        );
      } else {
        final r = await repo.updateGoal(
          g.copyWith(
            name: _name.text.trim(),
            targetSatang: target,
            color: _color,
            targetDate: Value(_targetDate),
            emoji: _emoji,
            memberId: Value(_memberId),
          ),
        );
        completedNow = r.justCompleted;
      }
      Haptics.light();
      navigator.pop();
      showAppSnackBarOn(
        messenger,
        completedNow ? 'ถึงเป้าหมายแล้ว 🎉' : 'บันทึกเป้าหมายแล้ว',
        emoji: '🐷',
      );
    } catch (_) {
      if (mounted) setState(() => _saving = false);
      showAppSnackBarOn(messenger, 'บันทึกไม่สำเร็จ ลองใหม่อีกครั้ง', emoji: '😢');
    }
  }

  @override
  Widget build(BuildContext context) {
    final pal = context.palette;
    return Form(
      key: _formKey,
      child: FormSheetScaffold(
        emoji: _emoji,
        title: widget.editing == null ? 'เป้าหมายออมใหม่' : 'แก้ไขเป้าหมาย',
        gradient: AppGradients.saving,
        saving: _saving,
        onSave: _save,
        children: [
          const FieldLabel('ชื่อเป้าหมาย'),
          NameField(controller: _name, hint: 'เช่น ท่องเที่ยวญี่ปุ่น, ดาวน์รถ'),
          const FieldLabel('จำนวนเงินเป้าหมาย (บาท)'),
          AmountField(controller: _target),
          const FieldLabel('ไอคอน'),
          Wrap(
            spacing: AppSpacing.sm,
            runSpacing: AppSpacing.sm,
            children: [
              for (final e in _goalEmojis)
                Semantics(
                  button: true,
                  label: 'เลือกไอคอน $e',
                  child: GestureDetector(
                    onTap: () {
                      Haptics.selection();
                      setState(() => _emoji = e);
                    },
                    child: AnimatedContainer(
                      duration: AppDurations.fast,
                      width: AppSpacing.minTap,
                      height: AppSpacing.minTap,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: _emoji == e
                            ? Color(_color).withValues(alpha: 0.5)
                            : pal.inputFill,
                        borderRadius: BorderRadius.circular(AppRadius.r16),
                        border: Border.all(
                          color: _emoji == e ? Color(_color) : Colors.transparent,
                          width: 2,
                        ),
                      ),
                      child: Text(e, style: const TextStyle(fontSize: 24)),
                    ),
                  ),
                ),
            ],
          ),
          const FieldLabel('สี'),
          Wrap(
            spacing: AppSpacing.md,
            runSpacing: AppSpacing.sm,
            children: [
              for (final c in AppColors.pickerColors)
                GestureDetector(
                  onTap: () {
                    Haptics.selection();
                    setState(() => _color = c.toARGB32());
                  },
                  child: SizedBox(
                    width: AppSpacing.minTap,
                    height: AppSpacing.minTap,
                    child: Center(
                      child: AnimatedContainer(
                        duration: AppDurations.fast,
                        width: _color == c.toARGB32() ? 40 : 34,
                        height: _color == c.toARGB32() ? 40 : 34,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: AppGradients.fromColor(c),
                          border: Border.all(
                            color: _color == c.toARGB32()
                                ? pal.ink
                                : Colors.white.withValues(alpha: 0.8),
                            width: _color == c.toARGB32() ? 2.5 : 1.5,
                          ),
                        ),
                        child: _color == c.toARGB32()
                            ? const Icon(PhosphorIconsBold.check,
                                size: 18, color: AppColors.ink)
                            : null,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const FieldLabel('วันที่ต้องการถึงเป้าหมาย (ไม่บังคับ)'),
          _DateOrClear(
            value: _targetDate,
            onChanged: (d) => setState(() => _targetDate = d),
          ),
          const FieldLabel('ของใคร'),
          MemberChips(
            selectedId: _memberId,
            onChanged: (id) => setState(() => _memberId = id),
          ),
          const SizedBox(height: AppSpacing.sm),
        ],
      ),
    );
  }
}

class _DateOrClear extends ConsumerWidget {
  const _DateOrClear({required this.value, required this.onChanged});

  final DateTime? value;
  final ValueChanged<DateTime?> onChanged;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final v = value;
    if (v == null) {
      return Align(
        alignment: Alignment.centerLeft,
        child: TextButton.icon(
          onPressed: () async {
            final now = DateTime.now();
            final picked = await showDatePicker(
              context: context,
              initialDate: DateTime(now.year, now.month + 6, now.day),
              firstDate: DateTime(now.year - 1),
              lastDate: DateTime(now.year + 50),
              locale: const Locale('th', 'TH'),
            );
            if (picked != null) onChanged(AppDates.dateOnly(picked));
          },
          icon: const Icon(PhosphorIconsRegular.calendarPlus),
          label: const Text('กำหนดวันที่'),
        ),
      );
    }
    return Row(
      children: [
        Expanded(
          child: DateField(
            value: v,
            firstDate: DateTime(DateTime.now().year - 1),
            lastDate: DateTime(DateTime.now().year + 50),
            onChanged: onChanged,
          ),
        ),
        IconButton(
          tooltip: 'ล้างวันที่',
          constraints: const BoxConstraints(
            minWidth: AppSpacing.minTap,
            minHeight: AppSpacing.minTap,
          ),
          icon: const Icon(PhosphorIconsRegular.x),
          onPressed: () => onChanged(null),
        ),
      ],
    );
  }
}
