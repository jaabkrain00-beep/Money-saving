import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/app_dates.dart';
import '../../core/utils/haptics.dart';
import '../../core/utils/money.dart';
import '../../data/db/app_database.dart';
import '../../data/repositories/savings_repository.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';
import '../shared/form_kit.dart';
import 'celebration.dart';

/// ฟอร์มฝาก/ถอนเงินออม
/// - [goal] = null: ให้เลือกเป้าหมายในฟอร์ม (ใช้จากปุ่ม "+")
/// - [editing] != null: แก้ไขรายการเดิม
Future<void> showSavingTxForm(
  BuildContext context, {
  SavingGoal? goal,
  SavingTxType type = SavingTxType.deposit,
  SavingTransaction? editing,
}) {
  return showFormSheet<void>(
    context,
    builder: (_) => SavingTxFormSheet(goal: goal, type: type, editing: editing),
  );
}

class SavingTxFormSheet extends ConsumerStatefulWidget {
  const SavingTxFormSheet({
    super.key,
    this.goal,
    this.type = SavingTxType.deposit,
    this.editing,
  });

  final SavingGoal? goal;
  final SavingTxType type;
  final SavingTransaction? editing;

  @override
  ConsumerState<SavingTxFormSheet> createState() => _SavingTxFormSheetState();
}

class _SavingTxFormSheetState extends ConsumerState<SavingTxFormSheet> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _amount;
  late final TextEditingController _note;
  late SavingTxType _type;
  late DateTime _date;
  int? _goalId;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.editing;
    _amount = TextEditingController(
      text: e == null ? '' : Money.toInputText(e.amountSatang),
    );
    _note = TextEditingController(text: e?.note ?? '');
    _type = e?.type ?? widget.type;
    _date = e?.date ?? AppDates.dateOnly(DateTime.now());
    _goalId = e?.goalId ?? widget.goal?.id;
  }

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!(_formKey.currentState?.validate() ?? false)) {
      Haptics.medium();
      return;
    }
    final goalId = _goalId;
    if (goalId == null) {
      showAppSnackBar(context, 'กรุณาเลือกเป้าหมายออม', emoji: '⚠️');
      return;
    }
    final repo = ref.read(savingsRepositoryProvider);
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);
    final rootContext = Navigator.of(context, rootNavigator: true).context;
    final amount = parseAmountOrZero(_amount.text);
    setState(() => _saving = true);
    try {
      final e = widget.editing;
      final TxResult result;
      if (e == null) {
        result = await repo.addTransaction(
          goalId: goalId,
          amountSatang: amount,
          type: _type,
          date: _date,
          note: _note.text.trim(),
        );
      } else {
        result = await repo.updateTransaction(
          e.copyWith(
            amountSatang: amount,
            type: _type,
            date: _date,
            note: _note.text.trim(),
          ),
        );
      }
      Haptics.medium();
      navigator.pop();
      if (result.justCompleted) {
        showCelebration(rootContext);
        showAppSnackBarOn(messenger, 'ยินดีด้วย! ออมถึงเป้าหมายแล้ว', emoji: '🎉');
      } else {
        showAppSnackBarOn(
          messenger,
          _type == SavingTxType.deposit ? 'ฝากเงินออมแล้ว' : 'ถอนเงินออมแล้ว',
          emoji: '🐷',
        );
      }
    } on InsufficientSavingsException catch (ex) {
      if (mounted) setState(() => _saving = false);
      showAppSnackBarOn(
        messenger,
        'ยอดออมไม่พอ เหลือ ฿${Money.format(ex.balance)}',
        emoji: '⚠️',
      );
    } catch (_) {
      if (mounted) setState(() => _saving = false);
      showAppSnackBarOn(messenger, 'บันทึกไม่สำเร็จ ลองใหม่อีกครั้ง', emoji: '😢');
    }
  }

  @override
  Widget build(BuildContext context) {
    final goals = ref.watch(goalsProvider).valueOrNull ?? const <SavingGoal>[];
    final balances = ref.watch(goalBalancesProvider);
    final isDeposit = _type == SavingTxType.deposit;
    final balance = _goalId == null ? null : (balances[_goalId] ?? 0);

    return Form(
      key: _formKey,
      child: FormSheetScaffold(
        emoji: isDeposit ? '🐷' : '💸',
        title: widget.editing == null
            ? (isDeposit ? 'ฝากเงินออม' : 'ถอนเงินออม')
            : 'แก้ไขรายการออม',
        gradient: isDeposit ? AppGradients.saving : AppGradients.expense,
        saving: _saving,
        onSave: _save,
        children: [
          SegmentSwitch(
            labels: const ['ฝากเข้า', 'ถอนออก'],
            index: isDeposit ? 0 : 1,
            gradient: isDeposit ? AppGradients.saving : AppGradients.expense,
            onChanged: (i) => setState(
              () => _type = i == 0 ? SavingTxType.deposit : SavingTxType.withdraw,
            ),
          ),
          if (widget.goal == null && widget.editing == null) ...[
            const FieldLabel('เป้าหมาย'),
            if (goals.isEmpty)
              Text(
                'ยังไม่มีเป้าหมายออม สร้างเป้าหมายก่อนนะ',
                style: Theme.of(context).textTheme.bodyMedium,
              )
            else
              DropdownButtonFormField<int>(
                value: _goalId,
                isExpanded: true,
                borderRadius: BorderRadius.circular(AppRadius.r20),
                hint: const Text('เลือกเป้าหมาย'),
                items: [
                  for (final g in goals)
                    DropdownMenuItem(
                      value: g.id,
                      child: Text(
                        '${g.emoji} ${g.name}',
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                ],
                onChanged: (v) => setState(() => _goalId = v),
              ),
          ],
          if (balance != null && !isDeposit)
            Padding(
              padding: const EdgeInsets.only(top: AppSpacing.sm),
              child: Text(
                'ยอดออมที่ถอนได้ ฿${Money.format(balance)}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
          const FieldLabel('จำนวนเงิน (บาท)'),
          AmountField(controller: _amount, autofocus: widget.editing == null),
          const FieldLabel('วันที่'),
          DateField(
            value: _date,
            onChanged: (d) => setState(() => _date = d),
          ),
          const FieldLabel('หมายเหตุ'),
          NoteField(controller: _note),
          const SizedBox(height: AppSpacing.sm),
        ],
      ),
    );
  }
}
