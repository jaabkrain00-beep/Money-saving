import 'dart:math' as math;

import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

/// พลุกระดาษสีพาสเทล เมื่อออมถึงเป้าหมาย (วางบน Overlay หน้าจอ แล้วลบเองหลัง 4 วินาที)
void showCelebration(BuildContext context) {
  final overlay = Overlay.maybeOf(context, rootOverlay: true);
  if (overlay == null) return;

  final controller = ConfettiController(duration: const Duration(seconds: 2));
  late final OverlayEntry entry;
  entry = OverlayEntry(
    builder: (_) => IgnorePointer(
      child: Stack(
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: ConfettiWidget(
              confettiController: controller,
              blastDirection: math.pi / 2,
              blastDirectionality: BlastDirectionality.explosive,
              emissionFrequency: 0.08,
              numberOfParticles: 24,
              maxBlastForce: 28,
              minBlastForce: 8,
              gravity: 0.25,
              shouldLoop: false,
              colors: const [
                AppColors.incomeA,
                AppColors.expenseA,
                AppColors.savingA,
                AppColors.brandA,
                AppColors.dueSoonA,
              ],
            ),
          ),
        ],
      ),
    ),
  );
  overlay.insert(entry);
  controller.play();
  Future<void>.delayed(const Duration(seconds: 4), () {
    entry.remove();
    controller.dispose();
  });
}
