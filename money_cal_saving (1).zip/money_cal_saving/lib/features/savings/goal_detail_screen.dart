import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/app_dates.dart';
import '../../core/utils/haptics.dart';
import '../../core/utils/money.dart';
import '../../data/db/app_database.dart';
import '../../domain/goal_calculator.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';
import '../shared/entry_card.dart';
import '../shared/page_kit.dart';
import 'celebration.dart';
import 'goal_form_sheet.dart';
import 'saving_tx_form_sheet.dart';
import 'savings_screen.dart';

/// รายละเอียดเป้าหมาย: วงแหวนใหญ่ + แผนออมรายเดือน + ประวัติฝาก/ถอน
class GoalDetailScreen extends ConsumerWidget {
  const GoalDetailScreen({super.key, required this.goalId});

  final int goalId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final goals = ref.watch(goalsProvider).valueOrNull ?? const <SavingGoal>[];
    SavingGoal? goal;
    for (final g in goals) {
      if (g.id == goalId) goal = g;
    }
    if (goal == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final theme = Theme.of(context);
    final buddhist = ref.watch(useBuddhistYearProvider);
    final saved = ref.watch(goalBalancesProvider)[goalId] ?? 0;
    final txs = [
      for (final t in ref.watch(allSavingTxProvider).valueOrNull ??
          const <SavingTransaction>[])
        if (t.goalId == goalId) t,
    ]..sort((a, b) {
        final c = b.date.compareTo(a.date);
        return c != 0 ? c : b.id.compareTo(a.id);
      });

    final progress = GoalCalculator.progress(saved: saved, target: goal.targetSatang);
    final color = Color(goal.color);
    final needed = monthlyNeededText(goal, saved, buddhist: buddhist);
    final g = goal;

    return Scaffold(
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        slivers: [
          PastelSliverAppBar(
            title: g.name,
            leading: const PastelBackButton(),
            actions: [
              AppBarIconButton(
                icon: PhosphorIconsBold.pencilSimple,
                tooltip: 'แก้ไขเป้าหมาย',
                onPressed: () => showGoalForm(context, editing: g),
              ),
              AppBarIconButton(
                icon: PhosphorIconsBold.trash,
                tooltip: 'ลบเป้าหมาย',
                onPressed: () => _deleteGoal(context, ref, g),
              ),
            ],
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.screenH,
                vertical: AppSpacing.sm,
              ),
              child: GradientCard(
                gradient: AppGradients.fromColor(color),
                child: Column(
                  children: [
                    ProgressRing(
                      fraction: progress.fraction,
                      colors: const [Colors.white, AppColors.brandB, Colors.white],
                      size: 148,
                      strokeWidth: 14,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(g.emoji, style: const TextStyle(fontSize: 34)),
                          Text('${progress.percent}%',
                              style: theme.textTheme.titleLarge),
                        ],
                      ),
                    ),
                    const SizedBox(height: AppSpacing.md),
                    AmountText(
                      saved,
                      animate: true,
                      alignment: Alignment.center,
                      style: theme.textTheme.headlineMedium,
                    ),
                    Text(
                      'เป้าหมาย ฿${Money.format(g.targetSatang)}',
                      style: theme.textTheme.bodyMedium,
                    ),
                    if (progress.isReached)
                      Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: GestureDetector(
                          onTap: () => showCelebration(context),
                          child: Text(
                            '🎉 ถึงเป้าหมายแล้ว! (แตะเพื่อฉลองอีกครั้ง)',
                            textAlign: TextAlign.center,
                            style: theme.textTheme.titleSmall,
                          ),
                        ),
                      )
                    else if (needed != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Text(
                          needed,
                          textAlign: TextAlign.center,
                          style: theme.textTheme.bodyMedium,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.screenH,
                vertical: AppSpacing.sm,
              ),
              child: Row(
                children: [
                  Expanded(
                    child: GradientButton(
                      label: 'ฝากเงิน',
                      icon: PhosphorIconsBold.plus,
                      expand: true,
                      gradient: AppGradients.saving,
                      onPressed: () => showSavingTxForm(context, goal: g),
                    ),
                  ),
                  const SizedBox(width: AppSpacing.md),
                  Expanded(
                    child: GradientButton(
                      label: 'ถอนเงิน',
                      icon: PhosphorIconsBold.minus,
                      expand: true,
                      gradient: AppGradients.expense,
                      onPressed: () => showSavingTxForm(
                        context,
                        goal: g,
                        type: SavingTxType.withdraw,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SectionHeader(title: 'ประวัติฝาก/ถอน')),
          if (txs.isEmpty)
            const SliverToBoxAdapter(
              child: SizedBox(
                height: 220,
                child: EmptyState(
                  emoji: '🌱',
                  title: 'ยังไม่มีรายการ',
                  message: 'กด "ฝากเงิน" เพื่อเริ่มออมได้เลย',
                  gradient: AppGradients.saving,
                ),
              ),
            )
          else
            SliverList.builder(
              itemCount: txs.length,
              itemBuilder: (context, i) {
                final t = txs[i];
                final isDeposit = t.type == SavingTxType.deposit;
                return EntryCard(
                  slidableKey: ValueKey('tx-${t.id}'),
                  index: i,
                  emoji: isDeposit ? '⬆️' : '⬇️',
                  color: isDeposit ? AppColors.savingA : AppColors.expenseA,
                  title: isDeposit ? 'ฝากเงิน' : 'ถอนเงิน',
                  subtitle: t.note.trim().isEmpty
                      ? AppDates.formatDayMonth(t.date,
                          withYear: true, buddhist: buddhist)
                      : '${AppDates.formatDayMonth(t.date, buddhist: buddhist)} · ${t.note.trim()}',
                  amountSatang: isDeposit ? t.amountSatang : -t.amountSatang,
                  amountColor:
                      isDeposit ? AppColors.successInk : AppColors.dangerInk,
                  onTap: () => showSavingTxForm(context, goal: g, editing: t),
                  swipeActions: [
                    CardSwipeAction(
                      label: 'แก้ไข',
                      icon: PhosphorIconsBold.pencilSimple,
                      gradient: AppGradients.brand,
                      onTap: () => showSavingTxForm(context, goal: g, editing: t),
                    ),
                    CardSwipeAction(
                      label: 'ลบ',
                      icon: PhosphorIconsBold.trash,
                      gradient: AppGradients.expense,
                      onTap: () => _deleteTx(context, ref, t),
                    ),
                  ],
                );
              },
            ),
          const SliverToBoxAdapter(child: SizedBox(height: AppSpacing.huge)),
        ],
      ),
    );
  }

  Future<void> _deleteTx(
    BuildContext context,
    WidgetRef ref,
    SavingTransaction t,
  ) async {
    final repo = ref.read(savingsRepositoryProvider);
    final messenger = ScaffoldMessenger.of(context);
    final ok = await showConfirmDialog(
      context,
      title: 'ลบรายการนี้?',
      message: 'ยอดออมจะถูกคำนวณใหม่',
      confirmLabel: 'ลบ',
      destructive: true,
    );
    if (!ok) return;
    await repo.deleteTransaction(t);
    Haptics.medium();
    showUndoSnackBarOn(
      messenger,
      message: 'ลบรายการแล้ว',
      onUndo: () => repo.restoreTransaction(t),
    );
  }

  Future<void> _deleteGoal(
    BuildContext context,
    WidgetRef ref,
    SavingGoal g,
  ) async {
    final repo = ref.read(savingsRepositoryProvider);
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);
    final ok = await showConfirmDialog(
      context,
      title: 'ลบเป้าหมาย "${g.name}" ?',
      message: 'ประวัติฝาก/ถอนของเป้าหมายนี้จะถูกลบด้วย',
      confirmLabel: 'ลบ',
      destructive: true,
    );
    if (!ok) return;
    final snapshot = await repo.deleteGoal(g);
    Haptics.medium();
    navigator.pop();
    showUndoSnackBarOn(
      messenger,
      message: 'ลบเป้าหมาย "${g.name}" แล้ว',
      onUndo: () => repo.restoreGoal(snapshot),
    );
  }
}
