import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/app_dates.dart';
import '../../core/utils/haptics.dart';
import '../../core/utils/labels.dart';
import '../../core/utils/money.dart';
import '../../data/db/app_database.dart';
import '../../domain/goal_calculator.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';
import '../shared/entry_card.dart';
import '../shared/page_kit.dart';
import 'goal_detail_screen.dart';
import 'goal_form_sheet.dart';
import 'saving_tx_form_sheet.dart';

/// หน้าเป้าหมายออม: ยอดออมรวม + การ์ดเป้าหมายพร้อมวงแหวนความคืบหน้า
class SavingsScreen extends ConsumerStatefulWidget {
  const SavingsScreen({super.key});

  @override
  ConsumerState<SavingsScreen> createState() => _SavingsScreenState();
}

class _SavingsScreenState extends ConsumerState<SavingsScreen> {
  int? _memberFilter;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final goalsAsync = ref.watch(goalsProvider);
    final allGoals = goalsAsync.valueOrNull ?? const <SavingGoal>[];
    final balances = ref.watch(goalBalancesProvider);
    final members = ref.watch(membersProvider).valueOrNull ?? const <Member>[];
    final memberMap = ref.watch(memberMapProvider);

    final filterId =
        (_memberFilter != null && memberMap.containsKey(_memberFilter))
            ? _memberFilter
            : null;
    final goals = filterId == null
        ? allGoals
        : [for (final g in allGoals) if (g.memberId == filterId) g];

    final totalSaved = goals.fold<int>(0, (s, g) => s + (balances[g.id] ?? 0));
    final totalTarget = goals.fold<int>(0, (s, g) => s + g.targetSatang);
    final done = goals.where((g) => g.isCompleted).length;

    return Scaffold(
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        slivers: [
          PastelSliverAppBar(
            title: 'เป้าหมายออม',
            leading: const PastelBackButton(),
            actions: [
              AppBarIconButton(
                icon: PhosphorIconsBold.plusCircle,
                tooltip: 'เพิ่มเป้าหมาย',
                onPressed: () => showGoalForm(context),
              ),
            ],
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.screenH,
                vertical: AppSpacing.sm,
              ),
              child: GradientCard(
                gradient: AppGradients.saving,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'ยอดออมรวม · สำเร็จ $done/${goals.length} เป้าหมาย',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodyMedium,
                    ),
                    AmountText(
                      totalSaved,
                      animate: true,
                      style: theme.textTheme.headlineMedium,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'เป้าหมายรวม ฿${Money.format(totalTarget)}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: MemberFilterBar(
              members: members,
              selectedId: filterId,
              onChanged: (id) => setState(() => _memberFilter = id),
            ),
          ),
          if (goalsAsync.isLoading && allGoals.isEmpty)
            const SliverFillRemaining(
              hasScrollBody: false,
              child: Center(child: CircularProgressIndicator()),
            )
          else if (goals.isEmpty)
            SliverFillRemaining(
              hasScrollBody: false,
              child: EmptyState(
                emoji: '🐷',
                title: 'ยังไม่มีเป้าหมายออม',
                message: 'ตั้งเป้าหมาย เช่น ท่องเที่ยว ดาวน์บ้าน เงินสำรองฉุกเฉิน แล้วค่อยๆ เก็บไปด้วยกัน',
                actionLabel: 'สร้างเป้าหมาย',
                gradient: AppGradients.saving,
                onAction: () => showGoalForm(context),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.only(top: AppSpacing.sm),
              sliver: SliverList.builder(
                itemCount: goals.length,
                itemBuilder: (context, i) => StaggeredItem(
                  index: i,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppSpacing.screenH,
                      vertical: 5,
                    ),
                    child: GoalCard(
                      key: ValueKey('goal-${goals[i].id}'),
                      goal: goals[i],
                      saved: balances[goals[i].id] ?? 0,
                      owner: memberMap[goals[i].memberId],
                    ),
                  ),
                ),
              ),
            ),
          const SliverToBoxAdapter(child: SizedBox(height: AppSpacing.huge)),
        ],
      ),
    );
  }
}

/// ข้อความ "ต้องออมเดือนละเท่าไร" จากเป้าหมายและวันที่เป้าหมาย
String? monthlyNeededText(SavingGoal goal, int saved, {required bool buddhist}) {
  final progress = GoalCalculator.progress(saved: saved, target: goal.targetSatang);
  if (progress.isReached) return null;
  final plan = GoalCalculator.monthlyPlan(
    remaining: progress.remaining,
    targetDate: goal.targetDate,
    today: DateTime.now(),
  );
  if (plan == null) return 'เหลืออีก ฿${Money.format(progress.remaining)}';
  if (plan.overdue) {
    return 'เลยวันเป้าหมายแล้ว เหลืออีก ฿${Money.format(progress.remaining)}';
  }
  return 'ออมเดือนละ ฿${Money.format(plan.perMonthSatang)} อีก ${plan.months} เดือน';
}

class GoalCard extends ConsumerWidget {
  const GoalCard({
    super.key,
    required this.goal,
    required this.saved,
    required this.owner,
  });

  final SavingGoal goal;
  final int saved;
  final Member? owner;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final buddhist = ref.watch(useBuddhistYearProvider);
    final progress = GoalCalculator.progress(saved: saved, target: goal.targetSatang);
    final color = Color(goal.color);
    final needed = monthlyNeededText(goal, saved, buddhist: buddhist);

    return GlassCard(
      radius: AppRadius.r24,
      padding: const EdgeInsets.all(16),
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (_) => GoalDetailScreen(goalId: goal.id),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              ProgressRing(
                fraction: progress.fraction,
                colors: [color, AppColors.brandB, color],
                size: 76,
                child: Text(goal.emoji, style: const TextStyle(fontSize: 28)),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            goal.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.titleMedium,
                          ),
                        ),
                        if (goal.isCompleted)
                          const Padding(
                            padding: EdgeInsets.only(left: 6),
                            child: Text('🎉', style: TextStyle(fontSize: 18)),
                          ),
                      ],
                    ),
                    AmountText(
                      saved,
                      animate: true,
                      style: theme.textTheme.titleLarge,
                    ),
                    Text(
                      'จาก ฿${Money.format(goal.targetSatang)} · ${progress.percent}%',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              if (needed != null) InfoChip(text: needed, emoji: '🗓️'),
              if (goal.targetDate != null)
                InfoChip(
                  text: AppDates.formatDayMonth(goal.targetDate!,
                      withYear: true, buddhist: buddhist),
                  emoji: '🎯',
                ),
              InfoChip(
                text: memberLabel(owner),
                emoji: memberEmoji(owner),
                color: owner == null ? null : Color(owner!.color),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: MiniActionButton(
                  label: 'ฝาก',
                  icon: PhosphorIconsBold.plus,
                  gradient: AppGradients.saving,
                  onTap: () => showSavingTxForm(context, goal: goal),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: MiniActionButton(
                  label: 'ถอน',
                  icon: PhosphorIconsBold.minus,
                  gradient: AppGradients.expense,
                  onTap: () {
                    Haptics.light();
                    showSavingTxForm(
                      context,
                      goal: goal,
                      type: SavingTxType.withdraw,
                    );
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
