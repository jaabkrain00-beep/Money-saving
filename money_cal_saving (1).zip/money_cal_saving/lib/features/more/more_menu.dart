import 'package:flutter/material.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../core/theme/app_theme.dart';
import '../../widgets/widgets.dart';
import '../calendar/calendar_screen.dart';
import '../categories/categories_screen.dart';
import '../members/members_screen.dart';
import '../notifications/notifications_screen.dart';
import '../savings/savings_screen.dart';
import '../settings/settings_screen.dart';
import '../shared/page_kit.dart';

/// ปลายทางของเมนูเพิ่มเติม
enum MenuDestination {
  savings('เป้าหมายออม', '🐷', AppGradients.saving),
  members('สมาชิกครอบครัว', '👨‍👩‍👧', AppGradients.brand),
  notifications('การแจ้งเตือน', '🔔', AppGradients.expense),
  calendar('ปฏิทินการเงิน', '📅', AppGradients.income),
  categories('หมวดหมู่', '🏷️', AppGradients.saving),
  settings('ตั้งค่า', '⚙️', AppGradients.brand);

  const MenuDestination(this.label, this.emoji, this.gradient);

  final String label;
  final String emoji;
  final LinearGradient gradient;
}

/// ตัวสร้างหน้าของแต่ละเมนู (หน้าที่ยังไม่พร้อมแสดง "กำลังมาเร็วๆ นี้")
Widget buildMenuPage(MenuDestination d) {
  switch (d) {
    case MenuDestination.savings:
      return const SavingsScreen();
    case MenuDestination.members:
      return const MembersScreen();
    case MenuDestination.notifications:
      return const NotificationsScreen();
    case MenuDestination.calendar:
      return const CalendarScreen();
    case MenuDestination.categories:
      return const CategoriesScreen();
    case MenuDestination.settings:
      return const SettingsScreen();
  }
}

void openMenuDestination(BuildContext context, MenuDestination d) {
  Navigator.of(context).push(
    MaterialPageRoute<void>(builder: (_) => buildMenuPage(d)),
  );
}

/// ปุ่มเมนูบน AppBar เปิดรายการเมนูเพิ่มเติม
class MoreMenuButton extends StatelessWidget {
  const MoreMenuButton({super.key});

  @override
  Widget build(BuildContext context) {
    return AppBarIconButton(
      icon: PhosphorIconsBold.squaresFour,
      tooltip: 'เมนูเพิ่มเติม',
      onPressed: () => showMoreMenuSheet(context),
    );
  }
}

Future<void> showMoreMenuSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    builder: (ctx) => SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(
        AppSpacing.screenH,
        0,
        AppSpacing.screenH,
        AppSpacing.xxl,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('เมนู', style: Theme.of(ctx).textTheme.titleLarge),
          const SizedBox(height: AppSpacing.md),
          for (final d in MenuDestination.values) ...[
            _MenuTile(
              data: d,
              onTap: () {
                Navigator.of(ctx).pop();
                openMenuDestination(context, d);
              },
            ),
            const SizedBox(height: AppSpacing.sm),
          ],
        ],
      ),
    ),
  );
}

class _MenuTile extends StatelessWidget {
  const _MenuTile({required this.data, required this.onTap});

  final MenuDestination data;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return GlassCard(
      radius: AppRadius.r20,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      onTap: onTap,
      child: ConstrainedBox(
        constraints: const BoxConstraints(minHeight: AppSpacing.minTap),
        child: Row(
          children: [
            EmojiBadge(emoji: data.emoji, gradient: data.gradient, size: 42),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                data.label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: theme.textTheme.titleSmall,
              ),
            ),
            Icon(PhosphorIconsRegular.caretRight,
                size: 18, color: context.palette.inkSoft),
          ],
        ),
      ),
    );
  }
}
