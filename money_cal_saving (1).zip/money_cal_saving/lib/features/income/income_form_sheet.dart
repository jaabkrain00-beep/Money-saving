import 'package:drift/drift.dart' show Value;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/app_dates.dart';
import '../../core/utils/haptics.dart';
import '../../core/utils/money.dart';
import '../../data/db/app_database.dart';
import '../../data/repositories/income_repository.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';
import '../shared/form_kit.dart';

/// เปิดฟอร์มรายรับ
/// - [editing] = null: เพิ่มใหม่ ([startOneTime] เลือกโหมดเริ่มต้น)
/// - [editing] != null: แก้ไขรายการนั้น (ถ้าเป็นรายการประจำ จะถามขอบเขตตอนบันทึก)
Future<void> showIncomeForm(
  BuildContext context, {
  IncomeEntry? editing,
  bool startOneTime = false,
}) {
  return showFormSheet<void>(
    context,
    builder: (_) => IncomeFormSheet(editing: editing, startOneTime: startOneTime),
  );
}

class IncomeFormSheet extends ConsumerStatefulWidget {
  const IncomeFormSheet({super.key, this.editing, this.startOneTime = false});

  final IncomeEntry? editing;
  final bool startOneTime;

  @override
  ConsumerState<IncomeFormSheet> createState() => _IncomeFormSheetState();
}

class _IncomeFormSheetState extends ConsumerState<IncomeFormSheet> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _amount;
  late final TextEditingController _note;

  late bool _oneTime;
  int? _memberId;
  int? _categoryId;
  late int _day;
  late DateTime _date;
  late String _startMonth;
  String? _endMonth;
  bool _saving = false;

  IncomeEntry? get _editing => widget.editing;
  bool get _isEdit => _editing != null;

  @override
  void initState() {
    super.initState();
    final month = ref.read(selectedMonthProvider);
    final e = _editing;
    final today = AppDates.dateOnly(DateTime.now());

    _name = TextEditingController(text: e?.name ?? '');
    _amount = TextEditingController(
      text: e == null ? '' : Money.toInputText(e.amountSatang),
    );
    _note = TextEditingController(text: e?.note ?? '');
    _oneTime = e?.isOneTime ?? widget.startOneTime;
    _memberId = e?.memberId;
    _categoryId = e?.categoryId;

    if (e != null) {
      _day = e.date.day;
      _date = e.date;
      final tpl = e.templateId == null
          ? null
          : ref.read(incomeTemplateMapProvider)[e.templateId!];
      _startMonth = tpl?.startMonth ?? e.monthKey;
      _endMonth = tpl?.endMonth;
      if (tpl != null) _day = tpl.dayOfMonth;
    } else {
      final isCurrent = month == AppDates.monthKey(today);
      _day = isCurrent ? today.day : 25;
      _date = isCurrent ? today : AppDates.dateInMonth(month, 1);
      _startMonth = month;
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!(_formKey.currentState?.validate() ?? false)) {
      Haptics.medium();
      return;
    }
    if (!_oneTime &&
        _endMonth != null &&
        _endMonth!.compareTo(_startMonth) < 0) {
      showAppSnackBar(context, 'เดือนสิ้นสุดต้องไม่ก่อนเดือนเริ่มต้น', emoji: '⚠️');
      return;
    }

    final repo = ref.read(incomeRepositoryProvider);
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);
    final name = _name.text.trim();
    final amount = parseAmountOrZero(_amount.text);
    final note = _note.text.trim();

    setState(() => _saving = true);
    try {
      final e = _editing;
      if (e == null) {
        if (_oneTime) {
          await repo.addOneTime(
            name: name,
            amountSatang: amount,
            date: _date,
            memberId: _memberId,
            categoryId: _categoryId,
            note: note,
          );
        } else {
          await repo.addTemplate(
            IncomeTemplateInput(
              name: name,
              amountSatang: amount,
              dayOfMonth: _day,
              startMonth: _startMonth,
              endMonth: _endMonth,
              memberId: _memberId,
              categoryId: _categoryId,
              note: note,
            ),
          );
        }
      } else if (e.templateId == null) {
        // รายรับพิเศษ/ยกยอด แก้ตรงๆ
        await repo.updateEntry(
          e.copyWith(
            name: name,
            amountSatang: amount,
            date: _date,
            memberId: Value(_memberId),
            categoryId: Value(_categoryId),
            note: note,
          ),
        );
      } else {
        final scope = await showEditScopeDialog(context);
        if (scope == null) {
          if (mounted) setState(() => _saving = false);
          return;
        }
        if (scope == EditScope.thisMonthOnly) {
          await repo.updateEntry(
            e.copyWith(
              name: name,
              amountSatang: amount,
              date: AppDates.dateInMonth(e.monthKey, _day),
              memberId: Value(_memberId),
              categoryId: Value(_categoryId),
              note: note,
            ),
          );
        } else {
          final tpl = ref.read(incomeTemplateMapProvider)[e.templateId!];
          if (tpl == null) {
            throw StateError('ไม่พบแม่แบบรายรับ');
          }
          await repo.updateTemplateFromMonth(
            original: tpl,
            input: IncomeTemplateInput(
              name: name,
              amountSatang: amount,
              dayOfMonth: _day,
              startMonth: tpl.startMonth,
              endMonth: _endMonth,
              memberId: _memberId,
              categoryId: _categoryId,
              note: note,
            ),
            fromMonth: e.monthKey,
          );
        }
      }
      Haptics.light();
      navigator.pop();
      showAppSnackBarOn(messenger, 'บันทึกรายรับแล้ว', emoji: '💰');
    } catch (err) {
      if (mounted) setState(() => _saving = false);
      showAppSnackBarOn(messenger, 'บันทึกไม่สำเร็จ ลองใหม่อีกครั้ง', emoji: '😢');
    }
  }

  @override
  Widget build(BuildContext context) {
    final categories = ref.watch(incomeCategoriesProvider);
    final isInstance = _isEdit && _editing!.templateId != null;

    return Form(
      key: _formKey,
      child: FormSheetScaffold(
        emoji: '💰',
        title: _isEdit ? 'แก้ไขรายรับ' : 'เพิ่มรายรับ',
        gradient: AppGradients.income,
        saving: _saving,
        onSave: _save,
        children: [
          if (!_isEdit) ...[
            SegmentSwitch(
              labels: const ['ประจำทุกเดือน', 'พิเศษ (ครั้งเดียว)'],
              index: _oneTime ? 1 : 0,
              gradient: AppGradients.income,
              onChanged: (i) => setState(() => _oneTime = i == 1),
            ),
          ],
          const FieldLabel('ชื่อรายการ'),
          NameField(
            controller: _name,
            hint: _oneTime ? 'เช่น โบนัส, ขายของ' : 'เช่น เงินเดือน, ค่าเช่า',
          ),
          const FieldLabel('จำนวนเงิน (บาท)'),
          AmountField(controller: _amount),
          const FieldLabel('ของใคร'),
          MemberChips(
            selectedId: _memberId,
            onChanged: (id) => setState(() => _memberId = id),
          ),
          const FieldLabel('หมวดหมู่'),
          CategoryChips(
            categories: categories,
            selectedId: _categoryId,
            onChanged: (id) => setState(() => _categoryId = id),
          ),
          if (_oneTime || (_isEdit && _editing!.templateId == null)) ...[
            const FieldLabel('วันที่ได้รับ'),
            DateField(
              value: _date,
              onChanged: (d) => setState(() => _date = d),
            ),
          ] else ...[
            const FieldLabel('วันที่เงินเข้า'),
            DayOfMonthField(
              value: _day,
              onChanged: (d) => setState(() => _day = d),
            ),
            if (!_isEdit) ...[
              const FieldLabel('เริ่มตั้งแต่เดือน'),
              MonthKeyField(
                value: _startMonth,
                onChanged: (m) => setState(() => _startMonth = m),
              ),
            ],
            FieldLabel(isInstance ? 'สิ้นสุดเดือน (เมื่อเลือก "เป็นต้นไป")' : 'สิ้นสุดเดือน (ไม่บังคับ)'),
            MonthKeyField(
              value: _endMonth,
              placeholder: 'ไม่มีกำหนดสิ้นสุด',
              minKey: _startMonth,
              onChanged: (m) => setState(() => _endMonth = m),
              onCleared: () => setState(() => _endMonth = null),
            ),
          ],
          const FieldLabel('หมายเหตุ'),
          NoteField(controller: _note),
          const SizedBox(height: AppSpacing.sm),
        ],
      ),
    );
  }
}
