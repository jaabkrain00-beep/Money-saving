import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/app_dates.dart';
import '../../core/utils/haptics.dart';
import '../../core/utils/labels.dart';
import '../../core/utils/money.dart';
import '../../data/db/app_database.dart';
import '../../domain/status_rules.dart';
import '../../providers/providers.dart';
import '../../widgets/widgets.dart';
import '../more/more_menu.dart';
import '../shared/detail_sheet.dart';
import '../shared/entry_card.dart';
import 'income_form_sheet.dart';

/// หน้ารายรับ: สรุปเดือน + รายการ (ปัดซ้ายแก้ไข/ลบ, แตะดูรายละเอียด)
class IncomeScreen extends ConsumerStatefulWidget {
  const IncomeScreen({super.key});

  @override
  ConsumerState<IncomeScreen> createState() => _IncomeScreenState();
}

class _IncomeScreenState extends ConsumerState<IncomeScreen> {
  int? _memberFilter;

  @override
  Widget build(BuildContext context) {
    final ready = ref.watch(monthReadyProvider);
    final month = ref.watch(selectedMonthProvider);
    final all = ref.watch(monthIncomeProvider);
    final members = ref.watch(membersProvider).valueOrNull ?? const <Member>[];
    final memberMap = ref.watch(memberMapProvider);
    final categoryMap = ref.watch(categoryMapProvider);
    final today = AppDates.dateOnly(DateTime.now());

    // ถ้าสมาชิกที่กรองอยู่ถูกลบ ให้กลับไปแสดงทั้งหมด
    final filterId =
        (_memberFilter != null && memberMap.containsKey(_memberFilter))
            ? _memberFilter
            : null;
    final list = filterId == null
        ? all
        : [for (final e in all) if (e.memberId == filterId) e];

    final total = list.fold<int>(0, (s, e) => s + e.amountSatang);
    final received = list
        .where((e) => e.isReceived)
        .fold<int>(0, (s, e) => s + e.amountSatang);

    return MonthSwipe(
      child: CustomScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        slivers: [
          PastelSliverAppBar(
            title: 'รายรับ',
            actions: [
              IconButton(
                tooltip: 'เพิ่มรายรับ',
                constraints: const BoxConstraints(
                  minWidth: AppSpacing.minTap,
                  minHeight: AppSpacing.minTap,
                ),
                icon: const Icon(PhosphorIconsBold.plusCircle),
                onPressed: () => showIncomeForm(context),
              ),
              const MoreMenuButton(),
            ],
          ),
          const SliverToBoxAdapter(child: MonthSelector()),
          SliverToBoxAdapter(
            child: _SummaryCard(
              total: total,
              received: received,
              count: list.length,
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.only(top: AppSpacing.sm),
              child: MemberFilterBar(
                members: members,
                selectedId: filterId,
                onChanged: (id) => setState(() => _memberFilter = id),
              ),
            ),
          ),
          if (!ready)
            const SliverFillRemaining(
              hasScrollBody: false,
              child: Center(child: CircularProgressIndicator()),
            )
          else if (list.isEmpty)
            SliverFillRemaining(
              hasScrollBody: false,
              child: Padding(
                padding:
                    const EdgeInsets.only(bottom: AppSpacing.navBarClearance),
                child: EmptyState(
                  emoji: '🌱',
                  title: filterId == null
                      ? 'ยังไม่มีรายรับเดือนนี้'
                      : 'ยังไม่มีรายรับของคนนี้',
                  message: 'เพิ่มเงินเดือนหรือรายได้อื่นๆ เพื่อเริ่มวางแผนการเงินของครอบครัว',
                  actionLabel: 'เพิ่มรายรับ',
                  gradient: AppGradients.income,
                  onAction: () => showIncomeForm(context),
                ),
              ),
            )
          else ...[
            SliverPadding(
              padding: const EdgeInsets.only(top: AppSpacing.sm),
              sliver: SliverList.builder(
                itemCount: list.length,
                itemBuilder: (context, i) {
                  final e = list[i];
                  return _IncomeCard(
                    key: ValueKey('income-${e.id}'),
                    entry: e,
                    index: i,
                    member: memberMap[e.memberId],
                    category: categoryMap[e.categoryId],
                    today: today,
                    buddhist: ref.watch(useBuddhistYearProvider),
                  );
                },
              ),
            ),
            const SliverToBoxAdapter(
              child: SizedBox(height: AppSpacing.navBarClearance),
            ),
          ],
        ],
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.total,
    required this.received,
    required this.count,
  });

  final int total;
  final int received;
  final int count;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final pending = total - received;

    Widget stat(String label, int satang) => Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: theme.textTheme.bodySmall,
              ),
              AmountText(
                satang,
                animate: true,
                style: theme.textTheme.titleMedium,
              ),
            ],
          ),
        );

    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.screenH,
        vertical: AppSpacing.sm,
      ),
      child: GradientCard(
        gradient: AppGradients.income,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'รายรับรวมเดือนนี้ · $count รายการ',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodyMedium,
            ),
            const SizedBox(height: 4),
            AmountText(
              total,
              animate: true,
              style: theme.textTheme.headlineMedium,
            ),
            const SizedBox(height: AppSpacing.md),
            Row(
              children: [
                stat('ได้รับแล้ว', received),
                const SizedBox(width: AppSpacing.md),
                stat('รอเงินเข้า', pending),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _IncomeCard extends ConsumerWidget {
  const _IncomeCard({
    super.key,
    required this.entry,
    required this.index,
    required this.member,
    required this.category,
    required this.today,
    required this.buddhist,
  });

  final IncomeEntry entry;
  final int index;
  final Member? member;
  final Category? category;
  final DateTime today;
  final bool buddhist;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final e = entry;
    final dueNow = IncomeRules.needsConfirmation(
      isReceived: e.isReceived,
      date: e.date,
      today: today,
    );

    final chips = <Widget>[
      e.isReceived ? const StatusChip.received() : const StatusChip.waiting(),
      if (e.templateId != null)
        const InfoChip(text: 'ประจำ', emoji: '🔁')
      else
        const InfoChip(text: 'พิเศษ', emoji: '✨'),
      InfoChip(
        text: memberLabel(member),
        emoji: memberEmoji(member),
        color: member == null ? null : Color(member!.color),
      ),
    ];

    return EntryCard(
      slidableKey: ValueKey('slide-income-${e.id}'),
      index: index,
      emoji: category?.icon ?? '💰',
      color: Color(category?.color ?? AppColors.incomeA.toARGB32()),
      title: e.name,
      subtitle: '${AppDates.formatDayMonth(e.date, buddhist: buddhist)}'
          '${category == null ? '' : ' · ${category!.name}'}',
      amountSatang: e.amountSatang,
      amountColor: AppColors.successInk,
      chips: chips,
      trailingAction: e.isReceived
          ? null
          : MiniActionButton(
              label: dueNow ? 'ได้รับแล้ว' : 'รับล่วงหน้า',
              icon: PhosphorIconsBold.check,
              onTap: () => _setReceived(context, ref, true),
            ),
      onTap: () => _showDetail(context, ref),
      swipeActions: [
        CardSwipeAction(
          label: 'แก้ไข',
          icon: PhosphorIconsBold.pencilSimple,
          gradient: AppGradients.brand,
          onTap: () => showIncomeForm(context, editing: e),
        ),
        CardSwipeAction(
          label: 'ลบ',
          icon: PhosphorIconsBold.trash,
          gradient: AppGradients.expense,
          onTap: () => deleteIncomeWithUndo(context, ref, e),
        ),
      ],
    );
  }

  Future<void> _setReceived(
    BuildContext context,
    WidgetRef ref,
    bool value,
  ) async {
    Haptics.medium();
    final messenger = ScaffoldMessenger.of(context);
    final repo = ref.read(incomeRepositoryProvider);
    await repo.setReceived(entry.id, value);
    if (value) {
      showUndoSnackBarOn(
        messenger,
        message: 'บันทึกว่าได้รับ "${entry.name}" แล้ว 🎉',
        onUndo: () => repo.setReceived(entry.id, false),
      );
    }
  }

  void _showDetail(BuildContext context, WidgetRef ref) {
    final e = entry;
    final tpl = e.templateId == null
        ? null
        : ref.read(incomeTemplateMapProvider)[e.templateId!];

    showEntryDetailSheet(
      context,
      emoji: category?.icon ?? '💰',
      color: Color(category?.color ?? AppColors.incomeA.toARGB32()),
      title: e.name,
      amountSatang: e.amountSatang,
      note: e.note,
      chips: [
        e.isReceived ? const StatusChip.received() : const StatusChip.waiting(),
      ],
      rows: [
        DetailRowData('สมาชิก', memberLabel(member)),
        DetailRowData('หมวดหมู่', category?.name ?? 'ไม่ระบุ'),
        DetailRowData(
          'วันที่เงินเข้า',
          AppDates.formatDayMonth(e.date, withYear: true, buddhist: buddhist),
        ),
        DetailRowData(
          'ประเภท',
          e.templateId != null ? 'รายรับประจำทุกเดือน' : 'รายรับพิเศษ (ครั้งเดียว)',
        ),
        if (tpl != null)
          DetailRowData(
            'ช่วงเวลา',
            '${AppDates.formatShortMonthYear(tpl.startMonth, buddhist: buddhist)}'
            ' – ${tpl.endMonth == null ? 'ไม่มีกำหนด' : AppDates.formatShortMonthYear(tpl.endMonth!, buddhist: buddhist)}',
          ),
        DetailRowData('จำนวน', '฿ ${Money.format(e.amountSatang)}'),
      ],
      actions: [
        if (e.isReceived)
          DetailAction(
            label: 'ยกเลิกการรับเงิน',
            icon: PhosphorIconsBold.arrowUUpLeft,
            gradient: AppGradients.saving,
            onTap: () => _setReceived(context, ref, false),
          )
        else
          DetailAction(
            label: 'ได้รับเงินแล้ว',
            icon: PhosphorIconsBold.check,
            gradient: AppGradients.income,
            onTap: () => _setReceived(context, ref, true),
          ),
        DetailAction(
          label: 'แก้ไข',
          icon: PhosphorIconsBold.pencilSimple,
          onTap: () => showIncomeForm(context, editing: e),
        ),
        DetailAction(
          label: 'ลบ',
          icon: PhosphorIconsBold.trash,
          gradient: AppGradients.expense,
          onTap: () => deleteIncomeWithUndo(context, ref, e),
        ),
      ],
    );
  }
}

/// ลบรายรับ: ยืนยัน (และถามขอบเขตถ้าเป็นรายการประจำ) แล้วแสดง Undo
Future<void> deleteIncomeWithUndo(
  BuildContext context,
  WidgetRef ref,
  IncomeEntry entry,
) async {
  final repo = ref.read(incomeRepositoryProvider);
  final messenger = ScaffoldMessenger.of(context);

  if (entry.templateId == null) {
    final ok = await showConfirmDialog(
      context,
      title: 'ลบ "${entry.name}" ?',
      message: 'รายการนี้จะถูกลบออกจากเดือนนี้',
      confirmLabel: 'ลบ',
      destructive: true,
    );
    if (!ok) return;
    await repo.deleteEntry(entry);
    Haptics.medium();
    showUndoSnackBarOn(
      messenger,
      message: 'ลบ "${entry.name}" แล้ว',
      onUndo: () => repo.restoreEntry(entry),
    );
    return;
  }

  final scope = await showEditScopeDialog(
    context,
    title: 'ลบ "${entry.name}" แบบไหน?',
    message: 'รายการนี้เป็นรายรับประจำ เลือกขอบเขตที่จะลบ',
  );
  if (scope == null) return;

  Haptics.medium();
  if (scope == EditScope.thisMonthOnly) {
    await repo.deleteEntry(entry);
    showUndoSnackBarOn(
      messenger,
      message: 'ลบ "${entry.name}" เฉพาะเดือนนี้แล้ว',
      onUndo: () => repo.restoreEntry(entry),
    );
  } else {
    final tpl = ref.read(incomeTemplateMapProvider)[entry.templateId!];
    if (tpl == null) return;
    final snapshot = await repo.deleteTemplateFromMonth(tpl, entry.monthKey);
    showUndoSnackBarOn(
      messenger,
      message: 'ลบ "${entry.name}" ตั้งแต่เดือนนี้เป็นต้นไปแล้ว',
      onUndo: () => repo.restoreTemplate(snapshot),
    );
  }
}
