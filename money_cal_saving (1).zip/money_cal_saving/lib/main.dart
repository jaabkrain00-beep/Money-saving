import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'app.dart';
import 'data/db/app_database.dart';
import 'data/repositories/settings_repository.dart';
import 'providers/providers.dart';

/// สร้างแอปด้วย --dart-define=BUNDLED_FONTS=true เมื่อวางไฟล์ฟอนต์ไว้ใน assets/google_fonts/ แล้ว
/// (ปิดการดาวน์โหลดฟอนต์ ใช้งานออฟไลน์ 100%) ค่าเริ่มต้นคือดาวน์โหลดครั้งแรกแล้วแคช
const bool kBundledFonts = bool.fromEnvironment('BUNDLED_FONTS');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  GoogleFonts.config.allowRuntimeFetching = !kBundledFonts;

  // ล็อกแนวตั้งเท่านั้น
  await SystemChrome.setPreferredOrientations(const [
    DeviceOrientation.portraitUp,
  ]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

  await initializeDateFormatting('th_TH');

  // โหลดการตั้งค่าก่อนวาดหน้าจอแรก เพื่อไม่ให้ธีม/รูปแบบปีกะพริบ
  final db = AppDatabase();
  SettingsState settings;
  try {
    settings = await SettingsRepository(db).load();
  } catch (e, st) {
    debugPrint('โหลดการตั้งค่าไม่สำเร็จ: $e\n$st');
    settings = SettingsState.defaults;
  }

  runApp(
    ProviderScope(
      overrides: [
        databaseProvider.overrideWithValue(db),
        initialSettingsProvider.overrideWithValue(settings),
      ],
      child: const MoneyCalApp(),
    ),
  );
}
