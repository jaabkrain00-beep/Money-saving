import 'package:flutter/material.dart';

import '../db/app_database.dart';
import '../db/daos/settings_dao.dart';
import '../settings_keys.dart';

/// การตั้งค่าแอปแบบมีชนิดข้อมูล (แปลงจากตาราง settings ซึ่งเก็บเป็นข้อความ)
class SettingsState {
  const SettingsState({
    this.themeMode = ThemeMode.system,
    this.buddhistYear = true,
    this.carryOver = false,
    this.remindDaysBefore = 1,
    this.remindTime = '09:00',
    this.notifyPayday = true,
    this.notifyExpense = true,
    this.biometric = false,
    this.hasPin = false,
  });

  static const SettingsState defaults = SettingsState();

  /// ค่าที่เลือกได้สำหรับเตือนล่วงหน้า (วัน)
  static const List<int> remindDayOptions = [0, 1, 3, 7];

  final ThemeMode themeMode;

  /// แสดงปีเป็น พ.ศ. (ค่าเริ่มต้น) หรือ ค.ศ.
  final bool buddhistYear;

  /// ยกยอดคงเหลือไปเดือนถัดไป (ค่าเริ่มต้นปิด)
  final bool carryOver;
  final int remindDaysBefore;

  /// "HH:mm"
  final String remindTime;
  final bool notifyPayday;
  final bool notifyExpense;
  final bool biometric;
  final bool hasPin;

  int get remindHour => int.tryParse(remindTime.split(':').first) ?? 9;
  int get remindMinute => int.tryParse(remindTime.split(':').last) ?? 0;

  factory SettingsState.fromMap(Map<String, String> m) {
    bool flag(String key, bool fallback) {
      final v = m[key];
      if (v == null) return fallback;
      return v == 'true';
    }

    ThemeMode mode() {
      switch (m[SettingKeys.themeMode]) {
        case 'light':
          return ThemeMode.light;
        case 'dark':
          return ThemeMode.dark;
        default:
          return ThemeMode.system;
      }
    }

    int days() {
      final v = int.tryParse(m[SettingKeys.remindDaysBefore] ?? '');
      return (v != null && remindDayOptions.contains(v)) ? v : 1;
    }

    String time() {
      final v = m[SettingKeys.remindTime];
      if (v == null || !RegExp(r'^\d{2}:\d{2}$').hasMatch(v)) return '09:00';
      return v;
    }

    return SettingsState(
      themeMode: mode(),
      buddhistYear: flag(SettingKeys.buddhistYear, true),
      carryOver: flag(SettingKeys.carryOver, false),
      remindDaysBefore: days(),
      remindTime: time(),
      notifyPayday: flag(SettingKeys.notifyPayday, true),
      notifyExpense: flag(SettingKeys.notifyExpense, true),
      biometric: flag(SettingKeys.biometric, false),
      hasPin: (m[SettingKeys.pinHash] ?? '').isNotEmpty,
    );
  }
}

class SettingsRepository {
  SettingsRepository(AppDatabase db) : _dao = db.settingsDao;

  final SettingsDao _dao;

  Stream<SettingsState> watch() => _dao.watchAll().map(SettingsState.fromMap);
  Future<SettingsState> load() async =>
      SettingsState.fromMap(await _dao.getAll());

  Future<String?> getString(String key) => _dao.get(key);
  Future<void> setString(String key, String value) => _dao.put(key, value);
  Future<void> remove(String key) async {
    await _dao.remove(key);
  }

  Future<void> setBool(String key, bool value) =>
      _dao.put(key, value ? 'true' : 'false');

  Future<void> setThemeMode(ThemeMode mode) => _dao.put(
        SettingKeys.themeMode,
        switch (mode) {
          ThemeMode.light => 'light',
          ThemeMode.dark => 'dark',
          ThemeMode.system => 'system',
        },
      );

  Future<void> setRemindDays(int days) =>
      _dao.put(SettingKeys.remindDaysBefore, '$days');

  Future<void> setRemindTime(String hhmm) =>
      _dao.put(SettingKeys.remindTime, hhmm);
}
