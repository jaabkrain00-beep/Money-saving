import 'package:drift/drift.dart';

import '../../core/utils/app_dates.dart';
import '../../domain/goal_calculator.dart';
import '../db/app_database.dart';
import '../db/daos/savings_dao.dart';

class GoalInput {
  const GoalInput({
    required this.name,
    required this.targetSatang,
    required this.color,
    this.targetDate,
    this.emoji = '🎯',
    this.memberId,
  });

  final String name;
  final int targetSatang;

  /// สี ARGB
  final int color;
  final DateTime? targetDate;
  final String emoji;
  final int? memberId;
}

/// ภาพสถานะก่อนลบเป้าหมาย ใช้ทำ Undo
class GoalSnapshot {
  const GoalSnapshot(this.goal, this.transactions);

  final SavingGoal goal;
  final List<SavingTransaction> transactions;
}

/// ผลหลังบันทึกรายการฝาก/ถอน
class TxResult {
  const TxResult({required this.balance, required this.justCompleted});

  /// ยอดออมสุทธิของเป้าหมายหลังบันทึก
  final int balance;

  /// เพิ่งออมครบเป้าหมายจากรายการนี้ (ให้แสดง confetti)
  final bool justCompleted;
}

/// ถอนเกินยอดที่ออมไว้
class InsufficientSavingsException implements Exception {
  const InsufficientSavingsException(this.balance);

  final int balance;

  @override
  String toString() => 'InsufficientSavingsException(balance: $balance)';
}

class SavingsRepository {
  SavingsRepository(this._db) : _dao = _db.savingsDao;

  final AppDatabase _db;
  final SavingsDao _dao;

  // ---------- อ่าน ----------

  Stream<List<SavingGoal>> watchGoals() => _dao.watchGoals();
  Stream<List<SavingTransaction>> watchAllTransactions() =>
      _dao.watchAllTransactions();
  Stream<List<SavingTransaction>> watchTransactions(int goalId) =>
      _dao.watchTransactions(goalId);

  Future<int> balanceOf(int goalId) async =>
      GoalCalculator.balance(await _dao.getTransactions(goalId));

  // ---------- เป้าหมาย ----------

  Future<int> addGoal(GoalInput input) {
    return _dao.insertGoal(
      SavingGoalsCompanion.insert(
        name: input.name,
        targetSatang: input.targetSatang,
        targetDate: Value(input.targetDate),
        emoji: Value(input.emoji),
        color: input.color,
        memberId: Value(input.memberId),
      ),
    );
  }

  /// แก้เป้าหมาย (เปลี่ยนยอดเป้าหมายอาจทำให้สถานะ "สำเร็จ" เปลี่ยน จึงตรวจใหม่)
  Future<TxResult> updateGoal(SavingGoal goal) async {
    await _dao.updateGoal(goal);
    return reconcile(goal.id);
  }

  Future<GoalSnapshot> deleteGoal(SavingGoal goal) {
    return _db.transaction(() async {
      final txs = await _dao.getTransactions(goal.id);
      final snapshot = GoalSnapshot(goal, txs);
      await _dao.deleteGoal(goal.id);
      return snapshot;
    });
  }

  Future<void> restoreGoal(GoalSnapshot snapshot) {
    return _db.transaction(() async {
      await _dao.upsertGoal(snapshot.goal);
      for (final t in snapshot.transactions) {
        await _dao.upsertTransaction(t);
      }
    });
  }

  // ---------- ฝาก / ถอน ----------

  /// บันทึกฝากหรือถอน
  /// ถอนเกินยอดที่มี -> throw [InsufficientSavingsException]
  Future<TxResult> addTransaction({
    required int goalId,
    required int amountSatang,
    required SavingTxType type,
    required DateTime date,
    String note = '',
  }) {
    return _db.transaction(() async {
      if (type == SavingTxType.withdraw) {
        final balance = await balanceOf(goalId);
        if (amountSatang > balance) throw InsufficientSavingsException(balance);
      }
      final day = AppDates.dateOnly(date);
      await _dao.insertTransaction(
        SavingTransactionsCompanion.insert(
          goalId: goalId,
          amountSatang: amountSatang,
          type: type,
          date: day,
          monthKey: AppDates.monthKey(day),
          note: Value(note),
        ),
      );
      return reconcile(goalId);
    });
  }

  Future<TxResult> updateTransaction(SavingTransaction row) {
    return _db.transaction(() async {
      final others = (await _dao.getTransactions(row.goalId))
          .where((t) => t.id != row.id)
          .toList();
      final fixed = row.copyWith(monthKey: AppDates.monthKey(row.date));
      final newBalance = GoalCalculator.balance([...others, fixed]);
      if (newBalance < 0) {
        throw InsufficientSavingsException(GoalCalculator.balance(others));
      }
      await _dao.updateTransaction(fixed);
      return reconcile(row.goalId);
    });
  }

  Future<TxResult> deleteTransaction(SavingTransaction row) {
    return _db.transaction(() async {
      await _dao.deleteTransaction(row.id);
      return reconcile(row.goalId);
    });
  }

  Future<TxResult> restoreTransaction(SavingTransaction row) {
    return _db.transaction(() async {
      await _dao.upsertTransaction(row);
      return reconcile(row.goalId);
    });
  }

  /// ตรวจสถานะ "สำเร็จแล้ว" ของเป้าหมายตามยอดออมปัจจุบัน
  /// - ครบเป้าหมาย -> ตั้งเป็นสำเร็จ (justCompleted = true ครั้งแรกที่ครบ)
  /// - ถอนจนต่ำกว่าเป้าหมาย -> กลับเป็นยังไม่สำเร็จ
  Future<TxResult> reconcile(int goalId) async {
    final goal = await _dao.getGoal(goalId);
    final balance = await balanceOf(goalId);
    if (goal == null) return TxResult(balance: balance, justCompleted: false);

    final should = GoalCalculator.shouldBeCompleted(
      saved: balance,
      target: goal.targetSatang,
    );
    final justCompleted = should && !goal.isCompleted;
    if (should != goal.isCompleted) {
      await _dao.setCompleted(goalId, should);
    }
    return TxResult(balance: balance, justCompleted: justCompleted);
  }
}
