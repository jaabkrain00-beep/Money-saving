import 'package:drift/drift.dart';

import '../db/app_database.dart';
import '../db/daos/members_dao.dart';

class CategoryInput {
  const CategoryInput({
    required this.name,
    required this.type,
    required this.color,
    this.icon = '✨',
  });

  final String name;
  final CategoryType type;
  final String icon;

  /// สี ARGB
  final int color;
}

/// ภาพสถานะก่อนลบหมวดหมู่ ใช้ทำ Undo (จำว่ารายการไหนเคยใช้หมวดนี้)
class CategorySnapshot {
  const CategorySnapshot({
    required this.category,
    required this.incomeTemplateIds,
    required this.incomeEntryIds,
    required this.expenseTemplateIds,
    required this.expenseEntryIds,
  });

  final Category category;
  final List<int> incomeTemplateIds;
  final List<int> incomeEntryIds;
  final List<int> expenseTemplateIds;
  final List<int> expenseEntryIds;

  int get usageCount =>
      incomeTemplateIds.length +
      incomeEntryIds.length +
      expenseTemplateIds.length +
      expenseEntryIds.length;
}

class CategoriesRepository {
  CategoriesRepository(this._db) : _dao = _db.membersDao;

  final AppDatabase _db;
  final MembersDao _dao;

  Stream<List<Category>> watchCategories() => _dao.watchCategories();

  Future<int> addCategory(CategoryInput input) async {
    final all = await _dao.getCategories();
    final nextOrder = all.isEmpty
        ? 0
        : all.map((c) => c.sortOrder).reduce((a, b) => a > b ? a : b) + 1;
    return _dao.insertCategory(
      CategoriesCompanion.insert(
        name: input.name,
        type: input.type,
        color: input.color,
        icon: Value(input.icon),
        sortOrder: Value(nextOrder),
      ),
    );
  }

  Future<void> updateCategory(Category row) async {
    await _dao.updateCategory(row);
  }

  Future<void> reorder(List<int> orderedIds) => _dao.reorderCategories(orderedIds);

  /// จำนวนรายการที่ใช้หมวดนี้อยู่ (ใช้เตือนก่อนลบ)
  Future<int> usageCount(int categoryId) async =>
      (await _capture(categoryId)).usageCount;

  /// ลบหมวดหมู่ — รายการที่ใช้อยู่จะกลายเป็น "ไม่มีหมวด" คืน snapshot สำหรับ Undo
  Future<CategorySnapshot> deleteCategory(int categoryId) {
    return _db.transaction(() async {
      final snapshot = await _capture(categoryId);
      await _dao.deleteCategory(categoryId);
      return snapshot;
    });
  }

  Future<void> restoreCategory(CategorySnapshot s) {
    return _db.transaction(() async {
      await _dao.upsertCategory(s.category);
      final id = s.category.id;
      if (s.incomeTemplateIds.isNotEmpty) {
        await (_db.update(_db.incomeTemplates)
              ..where((t) => t.id.isIn(s.incomeTemplateIds)))
            .write(IncomeTemplatesCompanion(categoryId: Value(id)));
      }
      if (s.incomeEntryIds.isNotEmpty) {
        await (_db.update(_db.incomeEntries)
              ..where((t) => t.id.isIn(s.incomeEntryIds)))
            .write(IncomeEntriesCompanion(categoryId: Value(id)));
      }
      if (s.expenseTemplateIds.isNotEmpty) {
        await (_db.update(_db.expenseTemplates)
              ..where((t) => t.id.isIn(s.expenseTemplateIds)))
            .write(ExpenseTemplatesCompanion(categoryId: Value(id)));
      }
      if (s.expenseEntryIds.isNotEmpty) {
        await (_db.update(_db.expenseEntries)
              ..where((t) => t.id.isIn(s.expenseEntryIds)))
            .write(ExpenseEntriesCompanion(categoryId: Value(id)));
      }
    });
  }

  Future<CategorySnapshot> _capture(int categoryId) async {
    final category = await (_db.select(_db.categories)
          ..where((c) => c.id.equals(categoryId)))
        .getSingle();

    Future<List<int>> ids<T extends Table, D>(
      TableInfo<T, D> table,
      GeneratedColumn<int> idCol,
      GeneratedColumn<int> categoryCol,
    ) {
      final query = _db.selectOnly(table)
        ..addColumns([idCol])
        ..where(categoryCol.equals(categoryId));
      return query.map((row) => row.read(idCol)!).get();
    }

    return CategorySnapshot(
      category: category,
      incomeTemplateIds: await ids(
        _db.incomeTemplates,
        _db.incomeTemplates.id,
        _db.incomeTemplates.categoryId,
      ),
      incomeEntryIds: await ids(
        _db.incomeEntries,
        _db.incomeEntries.id,
        _db.incomeEntries.categoryId,
      ),
      expenseTemplateIds: await ids(
        _db.expenseTemplates,
        _db.expenseTemplates.id,
        _db.expenseTemplates.categoryId,
      ),
      expenseEntryIds: await ids(
        _db.expenseEntries,
        _db.expenseEntries.id,
        _db.expenseEntries.categoryId,
      ),
    );
  }
}
