import 'package:drift/drift.dart';

import '../../core/utils/app_dates.dart';
import '../../domain/monthly_generator.dart';
import '../../domain/template_rules.dart';
import '../db/app_database.dart';
import '../db/daos/expense_dao.dart';

/// ข้อมูลสำหรับสร้าง/แก้แม่แบบรายจ่ายประจำ
class ExpenseTemplateInput {
  const ExpenseTemplateInput({
    required this.name,
    required this.amountSatang,
    required this.dueDay,
    required this.startMonth,
    this.memberId,
    this.categoryId,
    this.endMonth,
    this.totalInstallments,
    this.remindDaysBefore,
    this.remindTime,
    this.note = '',
  });

  final String name;
  final int amountSatang;
  final int? memberId;
  final int dueDay;
  final int? categoryId;
  final String startMonth;
  final String? endMonth;
  final int? totalInstallments;

  /// null = ใช้ค่ารวมของแอป
  final int? remindDaysBefore;

  /// "HH:mm" หรือ null = ใช้ค่ารวมของแอป
  final String? remindTime;
  final String note;
}

/// ภาพสถานะก่อนลบ/ปิดยอดแม่แบบ ใช้ทำ Undo
class ExpenseTemplateSnapshot {
  const ExpenseTemplateSnapshot(this.template, this.entries);

  final ExpenseTemplate template;
  final List<ExpenseEntry> entries;
}

class ExpenseRepository {
  ExpenseRepository(this._db) : _dao = _db.expenseDao;

  final AppDatabase _db;
  final ExpenseDao _dao;

  static const int maxEnsureMonths = 600;
  static const int maxHistoryMonths = 24;

  // ---------- อ่าน ----------

  Stream<List<ExpenseTemplate>> watchTemplates() => _dao.watchTemplates();
  Stream<List<ExpenseEntry>> watchAll() => _dao.watchAll();
  Stream<List<ExpenseEntry>> watchUnpaid() => _dao.watchUnpaid();
  Future<List<ExpenseEntry>> getUnpaid() => _dao.getUnpaid();
  Future<List<ExpenseTemplate>> getTemplates() => _dao.getTemplates();

  // ---------- สร้างรายการรายเดือนจากแม่แบบ ----------

  Future<void> ensureMonth(String monthKey) => ensureRange(monthKey, monthKey);

  /// สร้าง instance ของทุกเดือนในช่วง [fromKey]..[toKey] จากแม่แบบที่ active
  /// สถานะเริ่มต้น "ยังไม่จ่าย" เสมอ ปลอดภัยที่จะเรียกซ้ำ
  Future<void> ensureRange(String fromKey, String toKey) async {
    final templates = await _dao.getTemplates();
    await _ensureFor(templates, fromKey, toKey);
  }

  Future<void> _ensureFor(
    List<ExpenseTemplate> templates,
    String fromKey,
    String toKey,
  ) async {
    if (templates.isEmpty || toKey.compareTo(fromKey) < 0) return;
    var from = fromKey;
    if (AppDates.monthsBetween(from, toKey) > maxEnsureMonths) {
      from = AppDates.addMonths(toKey, -maxEnsureMonths);
    }

    final existing = await _dao.getRange(from, toKey);
    final byMonth = <String, Set<int>>{};
    for (final e in existing) {
      final id = e.templateId;
      if (id != null) (byMonth[e.monthKey] ??= <int>{}).add(id);
    }

    final toCreate = <ExpenseEntriesCompanion>[];
    for (final m in AppDates.monthRange(from, toKey)) {
      toCreate.addAll(
        MonthlyGenerator.expenseToCreate(
          monthKey: m,
          templates: templates,
          existingTemplateIds: byMonth[m] ?? const <int>{},
        ),
      );
    }
    await _dao.insertEntriesIgnoreDuplicates(toCreate);
  }

  Future<String?> earliestMonth() async {
    String? best;
    for (final t in await _dao.getTemplates()) {
      if (best == null || t.startMonth.compareTo(best) < 0) best = t.startMonth;
    }
    for (final e in await _dao.getAllEntries()) {
      if (best == null || e.monthKey.compareTo(best) < 0) best = e.monthKey;
    }
    return best;
  }

  // ---------- เพิ่ม ----------

  Future<int> addTemplate(ExpenseTemplateInput input) {
    return _dao.insertTemplate(
      ExpenseTemplatesCompanion.insert(
        name: input.name,
        amountSatang: input.amountSatang,
        memberId: Value(input.memberId),
        dueDay: input.dueDay,
        categoryId: Value(input.categoryId),
        startMonth: input.startMonth,
        endMonth: Value(input.endMonth),
        totalInstallments: Value(input.totalInstallments),
        remindDaysBefore: Value(input.remindDaysBefore),
        remindTime: Value(input.remindTime),
        note: Value(input.note),
      ),
    );
  }

  /// รายจ่ายทั่วไป/รายจ่ายจร ถือว่าจ่ายแล้วทันทีที่บันทึก
  Future<int> addOneTime({
    required String name,
    required int amountSatang,
    required DateTime date,
    int? memberId,
    int? categoryId,
    String note = '',
  }) {
    final day = AppDates.dateOnly(date);
    return _dao.insertEntry(
      ExpenseEntriesCompanion.insert(
        name: name,
        amountSatang: amountSatang,
        memberId: Value(memberId),
        dueDate: day,
        monthKey: AppDates.monthKey(day),
        isPaid: const Value(true),
        paidAt: Value(day),
        categoryId: Value(categoryId),
        note: Value(note),
        isOneTime: const Value(true),
      ),
    );
  }

  // ---------- สถานะจ่ายแล้ว ----------

  /// กด "จ่ายแล้ว" (บันทึกวันที่จ่าย) หรือย้อนกลับเป็น "ยังไม่จ่าย"
  Future<void> setPaid(int id, bool paid) async {
    await _dao.setPaid(id, paid, paidAt: DateTime.now());
  }

  // ---------- แก้ไข ----------

  /// แก้เฉพาะรายการนี้ (เดือนนี้เท่านั้น) ไม่กระทบแม่แบบและเดือนอื่น
  Future<void> updateEntry(ExpenseEntry row) async {
    final fixed = row.isOneTime
        ? row.copyWith(monthKey: AppDates.monthKey(row.dueDate))
        : row;
    await _dao.updateEntry(fixed);
  }

  /// แก้แม่แบบ "ตั้งแต่เดือนนี้เป็นต้นไป" (ดูรายละเอียดที่ IncomeRepository)
  /// สถานะจ่ายแล้วของแต่ละเดือนไม่ถูกแตะ
  Future<void> updateTemplateFromMonth({
    required ExpenseTemplate original,
    required ExpenseTemplateInput input,
    required String fromMonth,
  }) {
    return _db.transaction(() async {
      final prev = AppDates.addMonths(fromMonth, -1);
      if (prev.compareTo(original.startMonth) >= 0) {
        var historyFrom = original.startMonth;
        final earliest = AppDates.addMonths(prev, -(maxHistoryMonths - 1));
        if (historyFrom.compareTo(earliest) < 0) historyFrom = earliest;
        await _ensureFor([original], historyFrom, prev);
      }

      final updated = original.copyWith(
        name: input.name,
        amountSatang: input.amountSatang,
        memberId: Value(input.memberId),
        dueDay: input.dueDay,
        categoryId: Value(input.categoryId),
        startMonth: input.startMonth,
        endMonth: Value(input.endMonth),
        totalInstallments: Value(input.totalInstallments),
        remindDaysBefore: Value(input.remindDaysBefore),
        remindTime: Value(input.remindTime),
        note: input.note,
      );
      await _dao.updateTemplate(updated);

      final instances = await _dao.getInstancesFrom(original.id, fromMonth);
      for (final i in instances) {
        final stillActive = TemplateRules.isActiveIn(
          i.monthKey,
          startMonth: updated.startMonth,
          endMonth: updated.endMonth,
          totalInstallments: updated.totalInstallments,
        );
        if (!stillActive) {
          await _dao.deleteEntry(i.id);
          continue;
        }
        await _dao.updateEntry(
          i.copyWith(
            name: updated.name,
            amountSatang: updated.amountSatang,
            memberId: Value(updated.memberId),
            categoryId: Value(updated.categoryId),
            note: updated.note,
            dueDate: AppDates.dateInMonth(i.monthKey, updated.dueDay),
          ),
        );
      }
    });
  }

  // ---------- ปิดยอด / ครบงวดแล้ว ----------

  /// ปิดยอด: บันทึกเดือนสุดท้ายเป็น [monthKey] (เดือนที่กำลังดู)
  /// - เดือนนี้ยังแสดงตามปกติ (ป้าย "งวดสุดท้าย")
  /// - เดือนถัดไปไม่ถูกสร้างอีก และลบ instance ของเดือนหลังจากนี้ที่เผลอสร้างไว้
  /// - ประวัติเดือนก่อนๆ อยู่ครบ
  Future<ExpenseTemplateSnapshot> closeTemplate(
    ExpenseTemplate template,
    String monthKey,
  ) {
    return _db.transaction(() async {
      final next = AppDates.addMonths(monthKey, 1);
      final later = await _dao.getInstancesFrom(template.id, next);
      final snapshot = ExpenseTemplateSnapshot(template, later);
      await _dao.deleteInstancesFrom(template.id, next);
      await _dao.updateTemplate(template.copyWith(endMonth: Value(monthKey)));
      return snapshot;
    });
  }

  /// ยกเลิกการปิดยอด (ล้างเดือนสุดท้าย) — ถ้ากำหนดจำนวนงวดไว้ ยังคงหยุดเองเมื่อครบงวด
  Future<void> reopenTemplate(ExpenseTemplate template) async {
    await _dao.updateTemplate(template.copyWith(endMonth: const Value(null)));
  }

  // ---------- ลบ / Undo ----------

  Future<void> deleteEntry(ExpenseEntry entry) async {
    if (entry.templateId != null) {
      await _dao.setSkipped(entry.id, true);
    } else {
      await _dao.deleteEntry(entry.id);
    }
  }

  Future<void> restoreEntry(ExpenseEntry entry) =>
      _dao.upsertEntry(entry.copyWith(isSkipped: false));

  /// ลบแม่แบบ "ตั้งแต่เดือนนี้เป็นต้นไป" (ถ้าตรงกับเดือนเริ่มต้นหรือก่อนหน้า = ลบทั้งหมด)
  Future<ExpenseTemplateSnapshot> deleteTemplateFromMonth(
    ExpenseTemplate template,
    String fromMonth,
  ) {
    return _db.transaction(() async {
      final entries = await _dao.getInstancesFrom(template.id, fromMonth);
      final snapshot = ExpenseTemplateSnapshot(template, entries);

      if (fromMonth.compareTo(template.startMonth) <= 0) {
        await _dao.deleteTemplate(template.id);
      } else {
        await _dao.deleteInstancesFrom(template.id, fromMonth);
        final prev = AppDates.addMonths(fromMonth, -1);
        final current = template.endMonth;
        final newEnd =
            (current != null && current.compareTo(prev) < 0) ? current : prev;
        await _dao.updateTemplate(template.copyWith(endMonth: Value(newEnd)));
      }
      return snapshot;
    });
  }

  /// Undo การลบหรือการปิดยอดแม่แบบ
  Future<void> restoreTemplate(ExpenseTemplateSnapshot snapshot) {
    return _db.transaction(() async {
      await _dao.upsertTemplate(snapshot.template);
      for (final e in snapshot.entries) {
        await _dao.upsertEntry(e);
      }
    });
  }
}
