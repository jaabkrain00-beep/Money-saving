import 'package:drift/drift.dart';

import '../../core/utils/app_dates.dart';
import '../../domain/monthly_generator.dart';
import '../../domain/template_rules.dart';
import '../db/app_database.dart';
import '../db/daos/income_dao.dart';

/// ข้อมูลสำหรับสร้าง/แก้แม่แบบรายรับประจำ
class IncomeTemplateInput {
  const IncomeTemplateInput({
    required this.name,
    required this.amountSatang,
    required this.dayOfMonth,
    required this.startMonth,
    this.memberId,
    this.categoryId,
    this.endMonth,
    this.note = '',
  });

  final String name;
  final int amountSatang;
  final int? memberId;
  final int dayOfMonth;
  final int? categoryId;
  final String startMonth;
  final String? endMonth;
  final String note;
}

/// ภาพสถานะก่อนลบแม่แบบ ใช้ทำ Undo
class IncomeTemplateSnapshot {
  const IncomeTemplateSnapshot(this.template, this.entries);

  final IncomeTemplate template;
  final List<IncomeEntry> entries;
}

class IncomeRepository {
  IncomeRepository(this._db) : _dao = _db.incomeDao;

  final AppDatabase _db;
  final IncomeDao _dao;

  /// ช่วงสูงสุดที่สร้าง instance ล่วงหน้าในครั้งเดียว (กันลูปยาวผิดปกติ)
  static const int maxEnsureMonths = 600;

  /// เดือนย้อนหลังสูงสุดที่เก็บประวัติให้ก่อนแก้แม่แบบ "ตั้งแต่เดือนนี้"
  static const int maxHistoryMonths = 24;

  // ---------- อ่าน ----------

  Stream<List<IncomeTemplate>> watchTemplates() => _dao.watchTemplates();
  Stream<List<IncomeEntry>> watchAll() => _dao.watchAll();
  Stream<List<IncomeEntry>> watchMonth(String monthKey) =>
      _dao.watchMonth(monthKey);

  /// รายการในช่วงเดือน (ไม่รวมที่ถูกลบเฉพาะเดือน)
  Future<List<IncomeEntry>> getRange(String fromKey, String toKey) =>
      _dao.getRange(fromKey, toKey, includeSkipped: false);

  // ---------- สร้างรายการรายเดือนจากแม่แบบ ----------

  Future<void> ensureMonth(String monthKey) => ensureRange(monthKey, monthKey);

  /// สร้าง instance ของทุกเดือนในช่วง [fromKey]..[toKey] จากแม่แบบที่ active
  /// ปลอดภัยที่จะเรียกซ้ำ (ไม่สร้างซ้ำ รวมถึงรายการที่ผู้ใช้ลบเฉพาะเดือน)
  Future<void> ensureRange(String fromKey, String toKey) async {
    final templates = await _dao.getTemplates();
    await _ensureFor(templates, fromKey, toKey);
  }

  Future<void> _ensureFor(
    List<IncomeTemplate> templates,
    String fromKey,
    String toKey,
  ) async {
    if (templates.isEmpty || toKey.compareTo(fromKey) < 0) return;
    var from = fromKey;
    if (AppDates.monthsBetween(from, toKey) > maxEnsureMonths) {
      from = AppDates.addMonths(toKey, -maxEnsureMonths);
    }

    final existing = await _dao.getRange(from, toKey);
    final byMonth = <String, Set<int>>{};
    for (final e in existing) {
      final id = e.templateId;
      if (id != null) (byMonth[e.monthKey] ??= <int>{}).add(id);
    }

    final toCreate = <IncomeEntriesCompanion>[];
    for (final m in AppDates.monthRange(from, toKey)) {
      toCreate.addAll(
        MonthlyGenerator.incomeToCreate(
          monthKey: m,
          templates: templates,
          existingTemplateIds: byMonth[m] ?? const <int>{},
        ),
      );
    }
    await _dao.insertEntriesIgnoreDuplicates(toCreate);
  }

  /// เดือนแรกสุดที่มีข้อมูลรายรับ (จากแม่แบบหรือรายการ) null ถ้ายังไม่มี
  Future<String?> earliestMonth() async {
    String? best;
    for (final t in await _dao.getTemplates()) {
      if (best == null || t.startMonth.compareTo(best) < 0) best = t.startMonth;
    }
    for (final e in await _dao.getAllEntries()) {
      if (best == null || e.monthKey.compareTo(best) < 0) best = e.monthKey;
    }
    return best;
  }

  // ---------- เพิ่ม ----------

  Future<int> addTemplate(IncomeTemplateInput input) {
    return _dao.insertTemplate(
      IncomeTemplatesCompanion.insert(
        name: input.name,
        amountSatang: input.amountSatang,
        memberId: Value(input.memberId),
        dayOfMonth: input.dayOfMonth,
        categoryId: Value(input.categoryId),
        startMonth: input.startMonth,
        endMonth: Value(input.endMonth),
        note: Value(input.note),
      ),
    );
  }

  /// รายรับพิเศษ (ครั้งเดียว) ถือว่าได้รับแล้วทันที
  Future<int> addOneTime({
    required String name,
    required int amountSatang,
    required DateTime date,
    int? memberId,
    int? categoryId,
    String note = '',
  }) {
    final day = AppDates.dateOnly(date);
    return _dao.insertEntry(
      IncomeEntriesCompanion.insert(
        name: name,
        amountSatang: amountSatang,
        memberId: Value(memberId),
        date: day,
        monthKey: AppDates.monthKey(day),
        isReceived: const Value(true),
        categoryId: Value(categoryId),
        note: Value(note),
        isOneTime: const Value(true),
      ),
    );
  }

  // ---------- แก้ไข ----------

  /// แก้เฉพาะรายการนี้ (เดือนนี้เท่านั้น) ไม่กระทบแม่แบบและเดือนอื่น
  Future<void> updateEntry(IncomeEntry row) async {
    final fixed = row.isOneTime
        ? row.copyWith(monthKey: AppDates.monthKey(row.date))
        : row;
    await _dao.updateEntry(fixed);
  }

  Future<void> setReceived(int id, bool received) async {
    await _dao.setReceived(id, received);
  }

  /// แก้แม่แบบ "ตั้งแต่เดือนนี้เป็นต้นไป"
  /// 1) สร้างรายการเดือนก่อนหน้าที่ยังไม่มี (ย้อนหลังไม่เกิน [maxHistoryMonths] เดือน)
  ///    ด้วยค่าเดิม เพื่อไม่ให้ประวัติเปลี่ยนตามค่าใหม่
  /// 2) แก้แม่แบบ  3) แก้ instance ตั้งแต่ [fromMonth] เป็นต้นไป
  Future<void> updateTemplateFromMonth({
    required IncomeTemplate original,
    required IncomeTemplateInput input,
    required String fromMonth,
  }) {
    return _db.transaction(() async {
      final prev = AppDates.addMonths(fromMonth, -1);
      if (prev.compareTo(original.startMonth) >= 0) {
        var historyFrom = original.startMonth;
        final earliest = AppDates.addMonths(prev, -(maxHistoryMonths - 1));
        if (historyFrom.compareTo(earliest) < 0) historyFrom = earliest;
        await _ensureFor([original], historyFrom, prev);
      }

      final updated = original.copyWith(
        name: input.name,
        amountSatang: input.amountSatang,
        memberId: Value(input.memberId),
        dayOfMonth: input.dayOfMonth,
        categoryId: Value(input.categoryId),
        startMonth: input.startMonth,
        endMonth: Value(input.endMonth),
        note: input.note,
      );
      await _dao.updateTemplate(updated);

      final instances = await _dao.getInstancesFrom(original.id, fromMonth);
      for (final i in instances) {
        final stillActive = TemplateRules.isActiveIn(
          i.monthKey,
          startMonth: updated.startMonth,
          endMonth: updated.endMonth,
        );
        if (!stillActive) {
          await _dao.deleteEntry(i.id);
          continue;
        }
        await _dao.updateEntry(
          i.copyWith(
            name: updated.name,
            amountSatang: updated.amountSatang,
            memberId: Value(updated.memberId),
            categoryId: Value(updated.categoryId),
            note: updated.note,
            date: AppDates.dateInMonth(i.monthKey, updated.dayOfMonth),
          ),
        );
      }
    });
  }

  // ---------- ลบ / Undo ----------

  /// ลบรายการนี้เฉพาะเดือนนี้
  /// - instance จากแม่แบบ: เก็บแถวไว้เป็น tombstone (isSkipped) เพื่อไม่ให้ถูกสร้างซ้ำ
  /// - รายรับพิเศษ: ลบแถวจริง
  Future<void> deleteEntry(IncomeEntry entry) async {
    if (entry.templateId != null) {
      await _dao.setSkipped(entry.id, true);
    } else {
      await _dao.deleteEntry(entry.id);
    }
  }

  Future<void> restoreEntry(IncomeEntry entry) =>
      _dao.upsertEntry(entry.copyWith(isSkipped: false));

  /// ลบแม่แบบ "ตั้งแต่เดือนนี้เป็นต้นไป"
  /// - ถ้า [fromMonth] อยู่ก่อนหรือตรงกับเดือนเริ่มต้น: ลบแม่แบบและรายการทั้งหมด
  /// - ไม่เช่นนั้น: ตั้งเดือนสุดท้ายเป็นเดือนก่อนหน้า ประวัติเก่ายังอยู่ครบ
  Future<IncomeTemplateSnapshot> deleteTemplateFromMonth(
    IncomeTemplate template,
    String fromMonth,
  ) {
    return _db.transaction(() async {
      final entries = await _dao.getInstancesFrom(template.id, fromMonth);
      final snapshot = IncomeTemplateSnapshot(template, entries);

      if (fromMonth.compareTo(template.startMonth) <= 0) {
        await _dao.deleteTemplate(template.id);
      } else {
        await _dao.deleteInstancesFrom(template.id, fromMonth);
        final prev = AppDates.addMonths(fromMonth, -1);
        final current = template.endMonth;
        final newEnd =
            (current != null && current.compareTo(prev) < 0) ? current : prev;
        await _dao.updateTemplate(template.copyWith(endMonth: Value(newEnd)));
      }
      return snapshot;
    });
  }

  Future<void> restoreTemplate(IncomeTemplateSnapshot snapshot) {
    return _db.transaction(() async {
      await _dao.upsertTemplate(snapshot.template);
      for (final e in snapshot.entries) {
        await _dao.upsertEntry(e);
      }
    });
  }
}
