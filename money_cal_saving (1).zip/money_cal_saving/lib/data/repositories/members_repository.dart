import 'package:drift/drift.dart';

import '../db/app_database.dart';
import '../db/daos/members_dao.dart';

class MemberInput {
  const MemberInput({
    required this.name,
    required this.color,
    this.nickname = '',
    this.avatar = '🙂',
  });

  final String name;
  final String nickname;

  /// สี ARGB
  final int color;

  /// อีโมจิ หรือ "file:<path>" สำหรับรูปจากเครื่อง
  final String avatar;
}

/// ภาพสถานะก่อนลบสมาชิก ใช้ทำ Undo (ครอบคลุมทั้งกรณีย้ายไปส่วนกลางและลบรายการทั้งหมด)
class MemberSnapshot {
  const MemberSnapshot({
    required this.member,
    required this.incomeTemplates,
    required this.incomeEntries,
    required this.expenseTemplates,
    required this.expenseEntries,
    required this.goalIds,
  });

  final Member member;
  final List<IncomeTemplate> incomeTemplates;
  final List<IncomeEntry> incomeEntries;
  final List<ExpenseTemplate> expenseTemplates;
  final List<ExpenseEntry> expenseEntries;

  /// เป้าหมายออมที่เคยเป็นของสมาชิกคนนี้ (ถูกย้ายไปส่วนกลางเสมอเมื่อลบ)
  final List<int> goalIds;
}

class MembersRepository {
  MembersRepository(this._db) : _dao = _db.membersDao;

  final AppDatabase _db;
  final MembersDao _dao;

  Stream<List<Member>> watchMembers() => _dao.watchMembers();

  Future<int> addMember(MemberInput input) {
    return _dao.insertMember(
      MembersCompanion.insert(
        name: input.name,
        nickname: Value(input.nickname),
        color: input.color,
        avatar: Value(input.avatar),
      ),
    );
  }

  Future<void> updateMember(Member row) async {
    await _dao.updateMember(row);
  }

  /// จำนวนรายการที่ผูกกับสมาชิก ใช้ถามก่อนลบ
  Future<int> countRecords(int memberId) => _db.countMemberRecords(memberId);

  /// ลบสมาชิก
  /// - [deleteRecords] = false: ย้ายรายการที่ผูกอยู่ไป "ส่วนกลาง"
  /// - [deleteRecords] = true: ลบแม่แบบและรายการรายรับ/รายจ่ายของสมาชิกทั้งหมด
  /// คืน snapshot สำหรับ Undo
  Future<MemberSnapshot> deleteMember(
    int memberId, {
    required bool deleteRecords,
  }) {
    return _db.transaction(() async {
      final snapshot = await _capture(memberId);
      await _db.deleteMember(memberId, deleteRecords: deleteRecords);
      return snapshot;
    });
  }

  /// Undo การลบสมาชิก: คืนสมาชิก แม่แบบ รายการ และความเป็นเจ้าของเป้าหมายออม
  Future<void> restoreMember(MemberSnapshot s) {
    return _db.transaction(() async {
      await _dao.upsertMember(s.member);
      for (final t in s.incomeTemplates) {
        await _db.incomeDao.upsertTemplate(t);
      }
      for (final t in s.expenseTemplates) {
        await _db.expenseDao.upsertTemplate(t);
      }
      for (final e in s.incomeEntries) {
        await _db.incomeDao.upsertEntry(e);
      }
      for (final e in s.expenseEntries) {
        await _db.expenseDao.upsertEntry(e);
      }
      for (final id in s.goalIds) {
        await (_db.update(_db.savingGoals)..where((g) => g.id.equals(id)))
            .write(SavingGoalsCompanion(memberId: Value(s.member.id)));
      }
    });
  }

  Future<MemberSnapshot> _capture(int memberId) async {
    final member = await _dao.getMember(memberId);
    if (member == null) {
      throw StateError('ไม่พบสมาชิก id=$memberId');
    }

    final incomeTpls = await (_db.select(_db.incomeTemplates)
          ..where((t) => t.memberId.equals(memberId)))
        .get();
    final expenseTpls = await (_db.select(_db.expenseTemplates)
          ..where((t) => t.memberId.equals(memberId)))
        .get();
    final incomeTplIds = [for (final t in incomeTpls) t.id];
    final expenseTplIds = [for (final t in expenseTpls) t.id];

    // รวม instance ของแม่แบบของสมาชิกด้วย (แม้ instance นั้นถูกแก้ให้เป็นของคนอื่น)
    // เพราะลบแม่แบบแล้ว instance จะถูกลบตาม (cascade)
    final incomeEntries = await (_db.select(_db.incomeEntries)
          ..where((e) {
            Expression<bool> cond = e.memberId.equals(memberId);
            if (incomeTplIds.isNotEmpty) {
              cond = cond | e.templateId.isIn(incomeTplIds);
            }
            return cond;
          }))
        .get();
    final expenseEntries = await (_db.select(_db.expenseEntries)
          ..where((e) {
            Expression<bool> cond = e.memberId.equals(memberId);
            if (expenseTplIds.isNotEmpty) {
              cond = cond | e.templateId.isIn(expenseTplIds);
            }
            return cond;
          }))
        .get();

    final goals = await (_db.select(_db.savingGoals)
          ..where((g) => g.memberId.equals(memberId)))
        .get();

    return MemberSnapshot(
      member: member,
      incomeTemplates: incomeTpls,
      incomeEntries: incomeEntries,
      expenseTemplates: expenseTpls,
      expenseEntries: expenseEntries,
      goalIds: [for (final g in goals) g.id],
    );
  }
}
