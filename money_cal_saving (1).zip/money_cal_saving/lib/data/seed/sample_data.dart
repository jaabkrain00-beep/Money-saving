import '../../core/utils/app_dates.dart';
import '../db/app_database.dart';
import '../repositories/expense_repository.dart';
import '../repositories/income_repository.dart';
import '../repositories/members_repository.dart';
import '../repositories/savings_repository.dart';

/// ข้อมูลตัวอย่างสำหรับลองใช้แอป (ครอบครัวสมมติ ย้อนหลัง 3 เดือน)
/// เพิ่มต่อจากข้อมูลเดิม ไม่ลบอะไร
Future<void> insertSampleData(AppDatabase db) async {
  final members = MembersRepository(db);
  final income = IncomeRepository(db);
  final expense = ExpenseRepository(db);
  final savings = SavingsRepository(db);

  final cats = await db.membersDao.getCategories();
  int? cat(String name, CategoryType type) {
    for (final c in cats) {
      if (c.name == name && c.type == type) return c.id;
    }
    return null;
  }

  final now = DateTime.now();
  final thisMonth = AppDates.monthKey(now);
  final start = AppDates.addMonths(thisMonth, -3);

  final dad = await members.addMember(
    const MemberInput(name: 'สมชาย ใจดี', nickname: 'พ่อ', color: 0xFFA0C4FF, avatar: '👨'),
  );
  final mom = await members.addMember(
    const MemberInput(name: 'สมหญิง ใจดี', nickname: 'แม่', color: 0xFFF4B6DB, avatar: '👩'),
  );
  final kid = await members.addMember(
    const MemberInput(name: 'น้องมิ้น ใจดี', nickname: 'น้องมิ้น', color: 0xFFA8E6CF, avatar: '👧'),
  );

  // รายรับประจำ
  await income.addTemplate(IncomeTemplateInput(
    name: 'เงินเดือน (พ่อ)',
    amountSatang: 3500000,
    dayOfMonth: 25,
    startMonth: start,
    memberId: dad,
    categoryId: cat('เงินเดือน', CategoryType.income),
  ));
  await income.addTemplate(IncomeTemplateInput(
    name: 'เงินเดือน (แม่)',
    amountSatang: 2800000,
    dayOfMonth: 28,
    startMonth: start,
    memberId: mom,
    categoryId: cat('เงินเดือน', CategoryType.income),
  ));
  await income.addTemplate(IncomeTemplateInput(
    name: 'ขายของออนไลน์',
    amountSatang: 350000,
    dayOfMonth: 5,
    startMonth: start,
    memberId: mom,
    categoryId: cat('รายได้เสริม', CategoryType.income),
  ));

  // รายจ่ายประจำ / ผ่อน
  await expense.addTemplate(ExpenseTemplateInput(
    name: 'ค่าเช่าบ้าน',
    amountSatang: 800000,
    dueDay: 1,
    startMonth: start,
    categoryId: cat('ที่พัก/ค่าเช่า', CategoryType.expense),
  ));
  await expense.addTemplate(ExpenseTemplateInput(
    name: 'ค่าไฟ',
    amountSatang: 185000,
    dueDay: 10,
    startMonth: start,
    categoryId: cat('ค่าน้ำค่าไฟ', CategoryType.expense),
  ));
  await expense.addTemplate(ExpenseTemplateInput(
    name: 'ผ่อนรถ',
    amountSatang: 650000,
    dueDay: 5,
    startMonth: start,
    totalInstallments: 48,
    memberId: dad,
    categoryId: cat('ผ่อนชำระ', CategoryType.expense),
  ));
  await expense.addTemplate(ExpenseTemplateInput(
    name: 'อินเทอร์เน็ตบ้าน',
    amountSatang: 59900,
    dueDay: 15,
    startMonth: start,
    categoryId: cat('ค่าน้ำค่าไฟ', CategoryType.expense),
  ));
  await expense.addTemplate(ExpenseTemplateInput(
    name: 'ค่าเทอมน้องมิ้น',
    amountSatang: 450000,
    dueDay: 20,
    startMonth: start,
    totalInstallments: 6,
    memberId: kid,
    categoryId: cat('การศึกษา', CategoryType.expense),
  ));

  // สร้างรายการรายเดือนของช่วงที่ผ่านมา แล้วทำเครื่องหมายว่าเดือนก่อนๆ ได้รับ/จ่ายแล้ว
  await income.ensureRange(start, thisMonth);
  await expense.ensureRange(start, thisMonth);
  final today = AppDates.dateOnly(now);
  for (final m in AppDates.monthRange(start, thisMonth)) {
    for (final e in await db.incomeDao.getRange(m, m, includeSkipped: false)) {
      if (!e.date.isAfter(today)) await income.setReceived(e.id, true);
    }
    for (final e in await db.expenseDao.getRange(m, m, includeSkipped: false)) {
      if (m.compareTo(thisMonth) < 0 || e.dueDate.isBefore(today)) {
        await expense.setPaid(e.id, true);
      }
    }
  }

  // รายการครั้งเดียว
  await income.addOneTime(
    name: 'โบนัสกลางปี',
    amountSatang: 1500000,
    date: DateTime(now.year, now.month, 1),
    memberId: dad,
    categoryId: cat('โบนัส', CategoryType.income),
  );
  await expense.addOneTime(
    name: 'ค่าอาหารสุดสัปดาห์',
    amountSatang: 235000,
    date: today,
    categoryId: cat('อาหาร', CategoryType.expense),
  );
  await expense.addOneTime(
    name: 'ซื้อของใช้ในบ้าน',
    amountSatang: 128000,
    date: today,
    memberId: mom,
    categoryId: cat('ช้อปปิ้ง', CategoryType.expense),
  );

  // เป้าหมายออม
  final trip = await savings.addGoal(GoalInput(
    name: 'เที่ยวญี่ปุ่น',
    targetSatang: 6000000,
    color: 0xFFF4B6DB,
    emoji: '✈️',
    targetDate: DateTime(now.year + 1, now.month, 1),
  ));
  final emergency = await savings.addGoal(const GoalInput(
    name: 'เงินสำรองฉุกเฉิน',
    targetSatang: 10000000,
    color: 0xFFC3B1E1,
    emoji: '🛡️',
  ));
  await savings.addTransaction(
    goalId: trip,
    amountSatang: 1500000,
    type: SavingTxType.deposit,
    date: DateTime(now.year, now.month, 1),
  );
  await savings.addTransaction(
    goalId: emergency,
    amountSatang: 2500000,
    type: SavingTxType.deposit,
    date: today,
  );
}
