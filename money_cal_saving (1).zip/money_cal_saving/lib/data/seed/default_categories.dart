import '../db/tables.dart';

typedef DefaultCategory = ({
  String name,
  CategoryType type,
  String icon,
  int color,
});

/// หมวดหมู่ตั้งต้น (สร้างตอนติดตั้งครั้งแรก) ผู้ใช้เพิ่ม/แก้/ลบได้ในหน้า "หมวดหมู่"
const List<DefaultCategory> kDefaultCategories = [
  // รายรับ
  (name: 'เงินเดือน', type: CategoryType.income, icon: '💰', color: 0xFFA8E6CF),
  (name: 'โบนัส', type: CategoryType.income, icon: '🎁', color: 0xFFFFE5A0),
  (name: 'รายได้เสริม', type: CategoryType.income, icon: '💼', color: 0xFFA0C4FF),
  (name: 'ดอกเบี้ย/ปันผล', type: CategoryType.income, icon: '📈', color: 0xFF9EE0E6),
  (name: 'อื่นๆ', type: CategoryType.income, icon: '✨', color: 0xFFC3B1E1),
  // รายจ่าย
  (name: 'อาหาร', type: CategoryType.expense, icon: '🍜', color: 0xFFFFC8A2),
  (name: 'ที่พัก/ค่าเช่า', type: CategoryType.expense, icon: '🏠', color: 0xFFFFB7B2),
  (name: 'ค่าน้ำค่าไฟ', type: CategoryType.expense, icon: '💡', color: 0xFFFFE5A0),
  (name: 'เดินทาง', type: CategoryType.expense, icon: '🚌', color: 0xFFA0C4FF),
  (name: 'ช้อปปิ้ง', type: CategoryType.expense, icon: '🛍️', color: 0xFFF4B6DB),
  (name: 'สุขภาพ', type: CategoryType.expense, icon: '💊', color: 0xFFA8E6CF),
  (name: 'การศึกษา', type: CategoryType.expense, icon: '📚', color: 0xFFBDB2FF),
  (name: 'ผ่อนชำระ', type: CategoryType.expense, icon: '💳', color: 0xFFD5C4A1),
  (name: 'บันเทิง', type: CategoryType.expense, icon: '🎬', color: 0xFFC3B1E1),
  (name: 'ครอบครัว/ลูก', type: CategoryType.expense, icon: '👶', color: 0xFF9EE0E6),
  (name: 'อื่นๆ', type: CategoryType.expense, icon: '✨', color: 0xFFC3B1E1),
];
