/// คีย์ของตาราง settings(key, value) — ค่าทุกตัวเก็บเป็นข้อความ
class SettingKeys {
  SettingKeys._();

  /// 'system' | 'light' | 'dark'
  static const themeMode = 'themeMode';

  /// 'true' = แสดงปี พ.ศ. (ค่าเริ่มต้น), 'false' = ค.ศ.
  static const buddhistYear = 'buddhistYear';

  /// 'true' = ยกยอดคงเหลือไปเดือนถัดไป (ค่าเริ่มต้นปิด)
  static const carryOver = 'carryOver';

  /// เตือนล่วงหน้ากี่วัน: 0, 1, 3, 7 (ค่าเริ่มต้น 1)
  static const remindDaysBefore = 'remindDaysBefore';

  /// เวลาเตือน "HH:mm" (ค่าเริ่มต้น 09:00)
  static const remindTime = 'remindTime';

  /// 'true' = เตือนวันเงินเดือนเข้า
  static const notifyPayday = 'notifyPayday';

  /// 'true' = เปิดการแจ้งเตือนรายจ่าย
  static const notifyExpense = 'notifyExpense';

  /// PIN: เก็บเฉพาะ hash + salt ห้ามเก็บตัวเลขจริง
  static const pinHash = 'pinHash';
  static const pinSalt = 'pinSalt';

  /// 'true' = เปิดด้วยลายนิ้วมือ
  static const biometric = 'biometric';

  /// 'true' = ติดตั้งข้อมูลตัวอย่างแล้ว
  static const seeded = 'seeded';

  /// สีแบรนด์ที่ผู้ใช้เลือก (index ของชุดสี)
  static const accentIndex = 'accentIndex';
}
