import 'package:drift/drift.dart';

import '../app_database.dart';
import '../tables.dart';

part 'expense_dao.g.dart';

@DriftAccessor(tables: [ExpenseTemplates, ExpenseEntries])
class ExpenseDao extends DatabaseAccessor<AppDatabase> with _$ExpenseDaoMixin {
  ExpenseDao(super.attachedDatabase);

  // ---------- แม่แบบรายจ่ายประจำ ----------

  Stream<List<ExpenseTemplate>> watchTemplates() =>
      (select(expenseTemplates)..orderBy([(t) => OrderingTerm.asc(t.id)]))
          .watch();

  Future<List<ExpenseTemplate>> getTemplates() =>
      (select(expenseTemplates)..orderBy([(t) => OrderingTerm.asc(t.id)]))
          .get();

  Future<ExpenseTemplate?> getTemplate(int id) =>
      (select(expenseTemplates)..where((t) => t.id.equals(id)))
          .getSingleOrNull();

  Future<int> insertTemplate(ExpenseTemplatesCompanion entry) =>
      into(expenseTemplates).insert(entry);

  Future<bool> updateTemplate(ExpenseTemplate row) =>
      update(expenseTemplates).replace(row);

  /// ลบแม่แบบ — instance ทุกเดือนถูกลบตาม (cascade)
  Future<int> deleteTemplate(int id) =>
      (delete(expenseTemplates)..where((t) => t.id.equals(id))).go();

  // ---------- รายการรายเดือน ----------

  /// รายการของเดือน (ไม่รวมที่ถูกลบเฉพาะเดือนนี้) เรียงตามวันครบกำหนด
  Stream<List<ExpenseEntry>> watchMonth(String monthKey) =>
      (select(expenseEntries)
            ..where(
                (t) => t.monthKey.equals(monthKey) & t.isSkipped.equals(false))
            ..orderBy([
              (t) => OrderingTerm.asc(t.dueDate),
              (t) => OrderingTerm.asc(t.id),
            ]))
          .watch();

  Stream<List<ExpenseEntry>> watchRange(String fromKey, String toKey) =>
      (select(expenseEntries)
            ..where((t) =>
                t.monthKey.isBetweenValues(fromKey, toKey) &
                t.isSkipped.equals(false))
            ..orderBy([(t) => OrderingTerm.asc(t.dueDate)]))
          .watch();

  Stream<List<ExpenseEntry>> watchAll() => (select(expenseEntries)
        ..where((t) => t.isSkipped.equals(false))
        ..orderBy([(t) => OrderingTerm.asc(t.dueDate)]))
      .watch();

  /// รายจ่ายที่ยังไม่จ่ายทั้งหมด (ใช้ตั้งการแจ้งเตือนและหน้า "การแจ้งเตือน")
  Stream<List<ExpenseEntry>> watchUnpaid() => (select(expenseEntries)
        ..where((t) => t.isPaid.equals(false) & t.isSkipped.equals(false))
        ..orderBy([(t) => OrderingTerm.asc(t.dueDate)]))
      .watch();

  Future<List<ExpenseEntry>> getUnpaid() => (select(expenseEntries)
        ..where((t) => t.isPaid.equals(false) & t.isSkipped.equals(false))
        ..orderBy([(t) => OrderingTerm.asc(t.dueDate)]))
      .get();

  Future<List<ExpenseEntry>> getMonth(
    String monthKey, {
    bool includeSkipped = false,
  }) {
    final query = select(expenseEntries)
      ..where((t) => t.monthKey.equals(monthKey))
      ..orderBy([
        (t) => OrderingTerm.asc(t.dueDate),
        (t) => OrderingTerm.asc(t.id),
      ]);
    if (!includeSkipped) {
      query.where((t) => t.isSkipped.equals(false));
    }
    return query.get();
  }

  Future<List<ExpenseEntry>> getAllEntries() =>
      (select(expenseEntries)..orderBy([(t) => OrderingTerm.asc(t.id)])).get();

  Future<ExpenseEntry?> getEntry(int id) =>
      (select(expenseEntries)..where((t) => t.id.equals(id)))
          .getSingleOrNull();

  Future<List<ExpenseEntry>> getInstancesFrom(
          int templateId, String fromMonth) =>
      (select(expenseEntries)
            ..where((t) =>
                t.templateId.equals(templateId) &
                t.monthKey.isBiggerOrEqualValue(fromMonth))
            ..orderBy([(t) => OrderingTerm.asc(t.monthKey)]))
          .get();

  Future<int> insertEntry(ExpenseEntriesCompanion entry) =>
      into(expenseEntries).insert(entry);

  /// แทรกหลายรายการ ข้ามรายการที่ซ้ำ unique key (templateId + monthKey)
  Future<void> insertEntriesIgnoreDuplicates(
    List<ExpenseEntriesCompanion> entries,
  ) {
    if (entries.isEmpty) return Future.value();
    return batch((b) {
      b.insertAll(expenseEntries, entries, mode: InsertMode.insertOrIgnore);
    });
  }

  Future<bool> updateEntry(ExpenseEntry row) =>
      update(expenseEntries).replace(row);

  /// รายการในช่วงเดือน (ใช้ตอนสร้าง instance ล่วงหน้าทั้งช่วง)
  Future<List<ExpenseEntry>> getRange(
    String fromKey,
    String toKey, {
    bool includeSkipped = true,
  }) {
    final query = select(expenseEntries)
      ..where((t) => t.monthKey.isBetweenValues(fromKey, toKey));
    if (!includeSkipped) {
      query.where((t) => t.isSkipped.equals(false));
    }
    return query.get();
  }

  /// เพิ่มหรืออัปเดตแม่แบบด้วย id เดิม (ใช้ตอน Undo) — ไม่ใช้ replace เพราะจะ cascade ลบ instance
  Future<void> upsertTemplate(ExpenseTemplate row) =>
      into(expenseTemplates).insertOnConflictUpdate(row);

  /// เพิ่มหรืออัปเดตรายการด้วย id เดิม (ใช้ตอน Undo)
  Future<void> upsertEntry(ExpenseEntry row) async {
    final templateId = row.templateId;
    if (templateId != null) {
      await (delete(expenseEntries)
            ..where((t) =>
                t.templateId.equals(templateId) &
                t.monthKey.equals(row.monthKey) &
                t.id.isNotValue(row.id)))
          .go();
    }
    await into(expenseEntries).insertOnConflictUpdate(row);
  }

  /// จ่ายแล้ว (บันทึกวันที่จ่าย) หรือย้อนกลับเป็นยังไม่จ่าย (ล้างวันที่จ่าย)
  Future<int> setPaid(int id, bool paid, {DateTime? paidAt}) =>
      (update(expenseEntries)..where((t) => t.id.equals(id))).write(
        ExpenseEntriesCompanion(
          isPaid: Value(paid),
          paidAt: Value(paid ? (paidAt ?? DateTime.now()) : null),
        ),
      );

  Future<int> setSkipped(int id, bool skipped) =>
      (update(expenseEntries)..where((t) => t.id.equals(id)))
          .write(ExpenseEntriesCompanion(isSkipped: Value(skipped)));

  Future<int> deleteEntry(int id) =>
      (delete(expenseEntries)..where((t) => t.id.equals(id))).go();

  Future<int> deleteInstancesFrom(int templateId, String fromMonth) =>
      (delete(expenseEntries)
            ..where((t) =>
                t.templateId.equals(templateId) &
                t.monthKey.isBiggerOrEqualValue(fromMonth)))
          .go();
}
