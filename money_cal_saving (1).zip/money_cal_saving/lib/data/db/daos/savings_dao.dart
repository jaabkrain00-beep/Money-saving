import 'package:drift/drift.dart';

import '../app_database.dart';
import '../tables.dart';

part 'savings_dao.g.dart';

@DriftAccessor(tables: [SavingGoals, SavingTransactions])
class SavingsDao extends DatabaseAccessor<AppDatabase> with _$SavingsDaoMixin {
  SavingsDao(super.attachedDatabase);

  // ---------- เป้าหมายออม ----------

  Stream<List<SavingGoal>> watchGoals() => (select(savingGoals)
        ..orderBy([
          (t) => OrderingTerm.asc(t.isCompleted),
          (t) => OrderingTerm.desc(t.createdAt),
          (t) => OrderingTerm.desc(t.id),
        ]))
      .watch();

  Future<List<SavingGoal>> getGoals() =>
      (select(savingGoals)..orderBy([(t) => OrderingTerm.asc(t.id)])).get();

  Future<SavingGoal?> getGoal(int id) =>
      (select(savingGoals)..where((t) => t.id.equals(id))).getSingleOrNull();

  Future<int> insertGoal(SavingGoalsCompanion entry) =>
      into(savingGoals).insert(entry);

  Future<bool> updateGoal(SavingGoal row) => update(savingGoals).replace(row);

  /// เพิ่มหรืออัปเดตเป้าหมายด้วย id เดิม (ใช้ตอน Undo การลบ)
  Future<void> upsertGoal(SavingGoal row) =>
      into(savingGoals).insertOnConflictUpdate(row);

  Future<int> setCompleted(int id, bool completed) =>
      (update(savingGoals)..where((t) => t.id.equals(id)))
          .write(SavingGoalsCompanion(isCompleted: Value(completed)));

  /// ลบเป้าหมาย — รายการฝาก/ถอนของเป้าหมายนี้ถูกลบตาม (cascade)
  Future<int> deleteGoal(int id) =>
      (delete(savingGoals)..where((t) => t.id.equals(id))).go();

  // ---------- รายการฝาก/ถอน ----------

  Stream<List<SavingTransaction>> watchTransactions(int goalId) =>
      (select(savingTransactions)
            ..where((t) => t.goalId.equals(goalId))
            ..orderBy([
              (t) => OrderingTerm.desc(t.date),
              (t) => OrderingTerm.desc(t.id),
            ]))
          .watch();

  Stream<List<SavingTransaction>> watchAllTransactions() =>
      (select(savingTransactions)
            ..orderBy([
              (t) => OrderingTerm.desc(t.date),
              (t) => OrderingTerm.desc(t.id),
            ]))
          .watch();

  /// รายการฝาก/ถอนของเดือนที่เลือก (นับเป็นเงินออมของเดือนนั้น)
  Stream<List<SavingTransaction>> watchMonth(String monthKey) =>
      (select(savingTransactions)
            ..where((t) => t.monthKey.equals(monthKey))
            ..orderBy([(t) => OrderingTerm.desc(t.date)]))
          .watch();

  Stream<List<SavingTransaction>> watchRange(String fromKey, String toKey) =>
      (select(savingTransactions)
            ..where((t) => t.monthKey.isBetweenValues(fromKey, toKey)))
          .watch();

  Future<List<SavingTransaction>> getTransactions(int goalId) =>
      (select(savingTransactions)
            ..where((t) => t.goalId.equals(goalId))
            ..orderBy([(t) => OrderingTerm.asc(t.date)]))
          .get();

  Future<List<SavingTransaction>> getAllTransactions() =>
      (select(savingTransactions)..orderBy([(t) => OrderingTerm.asc(t.id)]))
          .get();

  Future<SavingTransaction?> getTransaction(int id) =>
      (select(savingTransactions)..where((t) => t.id.equals(id)))
          .getSingleOrNull();

  Future<int> insertTransaction(SavingTransactionsCompanion entry) =>
      into(savingTransactions).insert(entry);

  Future<bool> updateTransaction(SavingTransaction row) =>
      update(savingTransactions).replace(row);

  /// เพิ่มหรืออัปเดตรายการฝาก/ถอนด้วย id เดิม (ใช้ตอน Undo การลบ)
  Future<void> upsertTransaction(SavingTransaction row) =>
      into(savingTransactions).insertOnConflictUpdate(row);

  Future<int> deleteTransaction(int id) =>
      (delete(savingTransactions)..where((t) => t.id.equals(id))).go();
}
