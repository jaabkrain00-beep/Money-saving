import 'package:drift/drift.dart';

import '../app_database.dart';
import '../tables.dart';

part 'settings_dao.g.dart';

@DriftAccessor(tables: [AppSettings])
class SettingsDao extends DatabaseAccessor<AppDatabase>
    with _$SettingsDaoMixin {
  SettingsDao(super.attachedDatabase);

  /// การตั้งค่าทั้งหมดเป็น Map (reactive)
  Stream<Map<String, String>> watchAll() => select(appSettings)
      .watch()
      .map((rows) => {for (final r in rows) r.key: r.value});

  Future<Map<String, String>> getAll() async {
    final rows = await select(appSettings).get();
    return {for (final r in rows) r.key: r.value};
  }

  Future<String?> get(String key) => (select(appSettings)
        ..where((t) => t.key.equals(key)))
      .map((r) => r.value)
      .getSingleOrNull();

  Future<void> put(String key, String value) => into(appSettings)
      .insertOnConflictUpdate(
        AppSettingsCompanion(key: Value(key), value: Value(value)),
      );

  Future<int> remove(String key) =>
      (delete(appSettings)..where((t) => t.key.equals(key))).go();
}
