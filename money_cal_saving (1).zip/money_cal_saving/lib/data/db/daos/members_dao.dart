import 'package:drift/drift.dart';

import '../app_database.dart';
import '../tables.dart';

part 'members_dao.g.dart';

@DriftAccessor(tables: [Members, Categories])
class MembersDao extends DatabaseAccessor<AppDatabase> with _$MembersDaoMixin {
  MembersDao(super.attachedDatabase);

  // ---------- สมาชิก ----------

  Stream<List<Member>> watchMembers() => (select(members)
        ..orderBy([
          (t) => OrderingTerm.asc(t.createdAt),
          (t) => OrderingTerm.asc(t.id),
        ]))
      .watch();

  Future<List<Member>> getMembers() => (select(members)
        ..orderBy([
          (t) => OrderingTerm.asc(t.createdAt),
          (t) => OrderingTerm.asc(t.id),
        ]))
      .get();

  Future<Member?> getMember(int id) =>
      (select(members)..where((t) => t.id.equals(id))).getSingleOrNull();

  Future<int> insertMember(MembersCompanion entry) =>
      into(members).insert(entry);

  Future<bool> updateMember(Member row) => update(members).replace(row);

  /// เพิ่มหรืออัปเดตสมาชิกด้วย id เดิม (ใช้ตอน Undo การลบ)
  Future<void> upsertMember(Member row) =>
      into(members).insertOnConflictUpdate(row);

  // การลบสมาชิกอยู่ที่ AppDatabase.deleteMember (ต้องถามผู้ใช้ก่อน)

  // ---------- หมวดหมู่ ----------

  Stream<List<Category>> watchCategories() => (select(categories)
        ..orderBy([
          (t) => OrderingTerm.asc(t.sortOrder),
          (t) => OrderingTerm.asc(t.id),
        ]))
      .watch();

  Future<List<Category>> getCategories() => (select(categories)
        ..orderBy([
          (t) => OrderingTerm.asc(t.sortOrder),
          (t) => OrderingTerm.asc(t.id),
        ]))
      .get();

  Future<int> insertCategory(CategoriesCompanion entry) =>
      into(categories).insert(entry);

  Future<bool> updateCategory(Category row) => update(categories).replace(row);

  /// เพิ่มหรืออัปเดตหมวดหมู่ด้วย id เดิม (ใช้ตอน Undo การลบ)
  Future<void> upsertCategory(Category row) =>
      into(categories).insertOnConflictUpdate(row);

  /// ลบหมวดหมู่ — รายการที่ใช้หมวดนี้จะกลายเป็น "ไม่มีหมวด" (set null)
  Future<int> deleteCategory(int id) =>
      (delete(categories)..where((t) => t.id.equals(id))).go();

  /// บันทึกลำดับใหม่ของหมวดหมู่ตามลำดับ id ที่ส่งมา
  Future<void> reorderCategories(List<int> orderedIds) {
    return batch((b) {
      for (var i = 0; i < orderedIds.length; i++) {
        b.update(
          categories,
          CategoriesCompanion(sortOrder: Value(i)),
          where: (t) => t.id.equals(orderedIds[i]),
        );
      }
    });
  }
}
