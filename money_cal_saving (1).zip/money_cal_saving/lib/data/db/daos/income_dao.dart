import 'package:drift/drift.dart';

import '../app_database.dart';
import '../tables.dart';

part 'income_dao.g.dart';

@DriftAccessor(tables: [IncomeTemplates, IncomeEntries])
class IncomeDao extends DatabaseAccessor<AppDatabase> with _$IncomeDaoMixin {
  IncomeDao(super.attachedDatabase);

  // ---------- แม่แบบรายรับประจำ ----------

  Stream<List<IncomeTemplate>> watchTemplates() =>
      (select(incomeTemplates)..orderBy([(t) => OrderingTerm.asc(t.id)]))
          .watch();

  Future<List<IncomeTemplate>> getTemplates() =>
      (select(incomeTemplates)..orderBy([(t) => OrderingTerm.asc(t.id)])).get();

  Future<IncomeTemplate?> getTemplate(int id) =>
      (select(incomeTemplates)..where((t) => t.id.equals(id)))
          .getSingleOrNull();

  Future<int> insertTemplate(IncomeTemplatesCompanion entry) =>
      into(incomeTemplates).insert(entry);

  Future<bool> updateTemplate(IncomeTemplate row) =>
      update(incomeTemplates).replace(row);

  /// ลบแม่แบบ — instance ทุกเดือนถูกลบตาม (cascade)
  Future<int> deleteTemplate(int id) =>
      (delete(incomeTemplates)..where((t) => t.id.equals(id))).go();

  // ---------- รายการรายเดือน ----------

  /// รายการของเดือน (ไม่รวมที่ถูกลบเฉพาะเดือนนี้) เรียงตามวันที่
  Stream<List<IncomeEntry>> watchMonth(String monthKey) => (select(incomeEntries)
        ..where((t) => t.monthKey.equals(monthKey) & t.isSkipped.equals(false))
        ..orderBy([
          (t) => OrderingTerm.asc(t.date),
          (t) => OrderingTerm.asc(t.id),
        ]))
      .watch();

  /// รายการในช่วงเดือน [fromKey]..[toKey] รวมหัวท้าย (ใช้กับกราฟย้อนหลัง)
  Stream<List<IncomeEntry>> watchRange(String fromKey, String toKey) =>
      (select(incomeEntries)
            ..where((t) =>
                t.monthKey.isBetweenValues(fromKey, toKey) &
                t.isSkipped.equals(false))
            ..orderBy([(t) => OrderingTerm.asc(t.date)]))
          .watch();

  Stream<List<IncomeEntry>> watchAll() => (select(incomeEntries)
        ..where((t) => t.isSkipped.equals(false))
        ..orderBy([(t) => OrderingTerm.asc(t.date)]))
      .watch();

  Future<List<IncomeEntry>> getMonth(
    String monthKey, {
    bool includeSkipped = false,
  }) {
    final query = select(incomeEntries)
      ..where((t) => t.monthKey.equals(monthKey))
      ..orderBy([
        (t) => OrderingTerm.asc(t.date),
        (t) => OrderingTerm.asc(t.id),
      ]);
    if (!includeSkipped) {
      query.where((t) => t.isSkipped.equals(false));
    }
    return query.get();
  }

  Future<List<IncomeEntry>> getAllEntries() =>
      (select(incomeEntries)..orderBy([(t) => OrderingTerm.asc(t.id)])).get();

  Future<IncomeEntry?> getEntry(int id) =>
      (select(incomeEntries)..where((t) => t.id.equals(id))).getSingleOrNull();

  /// instance ของแม่แบบตั้งแต่เดือน [fromMonth] เป็นต้นไป (รวม tombstone)
  Future<List<IncomeEntry>> getInstancesFrom(int templateId, String fromMonth) =>
      (select(incomeEntries)
            ..where((t) =>
                t.templateId.equals(templateId) &
                t.monthKey.isBiggerOrEqualValue(fromMonth))
            ..orderBy([(t) => OrderingTerm.asc(t.monthKey)]))
          .get();

  Future<int> insertEntry(IncomeEntriesCompanion entry) =>
      into(incomeEntries).insert(entry);

  /// แทรกหลายรายการ ข้ามรายการที่ซ้ำ unique key (templateId + monthKey)
  /// จึงปลอดภัยแม้ถูกเรียกซ้อนกัน — ห้ามสร้างซ้ำ
  Future<void> insertEntriesIgnoreDuplicates(
    List<IncomeEntriesCompanion> entries,
  ) {
    if (entries.isEmpty) return Future.value();
    return batch((b) {
      b.insertAll(incomeEntries, entries, mode: InsertMode.insertOrIgnore);
    });
  }

  Future<bool> updateEntry(IncomeEntry row) =>
      update(incomeEntries).replace(row);

  /// รายการในช่วงเดือน (ใช้ตอนสร้าง instance ล่วงหน้าทั้งช่วง)
  Future<List<IncomeEntry>> getRange(
    String fromKey,
    String toKey, {
    bool includeSkipped = true,
  }) {
    final query = select(incomeEntries)
      ..where((t) => t.monthKey.isBetweenValues(fromKey, toKey));
    if (!includeSkipped) {
      query.where((t) => t.isSkipped.equals(false));
    }
    return query.get();
  }

  /// เพิ่มหรืออัปเดตแม่แบบด้วย id เดิม (ใช้ตอน Undo)
  /// ใช้ upsert ไม่ใช่ insert-or-replace เพราะ replace จะลบแถวเดิมและ cascade ลบ instance
  Future<void> upsertTemplate(IncomeTemplate row) =>
      into(incomeTemplates).insertOnConflictUpdate(row);

  /// เพิ่มหรืออัปเดตรายการด้วย id เดิม (ใช้ตอน Undo)
  /// ลบแถวอื่นที่ชน unique key (templateId + monthKey) ก่อน เผื่อระบบสร้างรายการใหม่ไปแล้ว
  Future<void> upsertEntry(IncomeEntry row) async {
    final templateId = row.templateId;
    if (templateId != null) {
      await (delete(incomeEntries)
            ..where((t) =>
                t.templateId.equals(templateId) &
                t.monthKey.equals(row.monthKey) &
                t.id.isNotValue(row.id)))
          .go();
    }
    await into(incomeEntries).insertOnConflictUpdate(row);
  }

  Future<int> setReceived(int id, bool received) =>
      (update(incomeEntries)..where((t) => t.id.equals(id)))
          .write(IncomeEntriesCompanion(isReceived: Value(received)));

  Future<int> setSkipped(int id, bool skipped) =>
      (update(incomeEntries)..where((t) => t.id.equals(id)))
          .write(IncomeEntriesCompanion(isSkipped: Value(skipped)));

  Future<int> deleteEntry(int id) =>
      (delete(incomeEntries)..where((t) => t.id.equals(id))).go();

  /// ลบ instance ของแม่แบบตั้งแต่เดือน [fromMonth] เป็นต้นไป
  Future<int> deleteInstancesFrom(int templateId, String fromMonth) =>
      (delete(incomeEntries)
            ..where((t) =>
                t.templateId.equals(templateId) &
                t.monthKey.isBiggerOrEqualValue(fromMonth)))
          .go();

  /// ลบรายการ "ยอดยกมา" ของเดือน (ใช้ตอนสร้างใหม่หรือปิดตัวเลือก)
  Future<int> deleteCarryOver(String monthKey) => (delete(incomeEntries)
        ..where((t) => t.isCarryOver.equals(true) & t.monthKey.equals(monthKey)))
      .go();
}
