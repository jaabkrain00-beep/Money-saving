import 'dart:io';

import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../seed/default_categories.dart';
import 'daos/expense_dao.dart';
import 'daos/income_dao.dart';
import 'daos/members_dao.dart';
import 'daos/savings_dao.dart';
import 'daos/settings_dao.dart';
import 'tables.dart';

export 'tables.dart' show CategoryType, SavingTxType;

part 'app_database.g.dart';

@DriftDatabase(
  tables: [
    Members,
    Categories,
    IncomeTemplates,
    IncomeEntries,
    ExpenseTemplates,
    ExpenseEntries,
    SavingGoals,
    SavingTransactions,
    AppSettings,
  ],
  daos: [MembersDao, IncomeDao, ExpenseDao, SavingsDao, SettingsDao],
)
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());

  /// ใช้ในการทดสอบ (เช่น NativeDatabase.memory())
  AppDatabase.forTesting(QueryExecutor executor) : super(executor);

  @override
  int get schemaVersion => 1;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (migrator) async {
          await migrator.createAll();
          await _insertDefaultCategories();
        },
        beforeOpen: (details) async {
          // เปิดใช้ foreign key (setNull / cascade ทำงานตามที่ออกแบบ)
          await customStatement('PRAGMA foreign_keys = ON');
        },
      );

  Future<void> _insertDefaultCategories() async {
    await batch((b) {
      b.insertAll(categories, [
        for (var i = 0; i < kDefaultCategories.length; i++)
          CategoriesCompanion.insert(
            name: kDefaultCategories[i].name,
            type: kDefaultCategories[i].type,
            color: kDefaultCategories[i].color,
            icon: Value(kDefaultCategories[i].icon),
            sortOrder: Value(i),
          ),
      ]);
    });
  }

  /// จำนวนรายการ (แม่แบบ + รายการรายเดือน) ที่ผูกกับสมาชิก ใช้ถามก่อนลบสมาชิก
  Future<int> countMemberRecords(int memberId) async {
    Future<int> count(TableInfo<Table, dynamic> table, GeneratedColumn<int> col) {
      final total = countAll();
      final query = selectOnly(table)
        ..addColumns([total])
        ..where(col.equals(memberId));
      return query.map((row) => row.read(total) ?? 0).getSingle();
    }

    final results = await Future.wait([
      count(incomeTemplates, incomeTemplates.memberId),
      count(incomeEntries, incomeEntries.memberId),
      count(expenseTemplates, expenseTemplates.memberId),
      count(expenseEntries, expenseEntries.memberId),
    ]);
    return results.fold<int>(0, (a, b) => a + b);
  }

  /// ลบสมาชิก
  /// - [deleteRecords] = false: รายการที่ผูกอยู่ถูกย้ายไป "ส่วนกลาง" (memberId = null)
  ///   โดย foreign key แบบ set null
  /// - [deleteRecords] = true: ลบแม่แบบและรายการรายรับ/รายจ่ายของสมาชิกทั้งหมดก่อน
  /// เป้าหมายออมของสมาชิกจะถูกย้ายไปส่วนกลางเสมอ (ไม่ลบเงินออม)
  Future<void> deleteMember(int memberId, {required bool deleteRecords}) {
    return transaction(() async {
      if (deleteRecords) {
        // แม่แบบถูกลบ -> instance ถูกลบตาม (cascade)
        await (delete(incomeTemplates)
              ..where((t) => t.memberId.equals(memberId)))
            .go();
        await (delete(expenseTemplates)
              ..where((t) => t.memberId.equals(memberId)))
            .go();
        await (delete(incomeEntries)..where((t) => t.memberId.equals(memberId)))
            .go();
        await (delete(expenseEntries)
              ..where((t) => t.memberId.equals(memberId)))
            .go();
      }
      await (delete(members)..where((t) => t.id.equals(memberId))).go();
    });
  }

  /// ล้างข้อมูลทั้งหมด (ปุ่ม "ล้างข้อมูล" ในหน้าตั้งค่า)
  /// ค่าเริ่มต้นคงหมวดหมู่และการตั้งค่าไว้
  Future<void> clearAllData({bool keepCategories = true}) {
    return transaction(() async {
      await delete(savingTransactions).go();
      await delete(savingGoals).go();
      await delete(incomeEntries).go();
      await delete(expenseEntries).go();
      await delete(incomeTemplates).go();
      await delete(expenseTemplates).go();
      await delete(members).go();
      if (!keepCategories) {
        await delete(categories).go();
        await _insertDefaultCategories();
      }
    });
  }
}

LazyDatabase _openConnection() {
  return LazyDatabase(() async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File(p.join(dir.path, 'money_cal_saving.sqlite'));
    return NativeDatabase.createInBackground(file);
  });
}
