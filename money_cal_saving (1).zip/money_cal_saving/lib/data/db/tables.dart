import 'package:drift/drift.dart';

/// ประเภทหมวดหมู่
enum CategoryType { income, expense }

/// ประเภทรายการเงินออม
enum SavingTxType { deposit, withdraw }

/// จำนวนเงินทุกช่องเก็บเป็น "สตางค์" (int) เท่านั้น
/// monthKey รูปแบบ "yyyy-MM" (ค.ศ.)

@DataClassName('Member')
class Members extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get name => text()();
  TextColumn get nickname => text().withDefault(const Constant(''))();

  /// สีประจำตัว (ARGB int)
  IntColumn get color => integer()();

  /// อีโมจิ หรือ "file:<path>" สำหรับรูปจากเครื่อง
  TextColumn get avatar => text().withDefault(const Constant('🙂'))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

@DataClassName('Category')
class Categories extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get name => text()();
  TextColumn get type => textEnum<CategoryType>()();

  /// อีโมจิประจำหมวด
  TextColumn get icon => text().withDefault(const Constant('✨'))();
  IntColumn get color => integer()();
  IntColumn get sortOrder => integer().withDefault(const Constant(0))();
}

/// แม่แบบรายรับประจำ
@DataClassName('IncomeTemplate')
class IncomeTemplates extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get name => text()();
  IntColumn get amountSatang => integer()();
  IntColumn get memberId => integer()
      .nullable()
      .references(Members, #id, onDelete: KeyAction.setNull)();

  /// วันที่เงินเข้า 1-31
  IntColumn get dayOfMonth => integer()();
  IntColumn get categoryId => integer()
      .nullable()
      .references(Categories, #id, onDelete: KeyAction.setNull)();
  TextColumn get startMonth => text()();
  TextColumn get endMonth => text().nullable()();
  TextColumn get note => text().withDefault(const Constant(''))();
}

/// รายการรายรับของแต่ละเดือน (instance จากแม่แบบ หรือรายรับพิเศษ)
@DataClassName('IncomeEntry')
@TableIndex(name: 'income_entries_month', columns: {#monthKey})
class IncomeEntries extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get templateId => integer()
      .nullable()
      .references(IncomeTemplates, #id, onDelete: KeyAction.cascade)();
  TextColumn get name => text()();
  IntColumn get amountSatang => integer()();
  IntColumn get memberId => integer()
      .nullable()
      .references(Members, #id, onDelete: KeyAction.setNull)();
  DateTimeColumn get date => dateTime()();
  TextColumn get monthKey => text()();
  BoolColumn get isReceived => boolean().withDefault(const Constant(false))();
  IntColumn get categoryId => integer()
      .nullable()
      .references(Categories, #id, onDelete: KeyAction.setNull)();
  TextColumn get note => text().withDefault(const Constant(''))();
  BoolColumn get isOneTime => boolean().withDefault(const Constant(false))();

  /// เพิ่มเติมจากสเปก: รายการ "ยอดยกมา" ที่ระบบสร้างจากการยกยอดคงเหลือ
  BoolColumn get isCarryOver => boolean().withDefault(const Constant(false))();

  /// เพิ่มเติมจากสเปก: ผู้ใช้ลบ instance ของเดือนนี้เดือนเดียว
  /// เก็บแถวไว้เป็น tombstone เพื่อไม่ให้ระบบสร้างซ้ำ (และใช้ทำ Undo ได้ง่าย)
  BoolColumn get isSkipped => boolean().withDefault(const Constant(false))();

  @override
  List<Set<Column>> get uniqueKeys => [
        {templateId, monthKey},
      ];
}

/// แม่แบบรายจ่ายประจำเดือน
@DataClassName('ExpenseTemplate')
class ExpenseTemplates extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get name => text()();
  IntColumn get amountSatang => integer()();
  IntColumn get memberId => integer()
      .nullable()
      .references(Members, #id, onDelete: KeyAction.setNull)();

  /// วันครบกำหนดจ่าย 1-31
  IntColumn get dueDay => integer()();
  IntColumn get categoryId => integer()
      .nullable()
      .references(Categories, #id, onDelete: KeyAction.setNull)();
  TextColumn get startMonth => text()();

  /// เดือนสุดท้าย (null = ไม่มีกำหนด) ใช้กับ "ปิดยอด / ครบงวดแล้ว"
  TextColumn get endMonth => text().nullable()();

  /// จำนวนงวดทั้งหมด (null = ไม่กำหนด)
  IntColumn get totalInstallments => integer().nullable()();

  /// เตือนล่วงหน้ากี่วัน (null = ใช้ค่ารวมของแอป)
  IntColumn get remindDaysBefore => integer().nullable()();

  /// เวลาเตือน "HH:mm" (null = ใช้ค่ารวมของแอป)
  TextColumn get remindTime => text().nullable()();
  TextColumn get note => text().withDefault(const Constant(''))();
}

/// รายการรายจ่ายของแต่ละเดือน (instance จากแม่แบบ หรือรายจ่ายจร)
@DataClassName('ExpenseEntry')
@TableIndex(name: 'expense_entries_month', columns: {#monthKey})
class ExpenseEntries extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get templateId => integer()
      .nullable()
      .references(ExpenseTemplates, #id, onDelete: KeyAction.cascade)();
  TextColumn get name => text()();
  IntColumn get amountSatang => integer()();
  IntColumn get memberId => integer()
      .nullable()
      .references(Members, #id, onDelete: KeyAction.setNull)();
  DateTimeColumn get dueDate => dateTime()();
  TextColumn get monthKey => text()();
  BoolColumn get isPaid => boolean().withDefault(const Constant(false))();
  DateTimeColumn get paidAt => dateTime().nullable()();
  IntColumn get categoryId => integer()
      .nullable()
      .references(Categories, #id, onDelete: KeyAction.setNull)();
  TextColumn get note => text().withDefault(const Constant(''))();
  BoolColumn get isOneTime => boolean().withDefault(const Constant(false))();

  /// เพิ่มเติมจากสเปก: tombstone ของ instance ที่ถูกลบเฉพาะเดือนนี้
  BoolColumn get isSkipped => boolean().withDefault(const Constant(false))();

  @override
  List<Set<Column>> get uniqueKeys => [
        {templateId, monthKey},
      ];
}

@DataClassName('SavingGoal')
class SavingGoals extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get name => text()();
  IntColumn get targetSatang => integer()();
  DateTimeColumn get targetDate => dateTime().nullable()();
  TextColumn get emoji => text().withDefault(const Constant('🎯'))();
  IntColumn get color => integer()();
  IntColumn get memberId => integer()
      .nullable()
      .references(Members, #id, onDelete: KeyAction.setNull)();
  BoolColumn get isCompleted => boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

@DataClassName('SavingTransaction')
@TableIndex(name: 'saving_transactions_month', columns: {#monthKey})
class SavingTransactions extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get goalId =>
      integer().references(SavingGoals, #id, onDelete: KeyAction.cascade)();
  IntColumn get amountSatang => integer()();
  TextColumn get type => textEnum<SavingTxType>()();
  DateTimeColumn get date => dateTime()();
  TextColumn get monthKey => text()();
  TextColumn get note => text().withDefault(const Constant(''))();
}

@DataClassName('SettingRow')
class AppSettings extends Table {
  @override
  String get tableName => 'settings';

  TextColumn get key => text()();
  TextColumn get value => text()();

  @override
  Set<Column> get primaryKey => {key};
}
