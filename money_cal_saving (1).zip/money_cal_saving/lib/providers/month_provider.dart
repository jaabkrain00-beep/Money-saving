import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/utils/app_dates.dart';
import 'settings_provider.dart';

/// เดือนที่เลือกอยู่ (state กลางที่ทุกหน้าใช้ร่วมกัน) รูปแบบ "yyyy-MM"
class SelectedMonthNotifier extends Notifier<String> {
  @override
  String build() => AppDates.monthKey(DateTime.now());

  void set(String monthKey) => state = monthKey;
  void next() => state = AppDates.addMonths(state, 1);
  void previous() => state = AppDates.addMonths(state, -1);
  void goToToday() => state = AppDates.monthKey(DateTime.now());
}

final selectedMonthProvider =
    NotifierProvider<SelectedMonthNotifier, String>(SelectedMonthNotifier.new);

/// แสดงปีเป็น พ.ศ. (true) หรือ ค.ศ. (false) ตามการตั้งค่า
final useBuddhistYearProvider = Provider<bool>(
  (ref) => ref.watch(settingsProvider.select((s) => s.buddhistYear)),
);
