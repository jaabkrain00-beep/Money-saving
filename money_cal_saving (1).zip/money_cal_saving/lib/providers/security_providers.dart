import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../services/backup_service.dart';
import '../services/pin_service.dart';
import 'core_providers.dart';
import 'settings_provider.dart';

final pinServiceProvider = Provider<PinService>(
  (ref) => PinService(ref.watch(settingsRepositoryProvider)),
);

final backupServiceProvider = Provider<BackupService>(
  (ref) => BackupService(ref.watch(databaseProvider)),
);

/// สถานะล็อกหน้าจอ: เริ่มต้นล็อกเมื่อมี PIN แล้ว (อ่านจากค่าที่โหลดก่อนเปิดแอป)
class AppLockNotifier extends Notifier<bool> {
  @override
  bool build() => ref.read(initialSettingsProvider).hasPin;

  void lock() => state = true;
  void unlock() => state = false;
}

final appLockProvider =
    NotifierProvider<AppLockNotifier, bool>(AppLockNotifier.new);
