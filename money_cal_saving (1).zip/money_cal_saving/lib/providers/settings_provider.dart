import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/repositories/settings_repository.dart';
import 'core_providers.dart';

/// ค่าตั้งต้นก่อนอ่านฐานข้อมูลเสร็จ — main.dart โหลดค่าจริงล่วงหน้าแล้ว override ตัวนี้
/// เพื่อไม่ให้ธีม/ภาษาของปีกะพริบตอนเปิดแอป
final initialSettingsProvider =
    Provider<SettingsState>((ref) => SettingsState.defaults);

final settingsStreamProvider = StreamProvider<SettingsState>(
  (ref) => ref.watch(settingsRepositoryProvider).watch(),
);

/// การตั้งค่าปัจจุบัน (อัปเดตทันทีเมื่อแก้ในหน้าตั้งค่า)
final settingsProvider = Provider<SettingsState>((ref) {
  return ref.watch(settingsStreamProvider).valueOrNull ??
      ref.watch(initialSettingsProvider);
});
