import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/utils/app_dates.dart';
import '../data/db/app_database.dart';
import '../domain/summary_calculator.dart';
import 'data_providers.dart';
import 'month_provider.dart';
import 'settings_provider.dart';

/// ยอดยกมาเข้าเดือนที่เลือก (0 ถ้าไม่ได้เปิดตัวเลือก "ยกยอดคงเหลือไปเดือนถัดไป")
/// คำนวณสดจากข้อมูลทั้งหมดทุกครั้ง จึงถูกต้องเสมอแม้ไปแก้ข้อมูลเดือนก่อน
final carryOverProvider = Provider<int>((ref) {
  final enabled = ref.watch(settingsProvider.select((s) => s.carryOver));
  if (!enabled) return 0;

  final month = ref.watch(selectedMonthProvider);
  final income = ref.watch(allIncomeProvider).valueOrNull ?? const <IncomeEntry>[];
  final expenses =
      ref.watch(allExpenseProvider).valueOrNull ?? const <ExpenseEntry>[];
  final savings = ref.watch(allSavingTxProvider).valueOrNull ??
      const <SavingTransaction>[];

  final all = SummaryCalculator.computeAll(
    income: income,
    expenses: expenses,
    savings: savings,
  );
  if (all.isEmpty) return 0;

  final first = all.keys.reduce((a, b) => a.compareTo(b) <= 0 ? a : b);
  return SummaryCalculator.carryOverInto(
    monthKey: month,
    firstMonth: first,
    baseSummary: (key) => all[key] ?? MonthSummary(monthKey: key),
  );
});

/// สรุปเดือนที่เลือก — [memberId] null = ทั้งครอบครัว (รวมยอดยกมา), ระบุ = รายคน
final monthSummaryProvider = Provider.family<MonthSummary, int?>((ref, memberId) {
  final month = ref.watch(selectedMonthProvider);
  return SummaryCalculator.compute(
    monthKey: month,
    income: ref.watch(allIncomeProvider).valueOrNull ?? const <IncomeEntry>[],
    expenses:
        ref.watch(allExpenseProvider).valueOrNull ?? const <ExpenseEntry>[],
    savings: ref.watch(allSavingTxProvider).valueOrNull ??
        const <SavingTransaction>[],
    carryOver: memberId == null ? ref.watch(carryOverProvider) : 0,
    memberId: memberId,
    goalOwners: ref.watch(goalOwnersProvider),
  );
});

/// สรุปเดือนก่อนหน้า (ไม่รวมยอดยกมา ใช้เปรียบเทียบ "เพิ่มขึ้น/ลดลง")
final previousMonthSummaryProvider =
    Provider.family<MonthSummary, int?>((ref, memberId) {
  final month = AppDates.addMonths(ref.watch(selectedMonthProvider), -1);
  return SummaryCalculator.compute(
    monthKey: month,
    income: ref.watch(allIncomeProvider).valueOrNull ?? const <IncomeEntry>[],
    expenses:
        ref.watch(allExpenseProvider).valueOrNull ?? const <ExpenseEntry>[],
    savings: ref.watch(allSavingTxProvider).valueOrNull ??
        const <SavingTransaction>[],
    memberId: memberId,
    goalOwners: ref.watch(goalOwnersProvider),
  );
});

/// รายจ่ายของเดือนที่เลือกแยกตามหมวด (เรียงมากไปน้อย)
final monthExpenseByCategoryProvider =
    Provider.family<List<CategoryTotal>, int?>((ref, memberId) {
  return SummaryCalculator.expenseByCategory(
    ref.watch(allExpenseProvider).valueOrNull ?? const <ExpenseEntry>[],
    monthKey: ref.watch(selectedMonthProvider),
    memberId: memberId,
  );
});
