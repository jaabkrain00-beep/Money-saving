import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/utils/app_dates.dart';
import '../data/db/app_database.dart';
import '../domain/goal_calculator.dart';
import 'core_providers.dart';
import 'month_provider.dart';
import 'settings_provider.dart';

// ---------------------------------------------------------------------------
// แหล่งข้อมูลหลัก (single source of truth): reactive stream ของ Drift
// ทุกหน้าอ่านจาก provider เหล่านี้ เมื่อมีการแก้ไขข้อมูล ทุกหน้าอัปเดตทันที
// ---------------------------------------------------------------------------

final membersProvider = StreamProvider<List<Member>>(
  (ref) => ref.watch(membersRepositoryProvider).watchMembers(),
);

final categoriesProvider = StreamProvider<List<Category>>(
  (ref) => ref.watch(categoriesRepositoryProvider).watchCategories(),
);

final incomeTemplatesProvider = StreamProvider<List<IncomeTemplate>>(
  (ref) => ref.watch(incomeRepositoryProvider).watchTemplates(),
);

final expenseTemplatesProvider = StreamProvider<List<ExpenseTemplate>>(
  (ref) => ref.watch(expenseRepositoryProvider).watchTemplates(),
);

/// รายรับทุกเดือน (ไม่รวมรายการที่ถูกลบเฉพาะเดือน)
final allIncomeProvider = StreamProvider<List<IncomeEntry>>(
  (ref) => ref.watch(incomeRepositoryProvider).watchAll(),
);

/// รายจ่ายทุกเดือน (ไม่รวมรายการที่ถูกลบเฉพาะเดือน)
final allExpenseProvider = StreamProvider<List<ExpenseEntry>>(
  (ref) => ref.watch(expenseRepositoryProvider).watchAll(),
);

final goalsProvider = StreamProvider<List<SavingGoal>>(
  (ref) => ref.watch(savingsRepositoryProvider).watchGoals(),
);

final allSavingTxProvider = StreamProvider<List<SavingTransaction>>(
  (ref) => ref.watch(savingsRepositoryProvider).watchAllTransactions(),
);

/// รายจ่ายที่ยังไม่จ่ายทั้งหมด (ใช้ตั้งการแจ้งเตือนและหน้า "การแจ้งเตือน")
final unpaidExpensesProvider = StreamProvider<List<ExpenseEntry>>(
  (ref) => ref.watch(expenseRepositoryProvider).watchUnpaid(),
);

// ---------------------------------------------------------------------------
// ตัวช่วยค้นหาด้วย id
// ---------------------------------------------------------------------------

final memberMapProvider = Provider<Map<int, Member>>((ref) {
  final list = ref.watch(membersProvider).valueOrNull ?? const <Member>[];
  return {for (final m in list) m.id: m};
});

final categoryMapProvider = Provider<Map<int, Category>>((ref) {
  final list = ref.watch(categoriesProvider).valueOrNull ?? const <Category>[];
  return {for (final c in list) c.id: c};
});

final incomeCategoriesProvider = Provider<List<Category>>((ref) {
  final list = ref.watch(categoriesProvider).valueOrNull ?? const <Category>[];
  return [for (final c in list) if (c.type == CategoryType.income) c];
});

final expenseCategoriesProvider = Provider<List<Category>>((ref) {
  final list = ref.watch(categoriesProvider).valueOrNull ?? const <Category>[];
  return [for (final c in list) if (c.type == CategoryType.expense) c];
});

final incomeTemplateMapProvider = Provider<Map<int, IncomeTemplate>>((ref) {
  final list = ref.watch(incomeTemplatesProvider).valueOrNull ??
      const <IncomeTemplate>[];
  return {for (final t in list) t.id: t};
});

final expenseTemplateMapProvider = Provider<Map<int, ExpenseTemplate>>((ref) {
  final list = ref.watch(expenseTemplatesProvider).valueOrNull ??
      const <ExpenseTemplate>[];
  return {for (final t in list) t.id: t};
});

/// ยอดออมสุทธิของแต่ละเป้าหมาย goalId -> สตางค์
final goalBalancesProvider = Provider<Map<int, int>>((ref) {
  final txs =
      ref.watch(allSavingTxProvider).valueOrNull ?? const <SavingTransaction>[];
  final byGoal = <int, List<SavingTransaction>>{};
  for (final t in txs) {
    (byGoal[t.goalId] ??= []).add(t);
  }
  return {
    for (final entry in byGoal.entries)
      entry.key: GoalCalculator.balance(entry.value),
  };
});

/// เจ้าของเป้าหมาย goalId -> memberId (ใช้กรองเงินออมรายคน)
final goalOwnersProvider = Provider<Map<int, int?>>((ref) {
  final goals = ref.watch(goalsProvider).valueOrNull ?? const <SavingGoal>[];
  return {for (final g in goals) g.id: g.memberId};
});

// ---------------------------------------------------------------------------
// การสร้างรายการประจำเดือนจากแม่แบบ
// เมื่อเปิดแอปหรือเปลี่ยนไปดูเดือนใดๆ ระบบสร้าง instance ของเดือนนั้น (ไม่ซ้ำ)
// และสร้างใหม่อัตโนมัติเมื่อแม่แบบเปลี่ยน
// ---------------------------------------------------------------------------

/// เดือนแรกสุดที่มีข้อมูล (จากแม่แบบหรือรายการ) null ถ้ายังไม่มีข้อมูล
final earliestMonthProvider = Provider<String?>((ref) {
  String? best;
  void consider(String key) {
    if (best == null || key.compareTo(best!) < 0) best = key;
  }

  for (final t in ref.watch(incomeTemplatesProvider).valueOrNull ??
      const <IncomeTemplate>[]) {
    consider(t.startMonth);
  }
  for (final t in ref.watch(expenseTemplatesProvider).valueOrNull ??
      const <ExpenseTemplate>[]) {
    consider(t.startMonth);
  }
  for (final e
      in ref.watch(allIncomeProvider).valueOrNull ?? const <IncomeEntry>[]) {
    consider(e.monthKey);
  }
  for (final e
      in ref.watch(allExpenseProvider).valueOrNull ?? const <ExpenseEntry>[]) {
    consider(e.monthKey);
  }
  for (final t in ref.watch(allSavingTxProvider).valueOrNull ??
      const <SavingTransaction>[]) {
    consider(t.monthKey);
  }
  return best;
});

/// ช่วงเดือนที่ต้องสร้างรายการ "from|to": เดือนก่อนหน้า (ไว้เทียบ) ถึงเดือนที่เลือก
/// ถ้าเปิด "ยกยอดคงเหลือ" ต้องสร้างย้อนไปถึงเดือนแรกสุดเพื่อให้ยอดยกมาครบ
final monthWindowKeyProvider = Provider<String>((ref) {
  final month = ref.watch(selectedMonthProvider);
  var from = AppDates.addMonths(month, -1);
  if (ref.watch(settingsProvider.select((s) => s.carryOver))) {
    final earliest = ref.watch(earliestMonthProvider);
    if (earliest != null && earliest.compareTo(from) < 0) from = earliest;
  }
  return '$from|$month';
});

/// สร้างรายการประจำเดือนของช่วง [key] ("from|to") ทั้งรายรับและรายจ่าย
/// ทำงานซ้ำเมื่อแม่แบบเปลี่ยน (เช่นเพิ่มรายการประจำใหม่ขณะดูเดือนนี้)
final ensureWindowProvider = FutureProvider.family<void, String>((ref, key) async {
  await ref.watch(incomeTemplatesProvider.future);
  await ref.watch(expenseTemplatesProvider.future);
  final parts = key.split('|');
  await ref.read(incomeRepositoryProvider).ensureRange(parts[0], parts[1]);
  await ref.read(expenseRepositoryProvider).ensureRange(parts[0], parts[1]);
});

/// ข้อมูลของเดือนที่เลือกพร้อมแสดงแล้วหรือยัง (ใช้เลี่ยง empty state กะพริบตอนโหลด)
final monthReadyProvider = Provider<bool>((ref) {
  final key = ref.watch(monthWindowKeyProvider);
  final ensure = ref.watch(ensureWindowProvider(key));
  final incomeLoaded = ref.watch(allIncomeProvider).hasValue;
  final expenseLoaded = ref.watch(allExpenseProvider).hasValue;
  return ensure.hasValue && incomeLoaded && expenseLoaded;
});

// ---------------------------------------------------------------------------
// รายการของเดือนที่เลือก
// ---------------------------------------------------------------------------

final monthIncomeProvider = Provider<List<IncomeEntry>>((ref) {
  final month = ref.watch(selectedMonthProvider);
  final all = ref.watch(allIncomeProvider).valueOrNull ?? const <IncomeEntry>[];
  final list = [for (final e in all) if (e.monthKey == month) e];
  list.sort((a, b) {
    final byDate = a.date.compareTo(b.date);
    return byDate != 0 ? byDate : a.id.compareTo(b.id);
  });
  return list;
});

final monthExpenseProvider = Provider<List<ExpenseEntry>>((ref) {
  final month = ref.watch(selectedMonthProvider);
  final all =
      ref.watch(allExpenseProvider).valueOrNull ?? const <ExpenseEntry>[];
  final list = [for (final e in all) if (e.monthKey == month) e];
  list.sort((a, b) {
    final byDate = a.dueDate.compareTo(b.dueDate);
    return byDate != 0 ? byDate : a.id.compareTo(b.id);
  });
  return list;
});

/// รายการฝาก/ถอนของเดือนที่เลือก (ใหม่สุดก่อน)
final monthSavingTxProvider = Provider<List<SavingTransaction>>((ref) {
  final month = ref.watch(selectedMonthProvider);
  final all = ref.watch(allSavingTxProvider).valueOrNull ??
      const <SavingTransaction>[];
  final list = [for (final t in all) if (t.monthKey == month) t];
  list.sort((a, b) {
    final byDate = b.date.compareTo(a.date);
    return byDate != 0 ? byDate : b.id.compareTo(a.id);
  });
  return list;
});
