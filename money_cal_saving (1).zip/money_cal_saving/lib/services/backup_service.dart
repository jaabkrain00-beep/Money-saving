import 'dart:convert';
import 'dart:io';

import 'package:drift/drift.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../core/utils/app_dates.dart';
import '../core/utils/money.dart';
import '../data/db/app_database.dart';
import '../data/settings_keys.dart';

class BackupException implements Exception {
  const BackupException(this.message);

  final String message;

  @override
  String toString() => message;
}

/// สำรอง/กู้คืนข้อมูลเป็นไฟล์ JSON และส่งออก CSV (ทำงานออฟไลน์ล้วน)
class BackupService {
  BackupService(this._db);

  final AppDatabase _db;

  static const String appMarker = 'money_cal_saving';
  static const int formatVersion = 1;

  /// คีย์การตั้งค่าที่ไม่ใส่ลงไฟล์สำรอง (PIN ไม่ควรออกจากเครื่อง)
  static const Set<String> _excludedSettings = {
    SettingKeys.pinHash,
    SettingKeys.pinSalt,
    SettingKeys.biometric,
  };

  // ---------------------------------------------------------------- JSON

  Future<String> buildBackupJson() async {
    final settings = await _db.settingsDao.getAll();
    final map = <String, dynamic>{
      'app': appMarker,
      'version': formatVersion,
      'exportedAt': DateTime.now().toIso8601String(),
      'members': [for (final r in await _db.select(_db.members).get()) r.toJson()],
      'categories': [for (final r in await _db.select(_db.categories).get()) r.toJson()],
      'incomeTemplates': [for (final r in await _db.select(_db.incomeTemplates).get()) r.toJson()],
      'incomeEntries': [for (final r in await _db.select(_db.incomeEntries).get()) r.toJson()],
      'expenseTemplates': [for (final r in await _db.select(_db.expenseTemplates).get()) r.toJson()],
      'expenseEntries': [for (final r in await _db.select(_db.expenseEntries).get()) r.toJson()],
      'savingGoals': [for (final r in await _db.select(_db.savingGoals).get()) r.toJson()],
      'savingTransactions': [for (final r in await _db.select(_db.savingTransactions).get()) r.toJson()],
      'settings': {
        for (final e in settings.entries)
          if (!_excludedSettings.contains(e.key)) e.key: e.value,
      },
    };
    return const JsonEncoder.withIndent('  ').convert(map);
  }

  /// เขียนไฟล์สำรองลงโฟลเดอร์ชั่วคราว คืน path เพื่อส่งต่อด้วย share sheet
  Future<String> writeBackupFile() async {
    final json = await buildBackupJson();
    final dir = await getTemporaryDirectory();
    final stamp = _stamp();
    final file = File(p.join(dir.path, 'money_cal_saving_backup_$stamp.json'));
    await file.writeAsString(json, flush: true);
    return file.path;
  }

  /// กู้คืนจากข้อความ JSON: ตรวจรูปแบบก่อน แล้วแทนที่ข้อมูลทั้งหมดใน transaction เดียว
  /// ถ้าไฟล์ผิดพลาด ข้อมูลเดิมจะไม่ถูกแตะ
  Future<void> restoreFromJson(String source) async {
    final Map<String, dynamic> map;
    try {
      final decoded = jsonDecode(source);
      if (decoded is! Map<String, dynamic>) throw const FormatException();
      map = decoded;
    } on FormatException {
      throw const BackupException('ไฟล์ไม่ใช่ไฟล์สำรองที่ถูกต้อง');
    }
    if (map['app'] != appMarker) {
      throw const BackupException('ไฟล์นี้ไม่ได้มาจากแอป Money Cal Saving');
    }
    final version = map['version'];
    if (version is! int || version > formatVersion) {
      throw const BackupException('ไฟล์สำรองมาจากแอปเวอร์ชันที่ใหม่กว่า กรุณาอัปเดตแอปก่อน');
    }

    List<Map<String, dynamic>> list(String key) {
      final v = map[key];
      if (v == null) return const [];
      if (v is! List) throw BackupException('ข้อมูล "$key" ในไฟล์ไม่ถูกต้อง');
      return [for (final e in v) (e as Map).cast<String, dynamic>()];
    }

    // แปลงเป็น data class ทั้งหมดก่อนแตะฐานข้อมูล (พังตรงนี้ = ไม่มีอะไรเปลี่ยน)
    final List<Member> members;
    final List<Category> categories;
    final List<IncomeTemplate> incomeTemplates;
    final List<IncomeEntry> incomeEntries;
    final List<ExpenseTemplate> expenseTemplates;
    final List<ExpenseEntry> expenseEntries;
    final List<SavingGoal> goals;
    final List<SavingTransaction> txs;
    try {
      members = [for (final m in list('members')) Member.fromJson(m)];
      categories = [for (final m in list('categories')) Category.fromJson(m)];
      incomeTemplates = [for (final m in list('incomeTemplates')) IncomeTemplate.fromJson(m)];
      incomeEntries = [for (final m in list('incomeEntries')) IncomeEntry.fromJson(m)];
      expenseTemplates = [for (final m in list('expenseTemplates')) ExpenseTemplate.fromJson(m)];
      expenseEntries = [for (final m in list('expenseEntries')) ExpenseEntry.fromJson(m)];
      goals = [for (final m in list('savingGoals')) SavingGoal.fromJson(m)];
      txs = [for (final m in list('savingTransactions')) SavingTransaction.fromJson(m)];
    } on BackupException {
      rethrow;
    } catch (_) {
      throw const BackupException('อ่านข้อมูลในไฟล์สำรองไม่ได้ ไฟล์อาจเสียหาย');
    }
    final settings = (map['settings'] is Map)
        ? (map['settings'] as Map).map((k, v) => MapEntry('$k', '$v'))
        : <String, String>{};

    await _db.transaction(() async {
      // ลบลูกก่อนแม่ (foreign key เปิดอยู่)
      await _db.delete(_db.savingTransactions).go();
      await _db.delete(_db.savingGoals).go();
      await _db.delete(_db.incomeEntries).go();
      await _db.delete(_db.expenseEntries).go();
      await _db.delete(_db.incomeTemplates).go();
      await _db.delete(_db.expenseTemplates).go();
      await _db.delete(_db.members).go();
      await _db.delete(_db.categories).go();

      Future<void> insertAll<T extends Table, D>(
        TableInfo<T, D> table,
        List<Insertable<D>> rows,
      ) async {
        await _db.batch((b) => b.insertAll(table, rows));
      }

      await insertAll(_db.categories, categories);
      await insertAll(_db.members, members);
      await insertAll(_db.incomeTemplates, incomeTemplates);
      await insertAll(_db.expenseTemplates, expenseTemplates);
      await insertAll(_db.incomeEntries, incomeEntries);
      await insertAll(_db.expenseEntries, expenseEntries);
      await insertAll(_db.savingGoals, goals);
      await insertAll(_db.savingTransactions, txs);

      for (final e in settings.entries) {
        if (_excludedSettings.contains(e.key)) continue;
        await _db.settingsDao.put(e.key, e.value);
      }
      await _db.settingsDao.put(SettingKeys.seeded, 'true');
    });
  }

  // ----------------------------------------------------------------- CSV

  /// สร้างไฟล์ CSV 3 ไฟล์ (รายรับ รายจ่าย เงินออม) ใส่ BOM ให้ Excel อ่านภาษาไทยได้
  /// คืนรายการ path
  Future<List<String>> writeCsvFiles() async {
    final dir = await getTemporaryDirectory();
    final stamp = _stamp();
    final members = {for (final m in await _db.select(_db.members).get()) m.id: m};
    final cats = {for (final c in await _db.select(_db.categories).get()) c.id: c};
    final goals = {for (final g in await _db.select(_db.savingGoals).get()) g.id: g};

    String memberName(int? id) {
      final m = id == null ? null : members[id];
      if (m == null) return 'ส่วนกลาง';
      return m.nickname.trim().isNotEmpty ? m.nickname : m.name;
    }

    String catName(int? id) => id == null ? '' : (cats[id]?.name ?? '');

    String date(DateTime d) =>
        '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

    final income = (await _db.select(_db.incomeEntries).get())
      ..sort((a, b) => a.date.compareTo(b.date));
    final expenses = (await _db.select(_db.expenseEntries).get())
      ..sort((a, b) => a.dueDate.compareTo(b.dueDate));
    final txs = (await _db.select(_db.savingTransactions).get())
      ..sort((a, b) => a.date.compareTo(b.date));

    final incomeCsv = _csv(
      ['วันที่', 'เดือน', 'ชื่อรายการ', 'สมาชิก', 'หมวดหมู่', 'ประเภท', 'จำนวน(บาท)', 'สถานะ', 'หมายเหตุ'],
      [
        for (final e in income)
          if (!e.isSkipped)
            [
              date(e.date),
              e.monthKey,
              e.name,
              memberName(e.memberId),
              catName(e.categoryId),
              e.templateId != null ? 'ประจำ' : 'พิเศษ',
              _baht(e.amountSatang),
              e.isReceived ? 'ได้รับแล้ว' : 'รอเงินเข้า',
              e.note,
            ],
      ],
    );
    final expenseCsv = _csv(
      ['วันครบกำหนด', 'เดือน', 'ชื่อรายการ', 'สมาชิก', 'หมวดหมู่', 'ประเภท', 'จำนวน(บาท)', 'สถานะ', 'วันที่จ่าย', 'หมายเหตุ'],
      [
        for (final e in expenses)
          if (!e.isSkipped)
            [
              date(e.dueDate),
              e.monthKey,
              e.name,
              memberName(e.memberId),
              catName(e.categoryId),
              e.templateId != null ? 'ประจำ' : 'จร',
              _baht(e.amountSatang),
              e.isPaid ? 'จ่ายแล้ว' : 'ยังไม่จ่าย',
              e.paidAt == null ? '' : date(e.paidAt!),
              e.note,
            ],
      ],
    );
    final savingCsv = _csv(
      ['วันที่', 'เดือน', 'เป้าหมาย', 'ประเภท', 'จำนวน(บาท)', 'หมายเหตุ'],
      [
        for (final t in txs)
          [
            date(t.date),
            t.monthKey,
            goals[t.goalId]?.name ?? '',
            t.type == SavingTxType.deposit ? 'ฝาก' : 'ถอน',
            _baht(t.amountSatang),
            t.note,
          ],
      ],
    );

    final files = <String>[];
    Future<void> write(String name, String content) async {
      final f = File(p.join(dir.path, '${name}_$stamp.csv'));
      // BOM ให้ Excel เปิดภาษาไทยไม่เพี้ยน
      await f.writeAsBytes([0xEF, 0xBB, 0xBF, ...utf8.encode(content)], flush: true);
      files.add(f.path);
    }

    await write('income', incomeCsv);
    await write('expense', expenseCsv);
    await write('saving', savingCsv);
    return files;
  }

  static String _baht(int satang) => Money.format(satang).replaceAll(',', '');

  static String _csv(List<String> header, List<List<String>> rows) {
    String esc(String v) {
      var s = v;
      // กัน CSV injection ใน Excel (ค่าที่ขึ้นต้นด้วยสัญลักษณ์สูตร)
      if (s.isNotEmpty && '=+-@'.contains(s[0]) && double.tryParse(s) == null) {
        s = "'$s";
      }
      if (s.contains(',') || s.contains('"') || s.contains('\n') || s.contains('\r')) {
        return '"${s.replaceAll('"', '""')}"';
      }
      return s;
    }

    final b = StringBuffer()..writeln(header.map(esc).join(','));
    for (final r in rows) {
      b.writeln(r.map(esc).join(','));
    }
    return b.toString();
  }

  static String _stamp() {
    final n = DateTime.now();
    return '${AppDates.monthKey(n)}-${n.day.toString().padLeft(2, '0')}'
        '_${n.hour.toString().padLeft(2, '0')}${n.minute.toString().padLeft(2, '0')}';
  }
}
