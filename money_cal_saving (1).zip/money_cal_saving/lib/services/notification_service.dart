import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import '../core/utils/app_dates.dart';
import '../core/utils/money.dart';
import '../data/db/app_database.dart';
import '../data/repositories/expense_repository.dart';
import '../data/repositories/income_repository.dart';
import '../data/repositories/settings_repository.dart';

const String kPaidActionId = 'paid';
const String _expenseChannelId = 'expense_due';
const String _paydayChannelId = 'payday';
const int _incomeIdOffset = 1000000;
const int _maxScheduled = 120;

/// ผู้ใช้กดปุ่ม "จ่ายแล้ว" บนการแจ้งเตือนตอนแอปไม่ได้เปิดอยู่
/// ทำงานใน isolate แยก จึงเปิดฐานข้อมูลของตัวเองแล้วปิดทันที
/// (แอปจะรีเฟรช stream เองเมื่อกลับมา foreground ดู NotificationSync)
@pragma('vm:entry-point')
void notificationTapBackground(NotificationResponse response) async {
  if (response.actionId != kPaidActionId) return;
  final id = _expenseIdFromPayload(response.payload);
  if (id == null) return;
  final db = AppDatabase();
  try {
    await ExpenseRepository(db).setPaid(id, true);
  } finally {
    await db.close();
  }
}

int? _expenseIdFromPayload(String? payload) {
  if (payload == null || !payload.startsWith('expense:')) return null;
  return int.tryParse(payload.substring('expense:'.length));
}

/// บริการแจ้งเตือนในเครื่อง (Asia/Bangkok) — ทำงานออฟไลน์ 100%
class NotificationService {
  NotificationService._();

  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _ready = false;

  /// เรียกเมื่อกด "จ่ายแล้ว" ตอนแอปเปิดอยู่ (ตั้งโดยชั้น UI)
  Future<void> Function(int expenseId)? onMarkPaid;

  bool get isSupported => !kIsWeb && Platform.isAndroid;

  Future<void> init() async {
    if (_ready || !isSupported) return;
    tzdata.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation('Asia/Bangkok'));

    await _plugin.initialize(
      const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      ),
      onDidReceiveNotificationResponse: (r) async {
        if (r.actionId == kPaidActionId) {
          final id = _expenseIdFromPayload(r.payload);
          if (id != null) await onMarkPaid?.call(id);
        }
      },
      onDidReceiveBackgroundNotificationResponse: notificationTapBackground,
    );
    _ready = true;
  }

  AndroidFlutterLocalNotificationsPlugin? get _android => _plugin
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

  /// ขอสิทธิ์แจ้งเตือน (Android 13+) และสิทธิ์ตั้งเตือนตรงเวลา
  Future<bool> requestPermissions() async {
    if (!isSupported) return false;
    await init();
    final granted = await _android?.requestNotificationsPermission();
    await _android?.requestExactAlarmsPermission();
    return granted ?? false;
  }

  Future<bool> notificationsEnabled() async {
    if (!isSupported) return false;
    await init();
    return (await _android?.areNotificationsEnabled()) ?? false;
  }

  Future<bool> canScheduleExact() async {
    if (!isSupported) return false;
    await init();
    return (await _android?.canScheduleExactNotifications()) ?? false;
  }

  NotificationDetails _expenseDetails() => const NotificationDetails(
        android: AndroidNotificationDetails(
          _expenseChannelId,
          'ใกล้ครบกำหนดจ่าย',
          channelDescription: 'เตือนก่อนถึงวันครบกำหนดจ่ายรายจ่าย',
          importance: Importance.high,
          priority: Priority.high,
          actions: [
            AndroidNotificationAction(
              kPaidActionId,
              'จ่ายแล้ว',
              showsUserInterface: false,
              cancelNotification: true,
            ),
          ],
        ),
      );

  NotificationDetails _paydayDetails() => const NotificationDetails(
        android: AndroidNotificationDetails(
          _paydayChannelId,
          'วันเงินเข้า',
          channelDescription: 'เตือนเมื่อถึงวันที่รายรับควรเข้า',
          importance: Importance.defaultImportance,
          priority: Priority.defaultPriority,
        ),
      );

  /// ส่งการแจ้งเตือนทดสอบทันที
  Future<void> showTest() async {
    if (!isSupported) return;
    await init();
    await _plugin.show(
      0,
      '🔔 ทดสอบการแจ้งเตือน',
      'Money Cal Saving พร้อมเตือนก่อนครบกำหนดจ่ายแล้ว',
      _paydayDetails(),
    );
  }

  Future<void> cancelAll() async {
    if (!isSupported) return;
    await init();
    await _plugin.cancelAll();
  }

  /// ตั้งการแจ้งเตือนใหม่ทั้งหมดจากข้อมูลปัจจุบัน (เรียกซ้ำได้ปลอดภัย)
  /// - รายจ่ายที่ยังไม่จ่าย: เตือนล่วงหน้า N วัน ตามเวลาที่ตั้ง (ตั้งต่อรายการประจำได้)
  /// - รายรับที่ยังไม่ได้รับ: เตือนในวันที่เงินควรเข้า
  Future<int> rescheduleAll(AppDatabase db) async {
    if (!isSupported) return 0;
    await init();
    await _plugin.cancelAll();

    final settings = await SettingsRepository(db).load();
    if (!await notificationsEnabled()) return 0;
    final exact = await canScheduleExact();
    final mode = exact
        ? AndroidScheduleMode.exactAllowWhileIdle
        : AndroidScheduleMode.inexactAllowWhileIdle;

    final now = tz.TZDateTime.now(tz.local);
    final thisMonth = AppDates.monthKey(DateTime.now());
    final nextMonth = AppDates.addMonths(thisMonth, 1);
    var scheduled = 0;

    // ให้แน่ใจว่ารายการประจำของเดือนนี้และเดือนหน้าถูกสร้างแล้ว
    final expenseRepo = ExpenseRepository(db);
    final incomeRepo = IncomeRepository(db);
    await expenseRepo.ensureRange(thisMonth, nextMonth);
    await incomeRepo.ensureRange(thisMonth, nextMonth);

    if (settings.notifyExpense) {
      final templates = {
        for (final t in await expenseRepo.getTemplates()) t.id: t,
      };
      for (final e in await expenseRepo.getUnpaid()) {
        if (scheduled >= _maxScheduled) break;
        final tpl = e.templateId == null ? null : templates[e.templateId!];
        final days = tpl?.remindDaysBefore ?? settings.remindDaysBefore;
        final time = _parseTime(tpl?.remindTime ?? settings.remindTime);

        final due = e.dueDate;
        final remindDay = DateTime(due.year, due.month, due.day - days);
        final when = tz.TZDateTime(
          tz.local,
          remindDay.year,
          remindDay.month,
          remindDay.day,
          time.$1,
          time.$2,
        );
        // เลยเวลาเตือนแล้ว ไม่ตั้งซ้ำ (จะเห็นในหน้าแรก/หน้าการแจ้งเตือนแทน)
        if (!when.isAfter(now)) continue;

        final dueText = AppDates.formatDayMonth(due);
        final body = days == 0
            ? '฿${Money.format(e.amountSatang)} ครบกำหนดวันนี้'
            : '฿${Money.format(e.amountSatang)} ครบกำหนด $dueText (อีก $days วัน)';
        await _plugin.zonedSchedule(
          e.id,
          '🧾 ${e.name}',
          body,
          when,
          _expenseDetails(),
          androidScheduleMode: mode,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
          payload: 'expense:${e.id}',
        );
        scheduled++;
      }
    }

    if (settings.notifyPayday) {
      final time = _parseTime(settings.remindTime);
      final entries = await incomeRepo.getRange(thisMonth, nextMonth);
      for (final e in entries) {
        if (scheduled >= _maxScheduled) break;
        if (e.isReceived || e.isSkipped) continue;
        final when = tz.TZDateTime(
          tz.local,
          e.date.year,
          e.date.month,
          e.date.day,
          time.$1,
          time.$2,
        );
        if (!when.isAfter(now)) continue;
        await _plugin.zonedSchedule(
          _incomeIdOffset + e.id,
          '💰 วันเงินเข้า: ${e.name}',
          'ถึงวันรับ ฿${Money.format(e.amountSatang)} แล้ว อย่าลืมบันทึกว่าได้รับ',
          when,
          _paydayDetails(),
          androidScheduleMode: mode,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
          payload: 'income:${e.id}',
        );
        scheduled++;
      }
    }
    return scheduled;
  }

  (int, int) _parseTime(String hhmm) {
    final parts = hhmm.split(':');
    final h = int.tryParse(parts.first) ?? 9;
    final m = int.tryParse(parts.length > 1 ? parts[1] : '0') ?? 0;
    return (h.clamp(0, 23), m.clamp(0, 59));
  }
}
