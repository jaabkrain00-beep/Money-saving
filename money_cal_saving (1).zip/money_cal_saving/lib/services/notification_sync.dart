import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/providers.dart';
import 'notification_service.dart';

/// ครอบแอปไว้เพื่อ
/// - ตั้งการแจ้งเตือนใหม่ทุกครั้งที่รายจ่ายค้างจ่าย/รายรับ/การตั้งค่าเปลี่ยน (หน่วงเล็กน้อยกันถี่)
/// - ตั้งใหม่ตอนเปิดแอป และรีเฟรชข้อมูลเมื่อกลับมา foreground
///   (กรณีกดปุ่ม "จ่ายแล้ว" บนการแจ้งเตือนขณะแอปปิด ซึ่งเขียนฐานข้อมูลจาก isolate อื่น)
class NotificationSync extends ConsumerStatefulWidget {
  const NotificationSync({super.key, required this.child});

  final Widget child;

  @override
  ConsumerState<NotificationSync> createState() => _NotificationSyncState();
}

class _NotificationSyncState extends ConsumerState<NotificationSync>
    with WidgetsBindingObserver {
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    final service = NotificationService.instance;
    service.onMarkPaid = (id) async {
      await ref.read(expenseRepositoryProvider).setPaid(id, true);
    };
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await service.init();
      _schedule(immediate: true);
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      final db = ref.read(databaseProvider);
      db.markTablesUpdated([db.expenseEntries, db.incomeEntries]);
      _schedule();
    }
  }

  void _schedule({bool immediate = false}) {
    _debounce?.cancel();
    _debounce = Timer(
      immediate ? Duration.zero : const Duration(milliseconds: 1200),
      () async {
        if (!mounted) return;
        try {
          await NotificationService.instance
              .rescheduleAll(ref.read(databaseProvider));
        } catch (e) {
          debugPrint('ตั้งการแจ้งเตือนไม่สำเร็จ: $e');
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    ref.listen(unpaidExpensesProvider, (_, __) => _schedule());
    ref.listen(allIncomeProvider, (_, __) => _schedule());
    ref.listen(expenseTemplatesProvider, (_, __) => _schedule());
    ref.listen(
      settingsProvider.select(
        (s) => (s.notifyExpense, s.notifyPayday, s.remindDaysBefore, s.remindTime),
      ),
      (_, __) => _schedule(),
    );
    return widget.child;
  }
}
