import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:local_auth/local_auth.dart';

import '../data/repositories/settings_repository.dart';
import '../data/settings_keys.dart';

/// PIN 4 หลัก (เก็บเป็น SHA-256 + salt ไม่เก็บตัวเลขจริง) และสแกนนิ้วมือ/ใบหน้า
class PinService {
  PinService(this._settings);

  final SettingsRepository _settings;
  final LocalAuthentication _auth = LocalAuthentication();

  static const int pinLength = 4;

  static String _hash(String salt, String pin) =>
      sha256.convert(utf8.encode('$salt:$pin')).toString();

  static String _newSalt() {
    final r = Random.secure();
    return base64UrlEncode([for (var i = 0; i < 16; i++) r.nextInt(256)]);
  }

  Future<void> setPin(String pin) async {
    final salt = _newSalt();
    await _settings.setString(SettingKeys.pinSalt, salt);
    await _settings.setString(SettingKeys.pinHash, _hash(salt, pin));
  }

  Future<bool> verify(String pin) async {
    final salt = await _settings.getString(SettingKeys.pinSalt);
    final hash = await _settings.getString(SettingKeys.pinHash);
    if (salt == null || hash == null || hash.isEmpty) return false;
    return _hash(salt, pin) == hash;
  }

  Future<void> clearPin() async {
    await _settings.remove(SettingKeys.pinHash);
    await _settings.remove(SettingKeys.pinSalt);
    await _settings.setBool(SettingKeys.biometric, false);
  }

  Future<bool> biometricAvailable() async {
    try {
      return await _auth.canCheckBiometrics && await _auth.isDeviceSupported();
    } catch (_) {
      return false;
    }
  }

  Future<bool> authenticateBiometric() async {
    try {
      return await _auth.authenticate(
        localizedReason: 'ยืนยันตัวตนเพื่อเปิด Money Cal Saving',
        options: const AuthenticationOptions(
          biometricOnly: true,
          stickyAuth: true,
        ),
      );
    } catch (e) {
      debugPrint('biometric error: $e');
      return false;
    }
  }
}
