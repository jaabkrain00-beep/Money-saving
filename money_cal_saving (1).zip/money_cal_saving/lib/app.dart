import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/theme/app_theme.dart';
import 'features/lock/lock_gate.dart';
import 'features/shell/app_shell.dart';
import 'providers/providers.dart';
import 'services/notification_sync.dart';
import 'widgets/widgets.dart';

/// รากของแอป: ธีมพาสเทล + Dark mode ตามการตั้งค่า + ภาษาไทย + พื้นหลังกลาง
class MoneyCalApp extends ConsumerWidget {
  const MoneyCalApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(settingsProvider.select((s) => s.themeMode));

    return MaterialApp(
      title: 'Money Cal Saving',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: themeMode,
      locale: const Locale('th', 'TH'),
      supportedLocales: const [Locale('th', 'TH')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) => AppBackground(
        child: NotificationSync(
          child: LockGate(child: child ?? const SizedBox()),
        ),
      ),
      home: const AppShell(),
    );
  }
}
