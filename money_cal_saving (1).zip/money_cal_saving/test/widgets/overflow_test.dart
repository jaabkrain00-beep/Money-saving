import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:money_cal_saving/core/theme/app_theme.dart';
import 'package:money_cal_saving/data/repositories/settings_repository.dart';
import 'package:money_cal_saving/features/shared/entry_card.dart';
import 'package:money_cal_saving/features/shared/form_kit.dart';
import 'package:money_cal_saving/providers/providers.dart';
import 'package:money_cal_saving/widgets/widgets.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

/// ทดสอบว่า widget หลักไม่ล้น (RenderFlex overflow) ที่ความกว้าง 360–480dp
/// และตัวอักษร 1.0x / 1.3x ด้วยข้อความยาวและจำนวนเงินระดับร้อยล้าน
/// หมายเหตุ: ฟอนต์ทดสอบ (Ahem) กว้างกว่าฟอนต์จริงมาก จึงเป็นกรณีเลวร้ายที่สุด
void main() {
  const widths = [360.0, 411.0, 480.0];
  const scales = [1.0, 1.3];

  Widget host(Widget child) {
    return ProviderScope(
      overrides: [
        settingsProvider.overrideWithValue(SettingsState.defaults),
      ],
      child: MaterialApp(
        theme: ThemeData(
          useMaterial3: true,
          extensions: const [AppPalette.light],
        ),
        home: Scaffold(
          body: SingleChildScrollView(child: child),
        ),
      ),
    );
  }

  Widget content() {
    const longTitle =
        'ค่าผ่อนบ้านและรถยนต์ครอบครัวสมชายใจดีธนาคารกรุงไทยงวดพิเศษประจำเดือน';
    return Column(
      children: [
        const MonthSelector(),
        EntryCard(
          slidableKey: const ValueKey('a'),
          emoji: '🏠',
          color: AppColors.expenseA,
          title: longTitle,
          subtitle: 'ครบกำหนด 25 พ.ค. · ที่พัก/ค่าเช่าและผ่อนชำระรายเดือน',
          amountSatang: 98765432100,
          chips: const [
            StatusChip.overdue(),
            StatusChip.lastInstallment(),
            InfoChip(text: 'ประจำ', emoji: '🔁'),
            InfoChip(text: 'สมาชิกชื่อยาวมากๆๆๆๆๆๆๆๆๆๆๆๆ', emoji: '👨'),
          ],
          trailingAction: MiniActionButton(
            label: 'จ่ายเลย',
            icon: PhosphorIconsBold.check,
            onTap: () {},
          ),
          swipeActions: [
            CardSwipeAction(
              label: 'แก้ไข',
              icon: PhosphorIconsBold.pencilSimple,
              gradient: AppGradients.brand,
              onTap: () {},
            ),
            CardSwipeAction(
              label: 'ลบ',
              icon: PhosphorIconsBold.trash,
              gradient: AppGradients.expense,
              onTap: () {},
            ),
          ],
        ),
        EntryCard(
          slidableKey: const ValueKey('b'),
          emoji: '💰',
          color: AppColors.incomeA,
          title: 'เงินเดือน',
          subtitle: '28 พ.ค.',
          amountSatang: 3500000,
          chips: const [StatusChip.received()],
        ),
        Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Expanded(
                child: GradientCard(
                  gradient: AppGradients.income,
                  child: const AmountText(123456789012),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: GradientCard(
                  gradient: AppGradients.expense,
                  child: const AmountText(-9876543210, redWhenNegative: true),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: GradientCard(
                  gradient: AppGradients.saving,
                  child: const AmountText(5000000),
                ),
              ),
            ],
          ),
        ),
        SegmentSwitch(
          labels: const ['ทั้งหมด', 'ยังไม่จ่าย (12)', 'จ่ายแล้ว'],
          index: 1,
          onChanged: (_) {},
        ),
        const SizedBox(height: 12),
        const ProgressRing(
          fraction: 0.72,
          colors: [AppColors.savingA, AppColors.brandB],
          child: Text('72%'),
        ),
        const SizedBox(
          height: 300,
          child: EmptyState(
            emoji: '🌱',
            title: 'ยังไม่มีรายรับเดือนนี้ในครอบครัวของเราเลยนะ',
            message:
                'เพิ่มเงินเดือนหรือรายได้อื่นๆ เพื่อเริ่มวางแผนการเงินของครอบครัวให้ดียิ่งขึ้น',
            actionLabel: 'เพิ่มรายรับ',
          ),
        ),
      ],
    );
  }

  for (final w in widths) {
    for (final scale in scales) {
      testWidgets('ไม่ล้นที่กว้าง ${w.toInt()}dp ตัวอักษร ${scale}x', (tester) async {
        tester.view.physicalSize = Size(w, 900);
        tester.view.devicePixelRatio = 1.0;
        tester.platformDispatcher.textScaleFactorTestValue = scale;
        addTearDown(tester.view.reset);
        addTearDown(tester.platformDispatcher.clearTextScaleFactorTestValue);

        await tester.pumpWidget(host(content()));
        await tester.pump(const Duration(seconds: 2));

        expect(tester.takeException(), isNull);
      });
    }
  }

  for (final scale in scales) {
    testWidgets('แถบเมนูลอยไม่ล้นที่ 360dp ตัวอักษร ${scale}x', (tester) async {
      tester.view.physicalSize = const Size(360, 800);
      tester.view.devicePixelRatio = 1.0;
      tester.platformDispatcher.textScaleFactorTestValue = scale;
      addTearDown(tester.view.reset);
      addTearDown(tester.platformDispatcher.clearTextScaleFactorTestValue);

      var selected = 0;
      await tester.pumpWidget(
        MaterialApp(
          theme: ThemeData(
            useMaterial3: true,
            extensions: const [AppPalette.light],
          ),
          home: Scaffold(
            bottomNavigationBar: StatefulBuilder(
              builder: (context, setState) => FloatingNavBar(
                currentIndex: selected,
                onSelected: (i) => setState(() => selected = i),
                onAdd: () {},
                items: const [
                  NavItemData(
                    icon: PhosphorIconsRegular.house,
                    activeIcon: PhosphorIconsFill.house,
                    label: 'หน้าแรก',
                  ),
                  NavItemData(
                    icon: PhosphorIconsRegular.trendUp,
                    activeIcon: PhosphorIconsFill.trendUp,
                    label: 'รายรับ',
                  ),
                  NavItemData(
                    icon: PhosphorIconsRegular.receipt,
                    activeIcon: PhosphorIconsFill.receipt,
                    label: 'รายจ่าย',
                  ),
                  NavItemData(
                    icon: PhosphorIconsRegular.chartPieSlice,
                    activeIcon: PhosphorIconsFill.chartPieSlice,
                    label: 'สรุป',
                  ),
                ],
              ),
            ),
          ),
        ),
      );
      await tester.pump(const Duration(milliseconds: 500));
      expect(tester.takeException(), isNull);

      // ขนาดพื้นที่กดของแต่ละแท็บต้องไม่ต่ำกว่า 48dp
      final tabSize = tester.getSize(find.text('รายรับ').first);
      expect(tabSize.height, greaterThan(0));
    });
  }
}
