import 'package:flutter_test/flutter_test.dart';
import 'package:money_cal_saving/data/db/app_database.dart';
import 'package:money_cal_saving/domain/goal_calculator.dart';

import '../support/fixtures.dart';

void main() {
  group('balance (ฝาก - ถอน)', () {
    test('ยอดสุทธิของเป้าหมาย', () {
      final txs = [
        savingTx(id: 1, amount: 100000, type: SavingTxType.deposit),
        savingTx(id: 2, amount: 50000, type: SavingTxType.deposit),
        savingTx(id: 3, amount: 30000, type: SavingTxType.withdraw),
      ];
      expect(GoalCalculator.balance(txs), 120000);
    });

    test('ไม่มีรายการเป็น 0', () {
      expect(GoalCalculator.balance(const []), 0);
    });
  });

  group('progress', () {
    test('คิดเปอร์เซ็นต์และยอดที่ยังขาด', () {
      final p = GoalCalculator.progress(saved: 250000, target: 1000000);
      expect(p.percent, 25);
      expect(p.remaining, 750000);
      expect(p.isReached, isFalse);
      expect(p.fraction, closeTo(0.25, 1e-9));
    });

    test('ยังไม่ครบ แม้เกือบ 100% ต้องแสดง 99 ไม่ปัดเป็น 100', () {
      final p = GoalCalculator.progress(saved: 999999, target: 1000000);
      expect(p.percent, 99);
      expect(p.isReached, isFalse);
      expect(p.remaining, 1);
    });

    test('ครบพอดีและเกินเป้าหมาย', () {
      final exact = GoalCalculator.progress(saved: 1000000, target: 1000000);
      expect(exact.isReached, isTrue);
      expect(exact.percent, 100);
      expect(exact.remaining, 0);

      final over = GoalCalculator.progress(saved: 1500000, target: 1000000);
      expect(over.isReached, isTrue);
      expect(over.percent, 100);
      expect(over.remaining, 0);
      expect(over.fraction, 1);
    });

    test('ยอดออมเป็น 0 หรือติดลบ', () {
      expect(GoalCalculator.progress(saved: 0, target: 1000).percent, 0);
      expect(GoalCalculator.progress(saved: -500, target: 1000).percent, 0);
      expect(GoalCalculator.progress(saved: -500, target: 1000).fraction, 0);
    });
  });

  group('shouldBeCompleted', () {
    test('ครบเป้าหมายแล้วสำเร็จ ถอนจนต่ำกว่าเป้าหมายกลับเป็นยังไม่สำเร็จ', () {
      expect(GoalCalculator.shouldBeCompleted(saved: 1000, target: 1000), isTrue);
      expect(GoalCalculator.shouldBeCompleted(saved: 999, target: 1000), isFalse);
      expect(GoalCalculator.shouldBeCompleted(saved: 0, target: 0), isFalse);
    });
  });

  group('monthlyPlan (ต้องออมเดือนละเท่าไร)', () {
    test('ไม่ได้กำหนดวันที่ ไม่มีแผนรายเดือน', () {
      expect(
        GoalCalculator.monthlyPlan(
          remaining: 750000,
          targetDate: null,
          today: DateTime(2025, 12, 15),
        ),
        isNull,
      );
    });

    test('นับรวมเดือนปัจจุบัน: ธ.ค. -> ก.พ. = 3 เดือน', () {
      final plan = GoalCalculator.monthlyPlan(
        remaining: 750000,
        targetDate: DateTime(2026, 2, 28),
        today: DateTime(2025, 12, 15),
      )!;
      expect(plan.months, 3);
      expect(plan.perMonthSatang, 250000);
      expect(plan.overdue, isFalse);
    });

    test('หารไม่ลงตัวปัดขึ้น เพื่อให้ทันกำหนด', () {
      final plan = GoalCalculator.monthlyPlan(
        remaining: 100,
        targetDate: DateTime(2026, 2, 28),
        today: DateTime(2025, 12, 15),
      )!;
      expect(plan.perMonthSatang, 34); // 100 / 3 = 33.33 -> 34
      expect(plan.perMonthSatang * plan.months >= 100, isTrue);
    });

    test('เดือนเดียวกับวันที่ต้องการ = ต้องออมทั้งหมดในเดือนนี้', () {
      final plan = GoalCalculator.monthlyPlan(
        remaining: 500000,
        targetDate: DateTime(2025, 12, 31),
        today: DateTime(2025, 12, 15),
      )!;
      expect(plan.months, 1);
      expect(plan.perMonthSatang, 500000);
    });

    test('เลยวันที่ต้องการแล้ว', () {
      final plan = GoalCalculator.monthlyPlan(
        remaining: 500000,
        targetDate: DateTime(2025, 1, 1),
        today: DateTime(2025, 3, 1),
      )!;
      expect(plan.overdue, isTrue);
      expect(plan.months, 1);
      expect(plan.perMonthSatang, 500000);
    });

    test('ครบเป้าหมายแล้ว (ไม่เหลือ) ไม่ต้องออมเพิ่มและไม่ถือว่าเลยกำหนด', () {
      final plan = GoalCalculator.monthlyPlan(
        remaining: 0,
        targetDate: DateTime(2025, 1, 1),
        today: DateTime(2025, 3, 1),
      )!;
      expect(plan.perMonthSatang, 0);
      expect(plan.overdue, isFalse);
    });
  });
}
