import 'package:flutter_test/flutter_test.dart';
import 'package:money_cal_saving/domain/status_rules.dart';

void main() {
  final today = DateTime(2025, 5, 10);

  group('ExpenseRules.status', () {
    ExpenseStatus at(DateTime due, {bool paid = false}) =>
        ExpenseRules.status(isPaid: paid, dueDate: due, today: today);

    test('จ่ายแล้วเป็น paid เสมอ แม้เลยกำหนด', () {
      expect(at(DateTime(2025, 5, 1), paid: true), ExpenseStatus.paid);
    });

    test('เลยกำหนด', () {
      expect(at(DateTime(2025, 5, 9)), ExpenseStatus.overdue);
    });

    test('ใกล้ครบกำหนดภายใน 3 วัน (รวมวันนี้)', () {
      expect(at(DateTime(2025, 5, 10)), ExpenseStatus.dueSoon);
      expect(at(DateTime(2025, 5, 13)), ExpenseStatus.dueSoon);
    });

    test('มากกว่า 3 วันยังเป็น "ยังไม่จ่าย"', () {
      expect(at(DateTime(2025, 5, 14)), ExpenseStatus.unpaid);
    });

    test('เวลาในวันไม่มีผล (เทียบเฉพาะวันที่)', () {
      final lateToday = DateTime(2025, 5, 10, 23, 59);
      expect(
        ExpenseRules.status(
          isPaid: false,
          dueDate: DateTime(2025, 5, 10, 0, 1),
          today: lateToday,
        ),
        ExpenseStatus.dueSoon,
      );
    });
  });

  group('ExpenseRules.bucket', () {
    DueBucket at(DateTime due) =>
        ExpenseRules.bucket(dueDate: due, today: today);

    test('แบ่งช่วง เลยกำหนด / วันนี้ / สัปดาห์นี้ / หลังจากนั้น', () {
      expect(at(DateTime(2025, 5, 9)), DueBucket.overdue);
      expect(at(DateTime(2025, 5, 10)), DueBucket.today);
      expect(at(DateTime(2025, 5, 11)), DueBucket.thisWeek);
      expect(at(DateTime(2025, 5, 17)), DueBucket.thisWeek);
      expect(at(DateTime(2025, 5, 18)), DueBucket.later);
    });
  });

  group('IncomeRules.needsConfirmation', () {
    test('ถึงวันเงินเข้าแล้วแต่ยังไม่ยืนยัน ต้องถาม', () {
      expect(
        IncomeRules.needsConfirmation(
          isReceived: false,
          date: DateTime(2025, 5, 10),
          today: today,
        ),
        isTrue,
      );
      expect(
        IncomeRules.needsConfirmation(
          isReceived: false,
          date: DateTime(2025, 5, 1),
          today: today,
        ),
        isTrue,
      );
    });

    test('ยังไม่ถึงวัน หรือได้รับแล้ว ไม่ต้องถาม', () {
      expect(
        IncomeRules.needsConfirmation(
          isReceived: false,
          date: DateTime(2025, 5, 11),
          today: today,
        ),
        isFalse,
      );
      expect(
        IncomeRules.needsConfirmation(
          isReceived: true,
          date: DateTime(2025, 5, 1),
          today: today,
        ),
        isFalse,
      );
    });
  });
}
