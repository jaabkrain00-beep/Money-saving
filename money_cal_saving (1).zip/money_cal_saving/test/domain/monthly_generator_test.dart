import 'package:flutter_test/flutter_test.dart';
import 'package:money_cal_saving/domain/monthly_generator.dart';
import 'package:money_cal_saving/domain/summary_calculator.dart';
import 'package:money_cal_saving/domain/template_rules.dart';

import '../support/fixtures.dart';

void main() {
  group('วันที่เงินเข้า/ครบกำหนดเกินจำนวนวันของเดือน', () {
    test('วันที่ 31 ในเดือนที่มี 30 วัน ใช้วันที่ 30', () {
      final created = MonthlyGenerator.incomeToCreate(
        monthKey: '2025-04',
        templates: [incomeTemplate(day: 31)],
        existingTemplateIds: {},
      );
      expect(created, hasLength(1));
      expect(created.single.date.value, DateTime(2025, 4, 30));
    });

    test('วันที่ 31 ในเดือนที่มี 31 วัน ใช้วันที่ 31', () {
      final created = MonthlyGenerator.incomeToCreate(
        monthKey: '2025-01',
        templates: [incomeTemplate(day: 31)],
        existingTemplateIds: {},
      );
      expect(created.single.date.value, DateTime(2025, 1, 31));
    });

    test('ปีอธิกสุรทิน: ก.พ. 2024 = 29, ก.พ. 2025 = 28', () {
      final leap = MonthlyGenerator.expenseToCreate(
        monthKey: '2024-02',
        templates: [expenseTemplate(day: 31, start: '2024-01')],
        existingTemplateIds: {},
      );
      final normal = MonthlyGenerator.expenseToCreate(
        monthKey: '2025-02',
        templates: [expenseTemplate(day: 31)],
        existingTemplateIds: {},
      );
      expect(leap.single.dueDate.value, DateTime(2024, 2, 29));
      expect(normal.single.dueDate.value, DateTime(2025, 2, 28));
    });
  });

  group('ช่วง startMonth - endMonth', () {
    test('ยังไม่ถึงเดือนเริ่มต้น ไม่สร้าง', () {
      final created = MonthlyGenerator.incomeToCreate(
        monthKey: '2025-05',
        templates: [incomeTemplate(start: '2025-06')],
        existingTemplateIds: {},
      );
      expect(created, isEmpty);
    });

    test('การปิดยอดกลางเดือน: เดือนปิดยังสร้าง เดือนถัดไปไม่สร้าง', () {
      final template = expenseTemplate(end: '2025-05');

      final may = MonthlyGenerator.expenseToCreate(
        monthKey: '2025-05',
        templates: [template],
        existingTemplateIds: {},
      );
      final june = MonthlyGenerator.expenseToCreate(
        monthKey: '2025-06',
        templates: [template],
        existingTemplateIds: {},
      );

      expect(may, hasLength(1));
      expect(june, isEmpty);
      expect(
        TemplateRules.isFinalMonth('2025-05',
            startMonth: template.startMonth, endMonth: template.endMonth),
        isTrue,
      );
    });

    test('ยกเลิกการปิดยอด (endMonth = null) กลับมาสร้างต่อ', () {
      final reopened = expenseTemplate(end: null);
      final june = MonthlyGenerator.expenseToCreate(
        monthKey: '2025-06',
        templates: [reopened],
        existingTemplateIds: {},
      );
      expect(june, hasLength(1));
    });

    test('ผ่อนชำระ 3 งวด: สร้างครบ 3 เดือนแล้วหยุดเอง', () {
      final template = expenseTemplate(installments: 3);
      int count(String month) => MonthlyGenerator.expenseToCreate(
            monthKey: month,
            templates: [template],
            existingTemplateIds: {},
          ).length;

      expect(count('2024-12'), 0);
      expect(count('2025-01'), 1);
      expect(count('2025-02'), 1);
      expect(count('2025-03'), 1);
      expect(count('2025-04'), 0);
    });
  });

  group('ห้ามสร้างซ้ำ', () {
    test('ข้ามแม่แบบที่มี instance ในเดือนนั้นแล้ว', () {
      final created = MonthlyGenerator.incomeToCreate(
        monthKey: '2025-05',
        templates: [
          incomeTemplate(id: 1),
          incomeTemplate(id: 2, name: 'โบนัสประจำ'),
        ],
        existingTemplateIds: {1},
      );
      expect(created, hasLength(1));
      expect(created.single.templateId.value, 2);
    });

    test('รายการที่ถูกลบเฉพาะเดือน (tombstone) ไม่ถูกสร้างใหม่', () {
      final tombstone = expenseEntry(templateId: 1, skipped: true);
      final existing = MonthlyGenerator.expenseTemplateIds([tombstone]);
      expect(existing, {1});

      final created = MonthlyGenerator.expenseToCreate(
        monthKey: '2025-05',
        templates: [expenseTemplate(id: 1)],
        existingTemplateIds: existing,
      );
      expect(created, isEmpty);
    });

    test('รายการจร (ไม่มี templateId) ไม่นับเป็นแม่แบบที่มีอยู่', () {
      final oneTime = expenseEntry(templateId: null, oneTime: true, amount: 100);
      expect(MonthlyGenerator.expenseTemplateIds([oneTime]), isEmpty);
    });
  });

  group('ค่าที่คัดลอกจากแม่แบบและสถานะเริ่มต้น', () {
    test('รายรับ: คัดลอกข้อมูลครบ และยังไม่ถูกตั้งเป็น "ได้รับแล้ว"', () {
      final t = incomeTemplate(
        id: 7,
        name: 'เงินเดือนแม่',
        amount: 2550075,
        memberId: 3,
        categoryId: 2,
        note: 'โอนเข้าบัญชีออมสิน',
      );
      final c = MonthlyGenerator.incomeToCreate(
        monthKey: '2025-05',
        templates: [t],
        existingTemplateIds: {},
      ).single;

      expect(c.templateId.value, 7);
      expect(c.name.value, 'เงินเดือนแม่');
      expect(c.amountSatang.value, 2550075);
      expect(c.memberId.value, 3);
      expect(c.categoryId.value, 2);
      expect(c.note.value, 'โอนเข้าบัญชีออมสิน');
      expect(c.monthKey.value, '2025-05');
      expect(c.isReceived.present, isFalse); // ใช้ค่าเริ่มต้นของตาราง = false
    });

    test('รายจ่าย: เริ่มต้นเป็น "ยังไม่จ่าย" เสมอ แม้เดือนก่อนจ่ายแล้ว', () {
      final c = MonthlyGenerator.expenseToCreate(
        monthKey: '2025-06',
        templates: [expenseTemplate(id: 4)],
        existingTemplateIds: {},
      ).single;
      expect(c.isPaid.present, isFalse);
      expect(c.paidAt.present, isFalse);
      expect(c.templateId.value, 4);
    });
  });

  group('การแก้ยอดเฉพาะเดือน', () {
    test('เดือนที่แก้ใช้ยอดใหม่ เดือนอื่นที่สร้างจากแม่แบบยังใช้ยอดเดิม', () {
      final template = expenseTemplate(id: 1, amount: 500000);

      // ผู้ใช้แก้ยอดเฉพาะเดือน พ.ค. เป็น 6,000.00 (instance เก็บยอดของตัวเอง)
      final mayEdited = expenseEntry(
        templateId: 1,
        amount: 600000,
        month: '2025-05',
      );

      final june = MonthlyGenerator.expenseToCreate(
        monthKey: '2025-06',
        templates: [template],
        existingTemplateIds: {},
      ).single;

      final maySummary = SummaryCalculator.compute(
        monthKey: '2025-05',
        income: const [],
        expenses: [mayEdited],
        savings: const [],
      );

      expect(maySummary.expenseTotal, 600000);
      expect(june.amountSatang.value, 500000);
    });
  });
}
