import 'package:flutter_test/flutter_test.dart';
import 'package:money_cal_saving/domain/template_rules.dart';

void main() {
  group('effectiveEndMonth', () {
    test('ไม่มีกำหนดสิ้นสุด', () {
      expect(TemplateRules.effectiveEndMonth(startMonth: '2025-01'), isNull);
    });

    test('นับจากจำนวนงวด (เริ่ม ม.ค. 10 งวด -> ต.ค.)', () {
      expect(
        TemplateRules.effectiveEndMonth(
          startMonth: '2025-01',
          totalInstallments: 10,
        ),
        '2025-10',
      );
      expect(
        TemplateRules.effectiveEndMonth(
          startMonth: '2025-11',
          totalInstallments: 3,
        ),
        '2026-01',
      );
    });

    test('ปิดยอดด้วยมือ', () {
      expect(
        TemplateRules.effectiveEndMonth(
          startMonth: '2025-01',
          endMonth: '2025-05',
        ),
        '2025-05',
      );
    });

    test('มีทั้งสองอย่าง ใช้เดือนที่มาถึงก่อน', () {
      expect(
        TemplateRules.effectiveEndMonth(
          startMonth: '2025-01',
          endMonth: '2025-05',
          totalInstallments: 10,
        ),
        '2025-05',
      );
      expect(
        TemplateRules.effectiveEndMonth(
          startMonth: '2025-01',
          endMonth: '2025-12',
          totalInstallments: 10,
        ),
        '2025-10',
      );
    });

    test('จำนวนงวด 0 ถือว่าไม่กำหนด', () {
      expect(
        TemplateRules.effectiveEndMonth(
          startMonth: '2025-01',
          totalInstallments: 0,
        ),
        isNull,
      );
    });
  });

  group('isActiveIn', () {
    test('ก่อนเดือนเริ่มต้นไม่ active', () {
      expect(
        TemplateRules.isActiveIn('2024-12', startMonth: '2025-01'),
        isFalse,
      );
    });

    test('เดือนเริ่มต้นและเดือนสุดท้ายรวมอยู่ด้วย', () {
      expect(TemplateRules.isActiveIn('2025-01', startMonth: '2025-01'), isTrue);
      expect(
        TemplateRules.isActiveIn('2025-05',
            startMonth: '2025-01', endMonth: '2025-05'),
        isTrue,
      );
    });

    test('หลังเดือนสุดท้ายไม่ active (การปิดยอดกลางเดือน)', () {
      expect(
        TemplateRules.isActiveIn('2025-06',
            startMonth: '2025-01', endMonth: '2025-05'),
        isFalse,
      );
    });

    test('ไม่มีวันสิ้นสุด active ตลอด', () {
      expect(TemplateRules.isActiveIn('2040-01', startMonth: '2025-01'), isTrue);
    });

    test('ครบงวดแล้วหยุดอัตโนมัติ', () {
      expect(
        TemplateRules.isActiveIn('2025-10',
            startMonth: '2025-01', totalInstallments: 10),
        isTrue,
      );
      expect(
        TemplateRules.isActiveIn('2025-11',
            startMonth: '2025-01', totalInstallments: 10),
        isFalse,
      );
    });
  });

  test('installmentNumber', () {
    expect(TemplateRules.installmentNumber('2025-01', '2025-01'), 1);
    expect(TemplateRules.installmentNumber('2025-01', '2025-03'), 3);
    expect(TemplateRules.installmentNumber('2025-11', '2026-02'), 4);
  });

  group('isFinalMonth', () {
    test('ครบงวดพอดี', () {
      expect(
        TemplateRules.isFinalMonth('2025-03',
            startMonth: '2025-01', totalInstallments: 3),
        isTrue,
      );
      expect(
        TemplateRules.isFinalMonth('2025-02',
            startMonth: '2025-01', totalInstallments: 3),
        isFalse,
      );
    });

    test('ปิดยอดด้วยมือ -> เดือนนั้นเป็นงวดสุดท้าย', () {
      expect(
        TemplateRules.isFinalMonth('2025-05',
            startMonth: '2025-01', endMonth: '2025-05'),
        isTrue,
      );
    });

    test('ไม่มีกำหนดสิ้นสุด ไม่เคยเป็นงวดสุดท้าย', () {
      expect(
        TemplateRules.isFinalMonth('2025-05', startMonth: '2025-01'),
        isFalse,
      );
    });
  });
}
