import 'package:drift/drift.dart' show Value;
import 'package:flutter_test/flutter_test.dart';
import 'package:money_cal_saving/core/utils/money.dart';
import 'package:money_cal_saving/data/db/app_database.dart';
import 'package:money_cal_saving/domain/summary_calculator.dart';

import '../support/fixtures.dart';

void main() {
  const may = '2025-05';

  // ชุดข้อมูลตัวอย่างของเดือน พ.ค. 2568 (ตัวเลขเป็นสตางค์)
  final income = [
    incomeEntry(id: 1, amount: 3000000, received: true, memberId: 1),
    incomeEntry(id: 2, amount: 500050, received: false, memberId: 2, oneTime: true),
    incomeEntry(id: 3, amount: 999999, skipped: true, memberId: 1), // ถูกลบเฉพาะเดือน
    incomeEntry(id: 4, amount: 777, month: '2025-04', memberId: 1), // คนละเดือน
  ];
  final expenses = [
    expenseEntry(id: 1, amount: 800000, paid: true, memberId: 1),
    expenseEntry(id: 2, amount: 123456, paid: false, memberId: 1),
    expenseEntry(id: 3, amount: 15025, paid: true, memberId: 2, oneTime: true),
    expenseEntry(id: 4, amount: 50000, skipped: true, memberId: 1),
  ];
  final savings = [
    savingTx(id: 1, amount: 200000, type: SavingTxType.deposit),
    savingTx(id: 2, amount: 50000, type: SavingTxType.withdraw),
    savingTx(id: 3, amount: 100000, type: SavingTxType.deposit, month: '2025-04'),
  ];

  group('สูตรต่อเดือน', () {
    test('รายรับ/รายจ่าย/ออม/คงเหลือ ถูกต้องและไม่นับรายการที่ข้ามหรือคนละเดือน', () {
      final s = SummaryCalculator.compute(
        monthKey: may,
        income: income,
        expenses: expenses,
        savings: savings,
      );

      expect(s.incomeTotal, 3500050);
      expect(s.incomeReceived, 3000000);
      expect(s.incomePending, 500050);
      expect(s.expenseTotal, 938481);
      expect(s.expensePaid, 815025);
      expect(s.expenseUnpaid, 123456);
      expect(s.savings, 150000);
      expect(s.balancePlanned, 2411569);
      expect(s.balanceNow, 2034975);
    });

    test('เงินออมไม่นับเป็นรายจ่าย แต่หักออกจากคงเหลือ', () {
      final s = SummaryCalculator.compute(
        monthKey: may,
        income: [incomeEntry(amount: 1000000, received: true)],
        expenses: const [],
        savings: [savingTx(amount: 300000, type: SavingTxType.deposit)],
      );
      expect(s.expenseTotal, 0);
      expect(s.savings, 300000);
      expect(s.balancePlanned, 700000);
      expect(s.balanceNow, 700000);
    });

    test('เดือนที่ไม่มีข้อมูลเป็นศูนย์ทั้งหมด', () {
      final s = SummaryCalculator.compute(
        monthKey: '2030-01',
        income: income,
        expenses: expenses,
        savings: savings,
      );
      expect(s.incomeTotal, 0);
      expect(s.expenseTotal, 0);
      expect(s.savings, 0);
      expect(s.balancePlanned, 0);
      expect(s.balanceNow, 0);
    });

    test('ติดลบได้ (ใช้แสดงคำเตือนสีแดง)', () {
      final s = SummaryCalculator.compute(
        monthKey: may,
        income: [incomeEntry(amount: 100000, received: true)],
        expenses: [expenseEntry(amount: 250000, paid: true)],
        savings: const [],
      );
      expect(s.balancePlanned, -150000);
      expect(s.balanceNow, -150000);
    });
  });

  group('ฝากและถอนเงินออม', () {
    test('ยอดสุทธิ = ฝาก - ถอน และนับตามเดือนของรายการ', () {
      expect(SummaryCalculator.savingsNet(savings), 250000);

      final aprilOnly = SummaryCalculator.compute(
        monthKey: '2025-04',
        income: const [],
        expenses: const [],
        savings: savings,
      );
      expect(aprilOnly.savings, 100000);
    });

    test('ถอนมากกว่าฝากในเดือนนั้น เงินออมของเดือนติดลบและคืนเงินเข้าคงเหลือ', () {
      final s = SummaryCalculator.compute(
        monthKey: may,
        income: [incomeEntry(amount: 500000, received: true)],
        expenses: const [],
        savings: [savingTx(amount: 200000, type: SavingTxType.withdraw)],
      );
      expect(s.savings, -200000);
      expect(s.balanceNow, 700000);
    });
  });

  group('ยอดเงินหลักล้านที่มีสตางค์', () {
    test('ผลรวมไม่คลาดเคลื่อน', () {
      final s = SummaryCalculator.compute(
        monthKey: may,
        income: [
          incomeEntry(id: 1, amount: 100000001, received: true),
          incomeEntry(id: 2, amount: 23456788, received: true),
        ],
        expenses: [expenseEntry(amount: 99999999, paid: true)],
        savings: const [],
      );
      expect(s.incomeTotal, 123456789);
      expect(Money.format(s.incomeTotal), '1,234,567.89');
      expect(s.balancePlanned, 23456790);
      expect(Money.format(s.balancePlanned), '234,567.90');
    });

    test('บวก 0.01 บาทหลายพันครั้งแล้วต้องเท่ากับค่าที่คาด (ไม่มี floating point)', () {
      final many = [
        for (var i = 0; i < 10000; i++) incomeEntry(id: i, amount: 1, received: true),
      ];
      final s = SummaryCalculator.compute(
        monthKey: may,
        income: many,
        expenses: const [],
        savings: const [],
      );
      expect(s.incomeTotal, 10000);
      expect(Money.format(s.incomeTotal), '100.00');
    });
  });

  group('ตัวกรองสมาชิก', () {
    test('เฉพาะรายคน (เงินออมกรองตามเจ้าของเป้าหมาย)', () {
      final m1 = SummaryCalculator.compute(
        monthKey: may,
        income: income,
        expenses: expenses,
        savings: savings,
        memberId: 1,
        goalOwners: const {1: 1},
      );
      expect(m1.incomeTotal, 3000000);
      expect(m1.incomeReceived, 3000000);
      expect(m1.expenseTotal, 923456);
      expect(m1.expensePaid, 800000);
      expect(m1.savings, 150000);

      final m2 = SummaryCalculator.compute(
        monthKey: may,
        income: income,
        expenses: expenses,
        savings: savings,
        memberId: 2,
        goalOwners: const {1: 1},
      );
      expect(m2.incomeTotal, 500050);
      expect(m2.incomeReceived, 0);
      expect(m2.expenseTotal, 15025);
      expect(m2.savings, 0);
      expect(m2.balancePlanned, 485025);
      expect(m2.balanceNow, -15025);
    });

    test('การลบสมาชิก (ย้ายไปส่วนกลาง): ยอดครอบครัวเท่าเดิม สมาชิกที่ลบเป็นศูนย์', () {
      final before = SummaryCalculator.compute(
        monthKey: may,
        income: income,
        expenses: expenses,
        savings: savings,
      );

      // ลบสมาชิก 1 แล้วย้ายรายการไปส่วนกลาง (memberId = null)
      final movedIncome = [
        for (final e in income)
          e.memberId == 1 ? e.copyWith(memberId: const Value(null)) : e,
      ];
      final movedExpenses = [
        for (final e in expenses)
          e.memberId == 1 ? e.copyWith(memberId: const Value(null)) : e,
      ];

      final after = SummaryCalculator.compute(
        monthKey: may,
        income: movedIncome,
        expenses: movedExpenses,
        savings: savings,
      );
      final deletedMember = SummaryCalculator.compute(
        monthKey: may,
        income: movedIncome,
        expenses: movedExpenses,
        savings: savings,
        memberId: 1,
      );

      expect(after.incomeTotal, before.incomeTotal);
      expect(after.expenseTotal, before.expenseTotal);
      expect(after.balancePlanned, before.balancePlanned);
      expect(deletedMember.incomeTotal, 0);
      expect(deletedMember.expenseTotal, 0);
    });

    test('การลบสมาชิกพร้อมรายการทั้งหมด: ยอดครอบครัวลดลงตามที่ลบ', () {
      final remainingIncome = income.where((e) => e.memberId != 1).toList();
      final remainingExpenses = expenses.where((e) => e.memberId != 1).toList();
      final s = SummaryCalculator.compute(
        monthKey: may,
        income: remainingIncome,
        expenses: remainingExpenses,
        savings: const [],
      );
      expect(s.incomeTotal, 500050);
      expect(s.expenseTotal, 15025);
    });
  });

  group('ยอดยกมา', () {
    test('ยอดยกมาเพิ่มทั้งรายรับรวมและรายรับที่ได้รับแล้ว', () {
      final s = SummaryCalculator.compute(
        monthKey: may,
        income: income,
        expenses: expenses,
        savings: savings,
        carryOver: 100000,
      );
      expect(s.carryOver, 100000);
      expect(s.incomeTotal, 3600050);
      expect(s.incomeReceived, 3100000);
      expect(s.balancePlanned, 2511569);
      expect(s.balanceNow, 2134975);
    });

    MonthSummary base(Map<String, MonthSummary> map, String key) =>
        map[key] ?? MonthSummary(monthKey: key);

    test('ยกต่อกันเป็นทอด เฉพาะยอดบวก', () {
      final map = {
        '2025-01': const MonthSummary(monthKey: '2025-01', incomeTotal: 100000),
        '2025-02': const MonthSummary(monthKey: '2025-02', expenseTotal: 30000),
        '2025-03': const MonthSummary(monthKey: '2025-03', expenseTotal: 200000),
        '2025-04': const MonthSummary(monthKey: '2025-04', incomeTotal: 50000),
      };
      int carry(String month) => SummaryCalculator.carryOverInto(
            monthKey: month,
            firstMonth: '2025-01',
            baseSummary: (k) => base(map, k),
          );

      expect(carry('2025-01'), 0); // เดือนแรกไม่มียอดยกมา
      expect(carry('2025-02'), 100000);
      expect(carry('2025-03'), 70000); // 100000 - 30000
      expect(carry('2025-04'), 0); // 70000 - 200000 ติดลบ -> ไม่ยก
      expect(carry('2025-05'), 50000); // เริ่มใหม่จาก 0 + 50000
    });

    test('เดือนก่อนหน้าไม่มีข้อมูล ยอดยกมายังต่อเนื่อง', () {
      final map = {
        '2025-01': const MonthSummary(monthKey: '2025-01', incomeTotal: 90000),
      };
      final c = SummaryCalculator.carryOverInto(
        monthKey: '2025-04',
        firstMonth: '2025-01',
        baseSummary: (k) => base(map, k),
      );
      expect(c, 90000);
    });
  });

  group('computeAll', () {
    test('สรุปทุกเดือนที่มีข้อมูลในครั้งเดียว', () {
      final all = SummaryCalculator.computeAll(
        income: income,
        expenses: expenses,
        savings: savings,
      );
      expect(all.keys.toSet(), {'2025-04', '2025-05'});
      expect(all['2025-05']!.incomeTotal, 3500050);
      expect(all['2025-04']!.incomeTotal, 777);
      expect(all['2025-04']!.savings, 100000);
    });
  });

  group('รายจ่ายตามหมวด', () {
    final list = [
      expenseEntry(id: 1, amount: 300, categoryId: 1),
      expenseEntry(id: 2, amount: 500, categoryId: 2),
      expenseEntry(id: 3, amount: 200, categoryId: 1),
      expenseEntry(id: 4, amount: 100, categoryId: null),
      expenseEntry(id: 5, amount: 999, categoryId: 2, skipped: true),
      expenseEntry(id: 6, amount: 888, categoryId: 3, month: '2025-04'),
    ];

    test('เรียงมากไปน้อย เท่ากันเรียงตาม id และไม่มีหมวดอยู่ท้าย', () {
      final slices = SummaryCalculator.expenseByCategory(list, monthKey: may);
      expect(slices.map((s) => s.categoryId).toList(), [1, 2, null]);
      expect(slices.map((s) => s.amountSatang).toList(), [500, 500, 100]);
    });

    test('ข้อความแนะนำหมวดที่ใช้เงินมากที่สุด', () {
      final slices = SummaryCalculator.expenseByCategory(list, monthKey: may);
      final text = SummaryCalculator.topCategoryInsight(
        slices,
        (id) => id == 1 ? 'อาหาร' : 'อื่นๆ',
      );
      expect(text, 'หมวดอาหารใช้เงินมากที่สุด 45%');
    });

    test('ไม่มีรายจ่าย ไม่มีข้อความแนะนำ', () {
      expect(
        SummaryCalculator.topCategoryInsight(const [], (_) => ''),
        isNull,
      );
    });
  });

  group('เปรียบเทียบกับเดือนก่อน', () {
    test('ข้อความเพิ่มขึ้น ลดลง เท่าเดิม และเทียบไม่ได้', () {
      expect(SummaryCalculator.changeText('รายจ่าย', 10000, 11200),
          'รายจ่ายเพิ่มขึ้น 12%');
      expect(SummaryCalculator.changeText('รายจ่าย', 10000, 9500),
          'รายจ่ายลดลง 5%');
      expect(SummaryCalculator.changeText('รายจ่าย', 10000, 10000),
          'รายจ่ายเท่ากับเดือนก่อน');
      expect(SummaryCalculator.changeText('รายจ่าย', 0, 500), isNull);
    });
  });

  group('ข้อมูลกราฟเส้น', () {
    test('รวมรายรับ-รายจ่ายต่อเดือน เดือนที่ไม่มีข้อมูลเป็น 0', () {
      final points = SummaryCalculator.series(
        months: const ['2025-04', '2025-05', '2025-06'],
        income: [
          incomeEntry(id: 1, amount: 100, month: '2025-04'),
          incomeEntry(id: 2, amount: 200, month: '2025-05'),
          incomeEntry(id: 3, amount: 300, month: '2025-05'),
          incomeEntry(id: 4, amount: 9999, month: '2025-05', skipped: true),
        ],
        expenses: [expenseEntry(id: 1, amount: 50, month: '2025-05')],
      );
      expect(points.map((p) => p.incomeSatang).toList(), [100, 500, 0]);
      expect(points.map((p) => p.expenseSatang).toList(), [0, 50, 0]);
    });
  });
}
