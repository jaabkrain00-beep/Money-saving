import 'package:flutter_test/flutter_test.dart';
import 'package:money_cal_saving/core/utils/int_math.dart';

void main() {
  group('roundedDiv', () {
    test('ปัดใกล้สุด 0.5 ปัดออกจากศูนย์', () {
      expect(IntMath.roundedDiv(5, 2), 3);
      expect(IntMath.roundedDiv(7, 2), 4);
      expect(IntMath.roundedDiv(4, 3), 1);
      expect(IntMath.roundedDiv(5, 3), 2);
      expect(IntMath.roundedDiv(1, 3), 0);
      expect(IntMath.roundedDiv(0, 7), 0);
    });

    test('ค่าติดลบสมมาตรกับค่าบวก', () {
      expect(IntMath.roundedDiv(-5, 2), -3);
      expect(IntMath.roundedDiv(-4, 3), -1);
      expect(IntMath.roundedDiv(-1, 3), 0);
    });
  });

  test('ceilDiv ปัดขึ้น', () {
    expect(IntMath.ceilDiv(10, 3), 4);
    expect(IntMath.ceilDiv(9, 3), 3);
    expect(IntMath.ceilDiv(0, 5), 0);
    expect(IntMath.ceilDiv(1, 5), 1);
  });

  test('percentOf', () {
    expect(IntMath.percentOf(1, 3), 33);
    expect(IntMath.percentOf(2, 3), 67);
    expect(IntMath.percentOf(50, 100), 50);
    expect(IntMath.percentOf(5, 0), 0);
  });

  test('percentChange', () {
    expect(IntMath.percentChange(10000, 11200), 12);
    expect(IntMath.percentChange(10000, 9500), -5);
    expect(IntMath.percentChange(100, 100), 0);
    expect(IntMath.percentChange(100, 200), 100);
    expect(IntMath.percentChange(100, 50), -50);
    expect(IntMath.percentChange(0, 500), isNull);
  });
}
