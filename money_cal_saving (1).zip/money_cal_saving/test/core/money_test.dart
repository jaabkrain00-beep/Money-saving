import 'package:flutter_test/flutter_test.dart';
import 'package:money_cal_saving/core/utils/money.dart';

void main() {
  group('Money.format', () {
    test('แสดงทศนิยม 2 ตำแหน่งและลูกน้ำ', () {
      expect(Money.format(123450), '1,234.50');
      expect(Money.format(0), '0.00');
      expect(Money.format(5), '0.05');
      expect(Money.format(100), '1.00');
    });

    test('ยอดหลักล้านที่มีสตางค์ต้องไม่คลาดเคลื่อน', () {
      expect(Money.format(123456789), '1,234,567.89');
      expect(Money.format(100000001), '1,000,000.01');
      expect(Money.format(99999999999), '999,999,999.99');
    });

    test('ติดลบ มีสัญลักษณ์ และเครื่องหมายบวก', () {
      expect(Money.format(-123450), '-1,234.50');
      expect(Money.format(123450, symbol: true), '฿1,234.50');
      expect(Money.format(-100, symbol: true), '-฿1.00');
      expect(Money.format(100, signed: true), '+1.00');
      expect(Money.format(0, signed: true), '0.00');
    });
  });

  group('Money.toInputText', () {
    test('บาทถ้วนไม่แสดงทศนิยม', () {
      expect(Money.toInputText(123400), '1,234');
      expect(Money.toInputText(123450), '1,234.50');
    });
  });

  group('Money.formatCompact', () {
    test('ย่อเป็น K และ M', () {
      expect(Money.formatCompact(99900), '999');
      expect(Money.formatCompact(100000), '1K');
      expect(Money.formatCompact(150000), '1.5K');
      expect(Money.formatCompact(100000000), '1M');
      expect(Money.formatCompact(250000000), '2.5M');
      expect(Money.formatCompact(-150000), '-1.5K');
    });
  });

  group('Money.parse', () {
    test('แปลงข้อความเป็นสตางค์', () {
      expect(Money.parse('1,234.50'), 123450);
      expect(Money.parse('฿ 99'), 9900);
      expect(Money.parse('0.5'), 50);
      expect(Money.parse('.5'), 50);
      expect(Money.parse('12.'), 1200);
      expect(Money.parse('1234567.89'), 123456789);
      expect(Money.parse('0.05'), 5);
    });

    test('รูปแบบที่ไม่ถูกต้องคืน null', () {
      expect(Money.parse(''), isNull);
      expect(Money.parse('.'), isNull);
      expect(Money.parse('abc'), isNull);
      expect(Money.parse('1.234'), isNull);
      expect(Money.parse('1.2.3'), isNull);
      expect(Money.parse('-5'), isNull);
      expect(Money.parse('1234567890123'), isNull);
    });

    test('parse แล้ว format กลับต้องได้ค่าเดิม', () {
      for (final satang in [0, 1, 99, 100, 123450, 123456789, 99999999999]) {
        expect(Money.parse(Money.format(satang)), satang);
      }
    });
  });
}
