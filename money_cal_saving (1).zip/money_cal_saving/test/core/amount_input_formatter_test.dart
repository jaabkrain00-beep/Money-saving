import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:money_cal_saving/core/utils/amount_input_formatter.dart';

TextEditingValue _type(String text, {AmountInputFormatter? formatter}) {
  final f = formatter ?? AmountInputFormatter();
  return f.formatEditUpdate(
    TextEditingValue.empty,
    TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: text.length),
    ),
  );
}

void main() {
  test('ใส่ลูกน้ำคั่นหลักพันอัตโนมัติ', () {
    expect(_type('1234').text, '1,234');
    expect(_type('1234567').text, '1,234,567');
    expect(_type('999').text, '999');
  });

  test('ทศนิยมไม่เกิน 2 ตำแหน่ง', () {
    expect(_type('1234.567').text, '1,234.56');
    expect(_type('0.5').text, '0.5');
  });

  test('พิมพ์จุดก่อนเป็น 0.', () {
    expect(_type('.').text, '0.');
  });

  test('ตัดศูนย์นำหน้าและตัวอักษรที่ไม่ใช่ตัวเลข', () {
    expect(_type('007').text, '7');
    expect(_type('abc12').text, '12');
    expect(_type('1.2.3').text, '1.23');
  });

  test('จำกัดจำนวนหลักของส่วนจำนวนเต็ม', () {
    expect(_type('12345678901').text, '1,234,567,890');
    expect(
      _type('12345', formatter: AmountInputFormatter(maxIntDigits: 3)).text,
      '123',
    );
  });

  test('เคอร์เซอร์อยู่ท้ายข้อความเมื่อพิมพ์ต่อท้าย', () {
    final v = _type('1234');
    expect(v.selection.baseOffset, v.text.length);
  });

  test('ข้อความว่างยังว่าง', () {
    expect(_type('').text, '');
  });
}
