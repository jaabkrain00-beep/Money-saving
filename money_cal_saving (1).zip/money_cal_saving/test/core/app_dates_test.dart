import 'package:flutter_test/flutter_test.dart';
import 'package:money_cal_saving/core/utils/app_dates.dart';

void main() {
  group('monthKey', () {
    test('สร้างและแยกคีย์', () {
      expect(AppDates.monthKey(DateTime(2025, 5, 17)), '2025-05');
      expect(AppDates.monthKeyOf(2026, 12), '2026-12');
      final k = AppDates.parseKey('2025-05');
      expect(k.year, 2025);
      expect(k.month, 5);
    });

    test('addMonths ข้ามปีทั้งสองทาง', () {
      expect(AppDates.addMonths('2025-12', 1), '2026-01');
      expect(AppDates.addMonths('2026-01', -1), '2025-12');
      expect(AppDates.addMonths('2025-05', 12), '2026-05');
      expect(AppDates.addMonths('2025-05', -17), '2023-12');
      expect(AppDates.addMonths('2025-05', 0), '2025-05');
    });

    test('monthsBetween / monthRange / monthsBack', () {
      expect(AppDates.monthsBetween('2025-01', '2025-12'), 11);
      expect(AppDates.monthsBetween('2025-12', '2026-01'), 1);
      expect(AppDates.monthsBetween('2026-01', '2025-01'), -12);
      expect(AppDates.monthRange('2025-11', '2026-02'),
          ['2025-11', '2025-12', '2026-01', '2026-02']);
      expect(AppDates.monthRange('2025-05', '2025-05'), ['2025-05']);
      expect(AppDates.monthRange('2025-06', '2025-05'), isEmpty);
      expect(AppDates.monthsBack('2026-03', 3),
          ['2026-01', '2026-02', '2026-03']);
    });
  });

  group('วันในเดือน', () {
    test('ปีอธิกสุรทิน', () {
      expect(AppDates.isLeapYear(2024), isTrue);
      expect(AppDates.isLeapYear(2023), isFalse);
      expect(AppDates.isLeapYear(2100), isFalse);
      expect(AppDates.isLeapYear(2000), isTrue);
      expect(AppDates.daysInMonth(2024, 2), 29);
      expect(AppDates.daysInMonth(2023, 2), 28);
      expect(AppDates.daysInMonth(2025, 4), 30);
      expect(AppDates.daysInMonth(2025, 12), 31);
    });

    test('วันที่ 31 ในเดือนที่มี 30 วัน ใช้วันสุดท้ายของเดือน', () {
      expect(AppDates.dateInMonth('2025-04', 31), DateTime(2025, 4, 30));
      expect(AppDates.dateInMonth('2025-06', 31), DateTime(2025, 6, 30));
      expect(AppDates.dateInMonth('2025-01', 31), DateTime(2025, 1, 31));
    });

    test('กุมภาพันธ์: ปีปกติ 28 วัน ปีอธิกสุรทิน 29 วัน', () {
      expect(AppDates.dateInMonth('2025-02', 30), DateTime(2025, 2, 28));
      expect(AppDates.dateInMonth('2025-02', 31), DateTime(2025, 2, 28));
      expect(AppDates.dateInMonth('2024-02', 31), DateTime(2024, 2, 29));
      expect(AppDates.dateInMonth('2024-02', 29), DateTime(2024, 2, 29));
    });

    test('วันที่ต่ำกว่า 1 ปรับเป็นวันที่ 1', () {
      expect(AppDates.dateInMonth('2025-05', 0), DateTime(2025, 5, 1));
    });

    test('daysBetween นับตามปฏิทิน', () {
      expect(AppDates.daysBetween(DateTime(2025, 3, 1), DateTime(2025, 3, 4)), 3);
      expect(AppDates.daysBetween(DateTime(2025, 1, 31), DateTime(2025, 2, 1)), 1);
      expect(AppDates.daysBetween(DateTime(2025, 3, 4), DateTime(2025, 3, 1)), -3);
      expect(
        AppDates.daysBetween(
          DateTime(2025, 3, 1, 23, 59),
          DateTime(2025, 3, 2, 0, 1),
        ),
        1,
      );
    });
  });

  group('การแสดงผล', () {
    test('เดือนและปี พ.ศ./ค.ศ.', () {
      expect(AppDates.formatMonthYear(2025, 5, buddhist: true), 'พฤษภาคม 2568');
      expect(AppDates.formatMonthYear(2025, 5, buddhist: false), 'พฤษภาคม 2025');
      expect(AppDates.formatMonthYearFromKey('2026-01', buddhist: true),
          'มกราคม 2569');
      expect(AppDates.formatShortMonthYear('2025-05', buddhist: true),
          'พ.ค. 2568');
    });

    test('วัน-เดือน และวันที่เต็ม', () {
      final d = DateTime(2025, 5, 5);
      expect(AppDates.formatDayMonth(d), '5 พ.ค.');
      expect(AppDates.formatDayMonth(d, withYear: true), '5 พ.ค. 2568');
      expect(AppDates.formatDayMonth(d, withYear: true, buddhist: false),
          '5 พ.ค. 2025');
      expect(AppDates.formatFullDate(d), 'วันจันทร์ที่ 5 พฤษภาคม 2568');
    });

    test('เวลา', () {
      expect(AppDates.formatTime(9, 0), '09:00');
      expect(AppDates.formatTime(18, 5), '18:05');
    });

    test('คำทักทายตามช่วงเวลา', () {
      expect(AppDates.greeting(DateTime(2025, 1, 1, 2)), 'สวัสดีตอนดึก 🌙');
      expect(AppDates.greeting(DateTime(2025, 1, 1, 8)), 'สวัสดีตอนเช้า ☀️');
      expect(AppDates.greeting(DateTime(2025, 1, 1, 13)), 'สวัสดีตอนบ่าย 🌤️');
      expect(AppDates.greeting(DateTime(2025, 1, 1, 18)), 'สวัสดีตอนเย็น 🌇');
      expect(AppDates.greeting(DateTime(2025, 1, 1, 22)), 'สวัสดีตอนค่ำ 🌙');
    });
  });
}
