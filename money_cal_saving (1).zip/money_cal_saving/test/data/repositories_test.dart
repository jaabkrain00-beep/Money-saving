// ทดสอบ repository กับฐานข้อมูลจริงในหน่วยความจำ (SQLite)
// ต้องมีไลบรารี sqlite3 ในเครื่องที่รันเทสต์ (Linux: libsqlite3, macOS มีให้แล้ว,
// Windows: วาง sqlite3.dll ไว้ใน PATH) — ตรรกะล้วนอยู่ใน test/domain ซึ่งไม่ต้องใช้ SQLite
import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:money_cal_saving/data/db/app_database.dart';
import 'package:money_cal_saving/data/repositories/categories_repository.dart';
import 'package:money_cal_saving/data/repositories/expense_repository.dart';
import 'package:money_cal_saving/data/repositories/income_repository.dart';
import 'package:money_cal_saving/data/repositories/members_repository.dart';
import 'package:money_cal_saving/data/repositories/savings_repository.dart';

void main() {
  late AppDatabase db;
  late ExpenseRepository expense;
  late IncomeRepository income;
  late MembersRepository members;
  late SavingsRepository savings;
  late CategoriesRepository categories;

  setUp(() {
    db = AppDatabase.forTesting(NativeDatabase.memory());
    expense = ExpenseRepository(db);
    income = IncomeRepository(db);
    members = MembersRepository(db);
    savings = SavingsRepository(db);
    categories = CategoriesRepository(db);
  });

  tearDown(() async => db.close());

  const rent = ExpenseTemplateInput(
    name: 'ค่าเช่าห้อง',
    amountSatang: 800000,
    dueDay: 31,
    startMonth: '2025-01',
  );

  const salary = IncomeTemplateInput(
    name: 'เงินเดือน',
    amountSatang: 3000000,
    dayOfMonth: 25,
    startMonth: '2025-01',
  );

  group('การสร้างรายการรายเดือน', () {
    test('สร้างครบทุกเดือน ไม่ซ้ำเมื่อเรียกหลายครั้ง และเริ่มเป็น "ยังไม่จ่าย"', () async {
      await expense.addTemplate(rent);
      await expense.ensureRange('2025-01', '2025-03');
      await expense.ensureRange('2025-01', '2025-03');

      final all = await db.expenseDao.getAllEntries();
      expect(all, hasLength(3));
      expect(all.every((e) => !e.isPaid), isTrue);
      expect(all.map((e) => e.dueDate.day).toList(), [31, 28, 31]);
    });

    test('สถานะจ่ายแล้วแยกตามเดือน เดือนใหม่เริ่มเป็นยังไม่จ่ายเสมอ', () async {
      await expense.addTemplate(rent);
      await expense.ensureMonth('2025-01');
      final jan = (await db.expenseDao.getMonth('2025-01')).single;

      await expense.setPaid(jan.id, true);
      await expense.ensureMonth('2025-02');

      final paidJan = (await db.expenseDao.getMonth('2025-01')).single;
      final feb = (await db.expenseDao.getMonth('2025-02')).single;
      expect(paidJan.isPaid, isTrue);
      expect(paidJan.paidAt, isNotNull);
      expect(feb.isPaid, isFalse);
      expect(feb.paidAt, isNull);

      await expense.setPaid(jan.id, false);
      final undone = (await db.expenseDao.getMonth('2025-01')).single;
      expect(undone.isPaid, isFalse);
      expect(undone.paidAt, isNull);
    });

    test('ผ่อน 3 งวด สร้างครบ 3 เดือนแล้วหยุดเอง', () async {
      await expense.addTemplate(
        const ExpenseTemplateInput(
          name: 'ผ่อนโทรศัพท์',
          amountSatang: 100000,
          dueDay: 10,
          startMonth: '2025-01',
          totalInstallments: 3,
        ),
      );
      await expense.ensureRange('2025-01', '2025-12');
      final all = await db.expenseDao.getAllEntries();
      expect(all.map((e) => e.monthKey).toList(), ['2025-01', '2025-02', '2025-03']);
    });
  });

  group('ลบเฉพาะเดือนนี้ + Undo', () {
    test('ลบแล้วไม่ถูกสร้างซ้ำ และ Undo คืนรายการเดิม', () async {
      await expense.addTemplate(rent);
      await expense.ensureMonth('2025-02');
      final feb = (await db.expenseDao.getMonth('2025-02')).single;

      await expense.deleteEntry(feb);
      expect(await db.expenseDao.getMonth('2025-02'), isEmpty);

      await expense.ensureMonth('2025-02'); // เปิดแอป/เปลี่ยนเดือนอีกครั้ง
      expect(await db.expenseDao.getMonth('2025-02'), isEmpty);

      await expense.restoreEntry(feb);
      final restored = (await db.expenseDao.getMonth('2025-02')).single;
      expect(restored.id, feb.id);
    });

    test('รายจ่ายจรลบจริงและ Undo คืนได้', () async {
      final id = await expense.addOneTime(
        name: 'ซื้อของ',
        amountSatang: 15025,
        date: DateTime(2025, 5, 10),
      );
      final row = (await db.expenseDao.getEntry(id))!;
      expect(row.isPaid, isTrue); // ถือว่าจ่ายแล้วทันทีที่บันทึก
      expect(row.monthKey, '2025-05');

      await expense.deleteEntry(row);
      expect(await db.expenseDao.getEntry(id), isNull);

      await expense.restoreEntry(row);
      expect(await db.expenseDao.getEntry(id), isNotNull);
    });
  });

  group('ปิดยอด / ครบงวดแล้ว', () {
    test('เดือนที่ปิดยังอยู่ เดือนถัดไปไม่ถูกสร้าง ประวัติครบ และยกเลิกได้', () async {
      await expense.addTemplate(rent);
      await expense.ensureRange('2025-01', '2025-06');
      final template = (await db.expenseDao.getTemplates()).single;

      await expense.closeTemplate(template, '2025-03');

      var months = (await db.expenseDao.getAllEntries()).map((e) => e.monthKey);
      expect(months.toList(), ['2025-01', '2025-02', '2025-03']);

      await expense.ensureRange('2025-01', '2025-06');
      months = (await db.expenseDao.getAllEntries()).map((e) => e.monthKey);
      expect(months, hasLength(3)); // ไม่ถูกสร้างใหม่

      final closed = (await db.expenseDao.getTemplates()).single;
      expect(closed.endMonth, '2025-03');

      await expense.reopenTemplate(closed);
      await expense.ensureRange('2025-01', '2025-06');
      expect(await db.expenseDao.getAllEntries(), hasLength(6));
    });

    test('Undo การปิดยอดคืนเดือนที่ถูกลบและเดือนสุดท้ายเดิม', () async {
      await expense.addTemplate(rent);
      await expense.ensureRange('2025-01', '2025-06');
      final template = (await db.expenseDao.getTemplates()).single;

      final snapshot = await expense.closeTemplate(template, '2025-03');
      expect(snapshot.entries, hasLength(3));

      await expense.restoreTemplate(snapshot);
      expect((await db.expenseDao.getTemplates()).single.endMonth, isNull);
      expect(await db.expenseDao.getAllEntries(), hasLength(6));
    });
  });

  group('แก้ไขแม่แบบ', () {
    test('"ตั้งแต่เดือนนี้เป็นต้นไป" ไม่เปลี่ยนยอดของเดือนก่อนที่ยังไม่เคยเปิดดู', () async {
      await income.addTemplate(salary);
      final template = (await db.incomeDao.getTemplates()).single;

      await income.updateTemplateFromMonth(
        original: template,
        input: const IncomeTemplateInput(
          name: 'เงินเดือน',
          amountSatang: 3500000,
          dayOfMonth: 25,
          startMonth: '2025-01',
        ),
        fromMonth: '2025-03',
      );
      await income.ensureRange('2025-01', '2025-04');

      final byMonth = {
        for (final e in await db.incomeDao.getAllEntries())
          e.monthKey: e.amountSatang,
      };
      expect(byMonth, {
        '2025-01': 3000000,
        '2025-02': 3000000,
        '2025-03': 3500000,
        '2025-04': 3500000,
      });
    });

    test('แก้ตั้งแต่เดือนนี้: อัปเดตยอดแต่คงสถานะ "ได้รับแล้ว"', () async {
      await income.addTemplate(salary);
      await income.ensureRange('2025-01', '2025-03');
      final mar = (await db.incomeDao.getMonth('2025-03')).single;
      await income.setReceived(mar.id, true);

      final template = (await db.incomeDao.getTemplates()).single;
      await income.updateTemplateFromMonth(
        original: template,
        input: const IncomeTemplateInput(
          name: 'เงินเดือน',
          amountSatang: 3500000,
          dayOfMonth: 20,
          startMonth: '2025-01',
        ),
        fromMonth: '2025-03',
      );

      final updated = (await db.incomeDao.getMonth('2025-03')).single;
      expect(updated.amountSatang, 3500000);
      expect(updated.date.day, 20);
      expect(updated.isReceived, isTrue);
      final jan = (await db.incomeDao.getMonth('2025-01')).single;
      expect(jan.amountSatang, 3000000);
    });

    test('แก้เฉพาะเดือนนี้ ไม่กระทบเดือนอื่นและแม่แบบ', () async {
      await income.addTemplate(salary);
      await income.ensureMonth('2025-02');
      final feb = (await db.incomeDao.getMonth('2025-02')).single;

      await income.updateEntry(feb.copyWith(amountSatang: 3800000)); // ได้ OT
      await income.ensureMonth('2025-03');

      expect((await db.incomeDao.getMonth('2025-02')).single.amountSatang, 3800000);
      expect((await db.incomeDao.getMonth('2025-03')).single.amountSatang, 3000000);
      expect((await db.incomeDao.getTemplates()).single.amountSatang, 3000000);
    });
  });

  group('ลบแม่แบบ + Undo', () {
    test('ลบตั้งแต่เดือนนี้: เก็บประวัติก่อนหน้า และ Undo คืนครบ', () async {
      await income.addTemplate(salary);
      await income.ensureRange('2025-01', '2025-05');
      final template = (await db.incomeDao.getTemplates()).single;

      final snapshot = await income.deleteTemplateFromMonth(template, '2025-03');

      expect((await db.incomeDao.getTemplates()).single.endMonth, '2025-02');
      final months =
          (await db.incomeDao.getAllEntries()).map((e) => e.monthKey).toList();
      expect(months, ['2025-01', '2025-02']);

      await income.restoreTemplate(snapshot);
      expect((await db.incomeDao.getTemplates()).single.endMonth, isNull);
      expect(await db.incomeDao.getAllEntries(), hasLength(5));
    });

    test('ลบตั้งแต่เดือนเริ่มต้น = ลบทั้งหมด และ Undo คืนได้', () async {
      await income.addTemplate(salary);
      await income.ensureRange('2025-01', '2025-03');
      final template = (await db.incomeDao.getTemplates()).single;

      final snapshot = await income.deleteTemplateFromMonth(template, '2025-01');
      expect(await db.incomeDao.getTemplates(), isEmpty);
      expect(await db.incomeDao.getAllEntries(), isEmpty);

      await income.restoreTemplate(snapshot);
      expect(await db.incomeDao.getTemplates(), hasLength(1));
      expect(await db.incomeDao.getAllEntries(), hasLength(3));
    });
  });

  group('ลบสมาชิก', () {
    late int memberId;
    late int goalId;

    setUp(() async {
      memberId = await members.addMember(
        const MemberInput(name: 'แม่', color: 0xFFFFB7B2),
      );
      await income.addTemplate(
        IncomeTemplateInput(
          name: 'เงินเดือนแม่',
          amountSatang: 3000000,
          dayOfMonth: 25,
          startMonth: '2025-01',
          memberId: memberId,
        ),
      );
      await income.ensureRange('2025-01', '2025-02');
      await expense.addOneTime(
        name: 'ซื้อของ',
        amountSatang: 15025,
        date: DateTime(2025, 1, 10),
        memberId: memberId,
      );
      goalId = await savings.addGoal(
        GoalInput(
          name: 'ทริป',
          targetSatang: 1000000,
          color: 0xFFA0C4FF,
          memberId: memberId,
        ),
      );
    });

    test('นับรายการที่ผูกอยู่ก่อนลบ', () async {
      // แม่แบบ 1 + instance รายรับ 2 + รายจ่ายจร 1
      expect(await members.countRecords(memberId), 4);
    });

    test('ย้ายไปส่วนกลาง แล้ว Undo คืนความเป็นเจ้าของ', () async {
      final snapshot = await members.deleteMember(memberId, deleteRecords: false);

      expect(await db.membersDao.getMember(memberId), isNull);
      final entries = await db.incomeDao.getAllEntries();
      expect(entries, hasLength(2));
      expect(entries.every((e) => e.memberId == null), isTrue);
      expect((await db.incomeDao.getTemplates()).single.memberId, isNull);
      expect((await db.expenseDao.getAllEntries()).single.memberId, isNull);
      expect((await db.savingsDao.getGoal(goalId))!.memberId, isNull);

      await members.restoreMember(snapshot);

      expect(await db.membersDao.getMember(memberId), isNotNull);
      expect(
        (await db.incomeDao.getAllEntries()).every((e) => e.memberId == memberId),
        isTrue,
      );
      expect((await db.incomeDao.getTemplates()).single.memberId, memberId);
      expect((await db.expenseDao.getAllEntries()).single.memberId, memberId);
      expect((await db.savingsDao.getGoal(goalId))!.memberId, memberId);
    });

    test('ลบรายการทั้งหมด (เป้าหมายออมถูกย้ายไปส่วนกลาง) แล้ว Undo คืนครบ', () async {
      final snapshot = await members.deleteMember(memberId, deleteRecords: true);

      expect(await db.incomeDao.getTemplates(), isEmpty);
      expect(await db.incomeDao.getAllEntries(), isEmpty);
      expect(await db.expenseDao.getAllEntries(), isEmpty);
      final goal = await db.savingsDao.getGoal(goalId);
      expect(goal, isNotNull);
      expect(goal!.memberId, isNull);

      await members.restoreMember(snapshot);

      expect(await db.incomeDao.getTemplates(), hasLength(1));
      expect(await db.incomeDao.getAllEntries(), hasLength(2));
      expect(await db.expenseDao.getAllEntries(), hasLength(1));
      expect((await db.savingsDao.getGoal(goalId))!.memberId, memberId);
    });
  });

  group('เป้าหมายออม', () {
    late int goalId;

    setUp(() async {
      goalId = await savings.addGoal(
        const GoalInput(
          name: 'ทริปญี่ปุ่น',
          targetSatang: 1000000,
          color: 0xFFC3B1E1,
        ),
      );
    });

    Future<TxResult> deposit(int satang) => savings.addTransaction(
          goalId: goalId,
          amountSatang: satang,
          type: SavingTxType.deposit,
          date: DateTime(2025, 5, 10),
        );

    test('ครบเป้าหมายแล้วสำเร็จ ถอนต่ำกว่าเป้าหมายกลับเป็นยังไม่สำเร็จ', () async {
      expect((await deposit(600000)).justCompleted, isFalse);

      final reached = await deposit(400000);
      expect(reached.justCompleted, isTrue);
      expect(reached.balance, 1000000);
      expect((await db.savingsDao.getGoal(goalId))!.isCompleted, isTrue);

      final withdrawn = await savings.addTransaction(
        goalId: goalId,
        amountSatang: 100000,
        type: SavingTxType.withdraw,
        date: DateTime(2025, 5, 11),
      );
      expect(withdrawn.balance, 900000);
      expect((await db.savingsDao.getGoal(goalId))!.isCompleted, isFalse);

      // ออมครบอีกครั้ง ต้องฉลองอีกครั้ง
      expect((await deposit(100000)).justCompleted, isTrue);
    });

    test('ถอนเกินยอดที่ออมไว้ไม่ได้', () async {
      await deposit(100000);
      await expectLater(
        savings.addTransaction(
          goalId: goalId,
          amountSatang: 100001,
          type: SavingTxType.withdraw,
          date: DateTime(2025, 5, 11),
        ),
        throwsA(isA<InsufficientSavingsException>()),
      );
      expect(await savings.balanceOf(goalId), 100000);
    });

    test('รายการฝากถูกนับเป็นเงินออมของเดือนที่ฝาก', () async {
      await deposit(250000);
      final tx = (await db.savingsDao.getTransactions(goalId)).single;
      expect(tx.monthKey, '2025-05');
    });

    test('ลบเป้าหมายแล้ว Undo คืนเป้าหมายและรายการฝากถอน', () async {
      await deposit(300000);
      final goal = (await db.savingsDao.getGoal(goalId))!;

      final snapshot = await savings.deleteGoal(goal);
      expect(await db.savingsDao.getGoal(goalId), isNull);
      expect(await db.savingsDao.getAllTransactions(), isEmpty);

      await savings.restoreGoal(snapshot);
      expect(await db.savingsDao.getGoal(goalId), isNotNull);
      expect(await savings.balanceOf(goalId), 300000);
    });

    test('ลบรายการฝากที่ทำให้ครบเป้าหมาย สถานะกลับเป็นยังไม่สำเร็จ', () async {
      await deposit(1000000);
      expect((await db.savingsDao.getGoal(goalId))!.isCompleted, isTrue);

      final tx = (await db.savingsDao.getTransactions(goalId)).single;
      final result = await savings.deleteTransaction(tx);
      expect(result.balance, 0);
      expect((await db.savingsDao.getGoal(goalId))!.isCompleted, isFalse);
    });
  });

  group('หมวดหมู่', () {
    test('ลบหมวดแล้วรายการกลายเป็นไม่มีหมวด และ Undo คืนหมวดให้รายการเดิม', () async {
      final cats = await db.membersDao.getCategories();
      final food = cats.firstWhere((c) => c.type == CategoryType.expense);

      final entryId = await expense.addOneTime(
        name: 'ข้าวมันไก่',
        amountSatang: 5000,
        date: DateTime(2025, 5, 10),
        categoryId: food.id,
      );
      expect(await categories.usageCount(food.id), 1);

      final snapshot = await categories.deleteCategory(food.id);
      expect((await db.expenseDao.getEntry(entryId))!.categoryId, isNull);

      await categories.restoreCategory(snapshot);
      expect((await db.expenseDao.getEntry(entryId))!.categoryId, food.id);
    });

    test('มีหมวดหมู่ตั้งต้นทั้งรายรับและรายจ่าย', () async {
      final cats = await db.membersDao.getCategories();
      expect(cats.any((c) => c.type == CategoryType.income), isTrue);
      expect(cats.any((c) => c.type == CategoryType.expense), isTrue);
    });
  });

  test('ล้างข้อมูลทั้งหมดคงหมวดหมู่ไว้', () async {
    await expense.addTemplate(rent);
    await expense.ensureMonth('2025-01');
    await members.addMember(const MemberInput(name: 'พ่อ', color: 0xFFA0C4FF));

    await db.clearAllData();

    expect(await db.expenseDao.getAllEntries(), isEmpty);
    expect(await db.expenseDao.getTemplates(), isEmpty);
    expect(await db.membersDao.getMembers(), isEmpty);
    expect(await db.membersDao.getCategories(), isNotEmpty);
  });
}
