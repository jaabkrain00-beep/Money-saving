import 'package:money_cal_saving/data/db/app_database.dart';

// ตัวช่วยสร้างข้อมูลทดสอบ (Drift data class เป็น class ธรรมดา ไม่ต้องใช้ฐานข้อมูลจริง)

IncomeTemplate incomeTemplate({
  int id = 1,
  String name = 'เงินเดือน',
  int amount = 3000000,
  int? memberId = 1,
  int day = 25,
  int? categoryId,
  String start = '2025-01',
  String? end,
  String note = '',
}) =>
    IncomeTemplate(
      id: id,
      name: name,
      amountSatang: amount,
      memberId: memberId,
      dayOfMonth: day,
      categoryId: categoryId,
      startMonth: start,
      endMonth: end,
      note: note,
    );

ExpenseTemplate expenseTemplate({
  int id = 1,
  String name = 'ค่าเช่าห้อง',
  int amount = 800000,
  int? memberId,
  int day = 5,
  int? categoryId,
  String start = '2025-01',
  String? end,
  int? installments,
  String note = '',
}) =>
    ExpenseTemplate(
      id: id,
      name: name,
      amountSatang: amount,
      memberId: memberId,
      dueDay: day,
      categoryId: categoryId,
      startMonth: start,
      endMonth: end,
      totalInstallments: installments,
      remindDaysBefore: null,
      remindTime: null,
      note: note,
    );

IncomeEntry incomeEntry({
  int id = 1,
  int? templateId,
  String name = 'รายรับ',
  required int amount,
  int? memberId,
  DateTime? date,
  String month = '2025-05',
  bool received = false,
  int? categoryId,
  bool oneTime = false,
  bool carryOver = false,
  bool skipped = false,
}) =>
    IncomeEntry(
      id: id,
      templateId: templateId,
      name: name,
      amountSatang: amount,
      memberId: memberId,
      date: date ?? DateTime(2025, 5, 25),
      monthKey: month,
      isReceived: received,
      categoryId: categoryId,
      note: '',
      isOneTime: oneTime,
      isCarryOver: carryOver,
      isSkipped: skipped,
    );

ExpenseEntry expenseEntry({
  int id = 1,
  int? templateId,
  String name = 'รายจ่าย',
  required int amount,
  int? memberId,
  DateTime? due,
  String month = '2025-05',
  bool paid = false,
  int? categoryId,
  bool oneTime = false,
  bool skipped = false,
}) =>
    ExpenseEntry(
      id: id,
      templateId: templateId,
      name: name,
      amountSatang: amount,
      memberId: memberId,
      dueDate: due ?? DateTime(2025, 5, 5),
      monthKey: month,
      isPaid: paid,
      paidAt: null,
      categoryId: categoryId,
      note: '',
      isOneTime: oneTime,
      isSkipped: skipped,
    );

SavingTransaction savingTx({
  int id = 1,
  int goalId = 1,
  required int amount,
  required SavingTxType type,
  DateTime? date,
  String month = '2025-05',
}) =>
    SavingTransaction(
      id: id,
      goalId: goalId,
      amountSatang: amount,
      type: type,
      date: date ?? DateTime(2025, 5, 10),
      monthKey: month,
      note: '',
    );
