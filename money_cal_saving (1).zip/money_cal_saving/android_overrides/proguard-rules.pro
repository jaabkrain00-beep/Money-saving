# flutter_local_notifications ใช้ Gson/reflection ต้องกัน R8 ลบ/เปลี่ยนชื่อ
-keep class com.dexterous.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
-keep class * extends com.google.gson.reflect.TypeToken
-keep class com.google.gson.** { *; }
