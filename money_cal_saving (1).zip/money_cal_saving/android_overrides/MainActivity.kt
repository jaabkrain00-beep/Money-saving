package th.moneycal.money_cal_saving

import io.flutter.embedding.android.FlutterFragmentActivity

// local_auth (ลายนิ้วมือ) ต้องใช้ FlutterFragmentActivity
class MainActivity : FlutterFragmentActivity()
