#!/usr/bin/env python3
"""แก้ android/app/build.gradle(.kts) ที่ flutter create สร้างให้ตรงสเปก:
minSdk 26, targetSdk 35, core library desugaring (ต้องใช้กับ flutter_local_notifications),
R8 + proguard, และ signing แบบ release จาก android/key.properties (ถ้ามี)
รันซ้ำได้ปลอดภัย (ข้ามถ้าแก้แล้ว)"""
import os
import re
import sys

root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "android", "app")
kts = os.path.join(root, "build.gradle.kts")
groovy = os.path.join(root, "build.gradle")
MARK = "// [money_cal_saving] patched"

if os.path.exists(kts):
    path, is_kts = kts, True
elif os.path.exists(groovy):
    path, is_kts = groovy, False
else:
    sys.exit("ไม่พบ android/app/build.gradle(.kts) กรุณารัน tool/setup_android.sh ก่อน")

s = open(path, encoding="utf-8").read()
if MARK in s:
    print("แก้ไขไว้แล้ว ข้าม")
    sys.exit(0)

if is_kts:
    s = re.sub(r"minSdk\s*=\s*flutter\.minSdkVersion", "minSdk = 26", s)
    s = re.sub(r"targetSdk\s*=\s*flutter\.targetSdkVersion", "targetSdk = 35", s)
    if "isCoreLibraryDesugaringEnabled" not in s:
        s = re.sub(r"(compileOptions\s*\{)", r"\1\n        isCoreLibraryDesugaringEnabled = true", s, count=1)

    s = "import java.util.Properties\nimport java.io.FileInputStream\n\n" + s
    props = (
        'val keystoreProperties = Properties()\n'
        'val keystorePropertiesFile = rootProject.file("key.properties")\n'
        'if (keystorePropertiesFile.exists()) {\n'
        '    keystoreProperties.load(FileInputStream(keystorePropertiesFile))\n'
        '}\n\n'
    )
    # ต้องอยู่หลังบล็อก plugins { } (ห้ามมีโค้ดอื่นคั่นก่อน plugins)
    s = re.sub(r"(\nandroid\s*\{)", "\n" + props.rstrip("\n") + r"\n\1", s, count=1)

    signing = (
        '    signingConfigs {\n'
        '        create("release") {\n'
        '            if (keystorePropertiesFile.exists()) {\n'
        '                keyAlias = keystoreProperties["keyAlias"] as String\n'
        '                keyPassword = keystoreProperties["keyPassword"] as String\n'
        '                storeFile = file(keystoreProperties["storeFile"] as String)\n'
        '                storePassword = keystoreProperties["storePassword"] as String\n'
        '            }\n'
        '        }\n'
        '    }\n\n'
    )
    s = re.sub(r"(\n\s*buildTypes\s*\{)", "\n" + signing.rstrip("\n") + r"\n\1", s, count=1)
    release = (
        'release {\n'
        '            signingConfig = if (keystorePropertiesFile.exists()) signingConfigs.getByName("release") else signingConfigs.getByName("debug")\n'
        '            isMinifyEnabled = true\n'
        '            isShrinkResources = true\n'
        '            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")\n'
        '        }'
    )
    s = re.sub(r"release\s*\{[^}]*\}", release, s, count=1)
    s += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
else:
    s = re.sub(r"minSdkVersion\s+flutter\.minSdkVersion", "minSdkVersion 26", s)
    s = re.sub(r"targetSdkVersion\s+flutter\.targetSdkVersion", "targetSdkVersion 35", s)
    if "coreLibraryDesugaringEnabled" not in s:
        s = re.sub(r"(compileOptions\s*\{)", r"\1\n        coreLibraryDesugaringEnabled true", s, count=1)
    props = (
        'def keystoreProperties = new Properties()\n'
        'def keystorePropertiesFile = rootProject.file("key.properties")\n'
        'if (keystorePropertiesFile.exists()) {\n'
        '    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))\n'
        '}\n\n'
    )
    s = re.sub(r"(\nandroid\s*\{)", "\n" + props.rstrip("\n") + r"\n\1", s, count=1)
    signing = (
        '    signingConfigs {\n'
        '        release {\n'
        '            if (keystorePropertiesFile.exists()) {\n'
        '                keyAlias keystoreProperties["keyAlias"]\n'
        '                keyPassword keystoreProperties["keyPassword"]\n'
        '                storeFile file(keystoreProperties["storeFile"])\n'
        '                storePassword keystoreProperties["storePassword"]\n'
        '            }\n'
        '        }\n'
        '    }\n\n'
    )
    s = re.sub(r"(\n\s*buildTypes\s*\{)", "\n" + signing.rstrip("\n") + r"\n\1", s, count=1)
    release = (
        'release {\n'
        '            signingConfig keystorePropertiesFile.exists() ? signingConfigs.release : signingConfigs.debug\n'
        '            minifyEnabled true\n'
        '            shrinkResources true\n'
        '            proguardFiles getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro"\n'
        '        }'
    )
    s = re.sub(r"release\s*\{[^}]*\}", release, s, count=1)
    s += '\ndependencies {\n    coreLibraryDesugaring "com.android.tools:desugar_jdk_libs:2.1.4"\n}\n'

s = MARK + "\n" + s
open(path, "w", encoding="utf-8").write(s)
print("แก้", os.path.relpath(path), "เรียบร้อย")
