#!/usr/bin/env bash
# สร้างโฟลเดอร์ android/ แล้วใส่ค่าตามสเปกของ Money Cal Saving
# ใช้ครั้งเดียวหลัง clone/แตกไฟล์โปรเจกต์:  bash tool/setup_android.sh
set -euo pipefail
cd "$(dirname "$0")/.."

if ! command -v flutter >/dev/null 2>&1; then
  echo "ไม่พบคำสั่ง flutter กรุณาติดตั้ง Flutter SDK ก่อน (https://docs.flutter.dev/get-started/install)"
  exit 1
fi

if [ ! -d android ]; then
  flutter create --platforms=android --org th.moneycal --project-name money_cal_saving --no-pub .
fi

APP_ID_DIR="android/app/src/main/kotlin/th/moneycal/money_cal_saving"
mkdir -p "$APP_ID_DIR"
# ลบ MainActivity อื่นที่ flutter create อาจสร้างไว้ (ชื่อ package ต่างกัน)
find android/app/src/main/kotlin -name 'MainActivity.kt' ! -path "$APP_ID_DIR/*" -delete 2>/dev/null || true
find android/app/src/main/java -name 'MainActivity.*' -delete 2>/dev/null || true

cp android_overrides/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
cp android_overrides/MainActivity.kt "$APP_ID_DIR/MainActivity.kt"
cp android_overrides/proguard-rules.pro android/app/proguard-rules.pro

python3 tool/patch_gradle.py

flutter pub get
dart run build_runner build --delete-conflicting-outputs
dart run flutter_launcher_icons
dart run flutter_native_splash:create

echo
echo "เสร็จแล้ว รันแอปด้วย: flutter run"
