#!/usr/bin/env python3
"""สร้างไอคอนแอปและ splash พาสเทลของ Money Cal Saving (ต้องมี Pillow: pip install pillow)

ผลลัพธ์ใน assets/icon/: app_icon.png, app_icon_bg.png, app_icon_fg.png,
splash_logo.png, splash_bg.png, splash_bg_dark.png
จากนั้นรัน: dart run flutter_launcher_icons && dart run flutter_native_splash:create
"""
import math
import os

from PIL import Image, ImageChops, ImageDraw, ImageFilter

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "icon")
os.makedirs(OUT, exist_ok=True)
S = 1024


def hexc(h, a=255):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) + (a,)


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(4))


def diagonal_gradient(size, stops):
    """gradient เฉียงจากมุมซ้ายบนไปขวาล่าง stops = [(t, color), ...]"""
    w, h = size
    img = Image.new("RGBA", size)
    px = img.load()
    for y in range(h):
        for x in range(w):
            t = (x / (w - 1) + y / (h - 1)) / 2
            for i in range(len(stops) - 1):
                t0, c0 = stops[i]
                t1, c1 = stops[i + 1]
                if t <= t1 or i == len(stops) - 2:
                    k = 0 if t1 == t0 else min(max((t - t0) / (t1 - t0), 0), 1)
                    px[x, y] = lerp(c0, c1, k)
                    break
    return img


def blob(canvas, center, radius, color, blur):
    layer = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    cx, cy = center
    d.ellipse((cx - radius, cy - radius, cx + radius, cy + radius), fill=color)
    layer = layer.filter(ImageFilter.GaussianBlur(blur))
    canvas.alpha_composite(layer)


def make_bg():
    img = diagonal_gradient((S, S), [(0, hexc("#A0C4FF")), (0.55, hexc("#BDB2FF")), (1, hexc("#E2D5F8"))])
    blob(img, (150, 900), 330, hexc("#A8E6CF", 150), 90)
    blob(img, (900, 140), 300, hexc("#FFB7B2", 140), 90)
    blob(img, (860, 880), 220, hexc("#FFDAC1", 110), 80)
    return img


def make_fg(size=S, scale=1.0, shadow=True):
    """เหรียญสีขาวมุก + ต้นกล้า (เงินงอกเงย) บนพื้นโปร่งใส อยู่ใน safe zone ของ adaptive icon"""
    k = 3  # supersample
    W = size * k
    img = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    c = W // 2
    R = int(W * 0.30 * scale)

    if shadow:
        sh = Image.new("RGBA", (W, W), (0, 0, 0, 0))
        ImageDraw.Draw(sh).ellipse((c - R, c - R + W * 0.03, c + R, c + R + W * 0.03), fill=hexc("#7B6FC8", 110))
        sh = sh.filter(ImageFilter.GaussianBlur(W * 0.025))
        img.alpha_composite(sh)

    # เหรียญ: วงนอกไล่สีพีช-ลาเวนเดอร์ วงในขาวมุก
    ring = diagonal_gradient((2 * R, 2 * R), [(0, hexc("#FFDAC1")), (0.5, hexc("#FFB7B2")), (1, hexc("#C3B1E1"))])
    mask = Image.new("L", (2 * R, 2 * R), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, 2 * R - 1, 2 * R - 1), fill=255)
    img.paste(ring, (c - R, c - R), mask)

    r2 = int(R * 0.84)
    face = diagonal_gradient((2 * r2, 2 * r2), [(0, hexc("#FFFFFF")), (1, hexc("#FFF1E8"))])
    m2 = Image.new("L", (2 * r2, 2 * r2), 0)
    ImageDraw.Draw(m2).ellipse((0, 0, 2 * r2 - 1, 2 * r2 - 1), fill=255)
    img.paste(face, (c - r2, c - r2), m2)

    d = ImageDraw.Draw(img)
    # ขอบประจุดบนเหรียญ
    for i in range(24):
        a = 2 * math.pi * i / 24
        rr = int(R * 0.92)
        x, y = c + rr * math.cos(a), c + rr * math.sin(a)
        dr = R * 0.025
        d.ellipse((x - dr, y - dr, x + dr, y + dr), fill=hexc("#FFFFFF", 200))

    # ต้นกล้า: ก้านโค้ง + ใบ 2 ใบ ไล่สีมิ้นต์
    stem_w = int(R * 0.07)
    base = (c, c + int(R * 0.52))
    top = (c, c - int(R * 0.12))
    pts = []
    for i in range(41):
        t = i / 40
        x = base[0] + math.sin(t * math.pi * 0.9) * R * 0.06
        y = base[1] + (top[1] - base[1]) * t
        pts.append((x, y))
    d.line(pts, fill=hexc("#3FB68B"), width=stem_w, joint="curve")
    d.ellipse((pts[0][0] - stem_w / 2, pts[0][1] - stem_w / 2, pts[0][0] + stem_w / 2, pts[0][1] + stem_w / 2), fill=hexc("#3FB68B"))

    def leaf(origin, angle, length, width, c1, c2):
        layer = Image.new("RGBA", (W, W), (0, 0, 0, 0))
        ld = ImageDraw.Draw(layer)
        poly = []
        n = 40
        for i in range(n + 1):
            t = i / n
            w = math.sin(t * math.pi) * width / 2
            poly.append((t * length, -w))
        for i in range(n, -1, -1):
            t = i / n
            w = math.sin(t * math.pi) * width / 2
            poly.append((t * length, w))
        ca, sa = math.cos(angle), math.sin(angle)
        pts2 = [(origin[0] + x * ca - y * sa, origin[1] + x * sa + y * ca) for x, y in poly]
        ld.polygon(pts2, fill=c1)
        # ไฮไลต์ครึ่งบนของใบ
        hl = [(origin[0] + x * ca - y * sa, origin[1] + x * sa + y * ca) for x, y in poly[: n // 2 + 1]]
        ld.line(hl, fill=c2, width=max(2, int(R * 0.02)))
        img.alpha_composite(layer)

    leaf(top, -math.radians(150), R * 0.62, R * 0.34, hexc("#7EDDB2"), hexc("#D6F7E8"))
    leaf(top, -math.radians(30), R * 0.62, R * 0.34, hexc("#A8E6CF"), hexc("#E8FBF1"))

    # ประกายเล็ก
    def sparkle(cx, cy, r, color):
        d.polygon([(cx, cy - r), (cx + r * 0.28, cy - r * 0.28), (cx + r, cy), (cx + r * 0.28, cy + r * 0.28),
                   (cx, cy + r), (cx - r * 0.28, cy + r * 0.28), (cx - r, cy), (cx - r * 0.28, cy - r * 0.28)], fill=color)

    sparkle(c + R * 0.95, c - R * 0.85, R * 0.16, hexc("#FFFFFF"))
    sparkle(c - R * 1.0, c - R * 0.55, R * 0.10, hexc("#FFFFFF", 230))

    return img.resize((size, size), Image.LANCZOS)


def rounded(img, radius):
    mask = Image.new("L", img.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, img.size[0] - 1, img.size[1] - 1), radius=radius, fill=255)
    out = Image.new("RGBA", img.size, (0, 0, 0, 0))
    out.paste(img, (0, 0), mask)
    return out


def splash_bg(dark):
    w, h = 1080, 1920
    if dark:
        base = diagonal_gradient((w, h), [(0, hexc("#1E1B33")), (1, hexc("#2A2646"))])
        a = 60
    else:
        base = diagonal_gradient((w, h), [(0, hexc("#FFF9F5")), (1, hexc("#FFF1F5"))])
        a = 130
    blob(base, (120, 140), 380, hexc("#A0C4FF", a), 120)
    blob(base, (980, 520), 330, hexc("#FFB7B2", a), 120)
    blob(base, (80, 1380), 360, hexc("#A8E6CF", a), 120)
    blob(base, (960, 1840), 340, hexc("#C3B1E1", a), 120)
    return base


bg = make_bg()
fg = make_fg(S, 1.0)
bg.convert("RGB").save(os.path.join(OUT, "app_icon_bg.png"))
fg.save(os.path.join(OUT, "app_icon_fg.png"))

full = bg.copy()
full.alpha_composite(fg)
full.convert("RGB").save(os.path.join(OUT, "app_icon.png"))

make_fg(768, 1.25).save(os.path.join(OUT, "splash_logo.png"))
splash_bg(False).convert("RGB").save(os.path.join(OUT, "splash_bg.png"))
splash_bg(True).convert("RGB").save(os.path.join(OUT, "splash_bg_dark.png"))
print("สร้างไอคอนและ splash แล้วที่", os.path.abspath(OUT))
