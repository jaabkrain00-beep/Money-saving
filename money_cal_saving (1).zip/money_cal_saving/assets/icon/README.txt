ไอคอนและ splash สร้างด้วย: python3 tool/generate_icons.py (ต้องมี Pillow) แล้วรัน dart run flutter_launcher_icons และ dart run flutter_native_splash:create
