วางไฟล์ฟอนต์ Noto Sans Thai (.ttf) ไว้ในโฟลเดอร์นี้
ตั้งชื่อไฟล์ตามรูปแบบของ google_fonts เช่น
  NotoSansThai-Regular.ttf
  NotoSansThai-Medium.ttf
  NotoSansThai-SemiBold.ttf
  NotoSansThai-Bold.ttf
รายละเอียดอยู่ใน README.md หัวข้อ "ฟอนต์"
